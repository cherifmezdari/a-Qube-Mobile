module.exports = {
    "parser": "babel-eslint",
    "plugins": [
        "react",
        "react-native"
    ],
    "extends": ["eslint:recommended", "plugin:react/recommended", "plugin:react-native/all"],
    "env": {
        "jest": true,
        "react-native/react-native": true
    },
    "rules": {
        "react/jsx-filename-extension": "off",
        "react/prop-types": "off",
        "react-native/no-color-literals": "off",
        "react-native/no-raw-text": "off"
    },
    "globals": {
        "fetch": false
    }
}
