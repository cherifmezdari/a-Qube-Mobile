#!/bin/bash

cd android/

testfairy_url=https://upload.testfairy.com/api/upload/
apkfile=app/build/outputs/apk/dev/release/app-dev-release-unsigned.apk

if [ "${CI_COMMIT_REF_NAME}" = "master" ]; then
    apkfile=app/build/outputs/apk/prod/release/app-prod-release-unsigned.apk
fi

jarsigner -storepass:env storepass -keypass:env keypass -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore selfsign.ci.keystore ${apkfile} alias_name

curl \
  -A "GitLab CI" \
  -F api_key="${TESTFAIRY_API_KEY}" \
  -F comment="GitLab Pipeline build ${CI_COMMIT_SHA}" \
  -F file=@${apkfile} \
  ${testfairy_url}
