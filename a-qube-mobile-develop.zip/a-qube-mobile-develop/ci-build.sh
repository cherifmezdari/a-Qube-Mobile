#!/bin/bash

if [ "${CI_COMMIT_REF_NAME}" = "master" ]; then
  echo "Building for Production"
  cp .env.prod .env
  npm run build-prod
else
  echo "Building for Integration Environment"
  cp .env.dev .env
  npm run build-dev
fi
