const Colors = {
    Black: "#05030AFF",
    Eerie: "#171417FF",
    Gray: "#EFF0F1FF",
    DarkGray: "#DFDFDF",
    Granite: "#464449FF",
    Pink: "#803349FF",
    Translucid: {
        Gray: "#EFF0F180",
    },
    White: "#FFFFFFFF",
}

export default Colors
