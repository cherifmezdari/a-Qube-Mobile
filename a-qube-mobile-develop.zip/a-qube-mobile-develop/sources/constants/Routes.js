const Routes = {
    Contribution: "Contribution",
    Idea: "Idea",
    Inqubator: "Inqubator",
    Login: "Login",
    Profile: "Profile",
    Propose: "Propose",
    Register: "Register",
    Welcome: "Welcome",
    VerifyAccount: "VerifyAccount",
    EnterCode: "EnterCode",
    CreateNickname: "CreateNickname",
    ChooseAvatar: "ChooseAvatar",
    PickSkills: "PickSkills",
    ProfileComplete: "ProfileComplete",
    ApplicationStack: "ApplicationDrawer",
}

export default Routes
