const Tracks = {
    Business: "Business Innovation Track",
    Blockchain: "Blockchain & DLT Track"
}

export default Tracks
