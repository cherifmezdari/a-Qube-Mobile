const Forms = {
    Placeholders: {
        ConfirmPassword: "Confirm password",
        Email: "Email",
        Password: "Password",
        Phone: "Phone number",
        Code: "Enter the code",
        Nickname: "Nickname",
        TextBox: "Text box",
        TextFiles: "Add text and files",
        Upload: "Upload visuals",
        Search: "Searching for a concrete Qube?"
    }
}

export default Forms
