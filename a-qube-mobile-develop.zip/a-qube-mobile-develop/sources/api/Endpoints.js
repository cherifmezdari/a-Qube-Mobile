import AsyncStorage from "@react-native-community/async-storage";
import { API_URI_INQUBATOR } from './URIMapping';

export async function fetchMatchedIdeas() {
    const token = await AsyncStorage.getItem("@userToken");
    console.log(token);
    const response = fetch(API_URI_INQUBATOR + "/ideas/matched/", {
        method: "GET",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        }
    }).then(data => data.json());
    return response;
}


export function sendIdeaProposal(name) {
    const data = {
        name: name,
        token_pool: 360,
        track_slots: "5cba5342876f5b3cea3796ae"
    };
    //FIXME: endpoint does not exist in backend, did you mean /slots
    const response = fetch(API_URI_INQUBATOR + "/inqubator/slots", {
        method: "POST",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    })
        .then(response => {
            const statusCode = response.status;
            const data = response.json();
            return Promise.all([statusCode, data]).then(res => ({
                statusCode: res[0],
                data: res[1]
            }));
        })
        .catch(error => {
            console.error(error);
        });
    return response;
}

export async function getProposalStatus(idea, slot) {
    const token = await AsyncStorage.getItem("@userToken");
    const response = fetch(
        API_URI_INQUBATOR + "/idea/ + idea + "/slot/" + slot + "/status",
        {
            method: "GET",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`
            }
        }
    )
        .then(response => response.json())
        .then(responseJson => {
            return responseJson;
        })
        .catch(error => {
            console.error(error);
        });
    return response;
}

export async function fetchAllIdeas() {
    const token = await AsyncStorage.getItem("@userToken");
    const response = fetch(API_URI_INQUBATOR + "/ideas", {
        method: "GET",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        }
    })
        .then(response => {
            return response.json();
        })
        .then(responseJson => {
            return responseJson;
        })
        .catch(error => {
            console.error(error);
        });

    return response;
}
