import AsyncStorage from "@react-native-community/async-storage";
import { API_URI_INQUBATOR } from './URIMapping';

export async function fetchAllContributions(ideaID, slotID) {
    const token = await AsyncStorage.getItem("@userToken");
    const response = fetch(
        API_URI_INQUBATOR +
        ideaID +
        "/slot/" +
        slotID +
        "/contributions",
        {
            method: "GET",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`
            }
        }
    )
        .then(data => data.json())
        .then(responseJson => {
            return responseJson;
        })
        .catch(error => {
            console.error(error);
        });
    return response;
}