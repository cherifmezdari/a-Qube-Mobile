import AsyncStorage from "@react-native-community/async-storage";
import { API_URI_INQUBATOR } from './URIMapping';

export async function fetchIdeas(track) {
    const token = await AsyncStorage.getItem("@userToken");
    const response = fetch(`${API_URI_INQUBATOR}/ideas/track_slots/${track}`, {
        method: "GET",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        }
    })
        .then(response => {
            return response.json();
        })
        .then(responseJson => {
            return responseJson;
        })
        .catch(error => {
            console.error(error);
        });

    return response;
}

export async function FetchNotifications() {
    const token = await AsyncStorage.getItem("@userToken");
    const response = fetch(API_URI_INQUBATOR + "/user-profile/notifications", {
        method: "GET",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        }
    })
        .then(response => response.json())
        .then(responseJson => {
            return responseJson;
        })
        .catch(error => {
            console.error(error);
        });
    return response;
}

export async function fetchRandomIdeas() {
    const token = await AsyncStorage.getItem("@userToken");
    console.log(token);
    const response = fetch(API_URI_INQUBATOR + "/idea/random", {
        method: "GET",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        }
    }).then(data => data.json());
    return response;
}

export async function fetchWalletBalance() {
    const token = await AsyncStorage.getItem("@userToken");
    const response = fetch(API_URI_INQUBATOR + "/user-profile/balance", {
        method: "GET",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        }
    })
        .then(response => {
            return response.json();
        })
        .then(responseJson => {
            return responseJson;
        })
        .catch(error => {
            console.error(error);
        });

    return response;
}

export async function likeIdea(ideaID) {
    const token = await AsyncStorage.getItem("@userToken");

    const response = fetch(`${API_URI_INQUBATOR}/idea/${ideaID}/swipe/likes`, {
        method: "Post",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        }
    })
        .then(response => {
            const statusCode = response.status;
            const data = response.json();
            return Promise.all([statusCode, data]).then(res => ({
                statusCode: res[0],
                data: res[1]
            }));
        })
        .catch(error => {
            console.error(error);
        });
    return response;
}

export async function dislikeIdea(ideaID) {
    const token = await AsyncStorage.getItem("@userToken");

    const response = fetch(
        `${API_URI_INQUBATOR}/idea/${ideaID}/swipe/dislikes`,
        {
            method: "Post",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`
            }
        }
    )
        .then(response => {
            const statusCode = response.status;
            console.log(statusCode);
            const data = response.json();
            return Promise.all([statusCode, data]).then(res => ({
                statusCode: res[0],
                data: res[1]
            }));
        })
        .catch(error => {
            console.error(error);
        });
    return response;
}

export async function fetchUserProfile() {
    const token = await AsyncStorage.getItem("@userToken");
    console.log(token);
    const response = fetch(API_URI_INQUBATOR + "/user-profile", {
        method: "GET",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        }
    })
        .then(response => response.json())
        .then(responseJson => {
            return responseJson;
        })
        .catch(error => {
            console.error(error);
        });

    return response;
}

export async function fetchMyChallenges() {
    const token = await AsyncStorage.getItem("@userToken");
    const response = fetch(API_URI_INQUBATOR + "/ideas", {
        method: "GET",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        }
    })

        .then(async response => {
            const statusCode = response.status;
            console.log(statusCode);
            const data = response.json();
            const res = await Promise.all([statusCode, data]);
            return ({
                statusCode: res[0],
                data: res[1]
            });
        }).catch(error => {
            console.warn(error);
        });
    return response;
}

export async function fetchEngagementRate(ideaID) {
    const token = await AsyncStorage.getItem("@userToken");
    const response = fetch(`${API_URI_INQUBATOR}/idea/${ideaID}/engagement_rate`,
        {
            method: "GET",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`
            }
        }
    )
        .then(data => data.json())
        .then(responseJson => {
            return responseJson;
        })
        .catch(error => {
            console.error(error);
        });
    return response;
}