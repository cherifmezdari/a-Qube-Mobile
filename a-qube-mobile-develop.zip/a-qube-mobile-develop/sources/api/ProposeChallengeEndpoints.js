import AsyncStorage from "@react-native-community/async-storage";
import { API_URI_INQUBATOR } from './URIMapping';

export async function fetchTracks() {
    const token = await AsyncStorage.getItem("@userToken");
    const response = fetch(API_URI_INQUBATOR + "/tracks", {
        method: "GET",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        }
    })
        .then(data => data.json())
        .then(responseJson => {
            return responseJson;
        })
        .catch(error => {
            console.error(error);
        });
    return response;
}

export async function fetchTracksSlotsList() {
    const token = await AsyncStorage.getItem("@userToken");
    console.log(token);
    const response = fetch(API_URI_INQUBATOR + "/tracks/slots", {
        method: "GET",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        }
    })
        .then(data => data.json())
        .then(responseJson => {
            return responseJson;
        })
        .catch(error => {
            console.error(error);
        });
    return response;
}

export async function sendIdea(data, slots) {
    const token = await AsyncStorage.getItem("@userToken");
    console.log(token);
    const { name, token_pool, trackSlotID, qube_number } = data;
    console.log(
        name + " " + token_pool + " " + trackSlotID,
        +" " + qube_number
    );
    const sendData = {
        name: name,
        track: trackSlotID,
        qube_number: qube_number,
        slots: slots,
        qube_value: token_pool
    };
    const response = fetch(API_URI_INQUBATOR + "/idea", {
        method: "POST",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(sendData)
    })
        .then(response => {
            const statusCode = response.status;
            const data = response.json();
            return Promise.all([statusCode, data]).then(res => ({
                statusCode: res[0],
                data: res[1]
            }));
        })
        .catch(error => {
            console.error(error);
        });
    return response;
}