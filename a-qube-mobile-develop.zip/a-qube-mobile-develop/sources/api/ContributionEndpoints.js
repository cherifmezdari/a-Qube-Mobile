import AsyncStorage from "@react-native-community/async-storage";
import { API_URI_INQUBATOR } from './URIMapping';

export async function ContributeNow(data, answers) {
    console.log(data);
    const token = await AsyncStorage.getItem("@userToken");
    const { name, token_pool } = data;
    const sendData = {
        contributions: answers,
        predictive_guess: token_pool
    };
    const response = fetch(API_URI_INQUBATOR +
        data.ideaID +
        "/slot/" +
        data.slot +
        "/contribute",
        {
            method: "POST",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`
            },
            body: JSON.stringify(sendData)
        }
    )
        .then(data => data.json())
        .then(responseJson => {
            return responseJson;
        })
        .catch(error => {
            console.error(error);
        });

    return response;
}

export async function payForContribution(info) {
    console.log(info);
    const token = await AsyncStorage.getItem("@userToken");

    const response = fetch(
        API_URI_INQUBATOR + "/idea/" +
        info.idea._id +
        "/contribution/" +
        info.contribution._id +
        "/fee/" +
        info._id +
        "/pay",
        {
            method: "Post",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`
            }
        }
    )
        .then(response => {
            const statusCode = response.status;
            console.log(statusCode);
            const data = response.json();
            return Promise.all([statusCode, data]).then(res => ({
                statusCode: res[0],
                data: res[1]
            }));
        })
        .catch(error => {
            console.error(error);
        });
    return response;
}

export async function fetchContributionFee(info) {
    console.log(info);
    const token = await AsyncStorage.getItem("@userToken");

    const contributionID = info._id;
    const ideaID = info.idea._id;

    console.log(contributionID + " " + ideaID);

    const response = fetch(API_URI_INQUBATOR + "/idea/" +
        ideaID +
        "/contribution/" +
        contributionID +
        "/fee",
        {
            method: "GET",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`
            }
        }
    )
        .then(data => data.json())
        .then(responseJson => {
            return responseJson;
        })
        .catch(error => {
            console.error(error);
        });
    return response;
}

export async function getImplementationPool(idea) {
    const token = await AsyncStorage.getItem("@userToken");
    const response = fetch(
        API_URI_INQUBATOR + "/idea/" + idea + "/implementation_pools",
        {
            method: "GET",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`
            }
        }
    )
        .then(data => data.json())
        .then(responseJson => {
            return responseJson;
        })
        .catch(error => {
            console.error(error);
        });
    return response;
}