import AsyncStorage from "@react-native-community/async-storage";
import { API_URI_INQUBATOR, API_URI_USER_AUTH } from './URIMapping';

export async function checkToken() {
    const token = await AsyncStorage.getItem("@userToken");
    const response = fetch(API_URI_INQUBATOR + "/user-profile", {
        method: "GET",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        }
    })
        .then(data => data.json())
        .then(responseJson => {
            return responseJson;
        })
        .catch(error => {
            console.error(error);
        });
    return response;
}

export async function authenticated() {
    const token = await AsyncStorage.getItem("@userToken");
    const response = fetch(API_URI_USER_AUTH + "/auth", {
        method: "GET",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        }
    })

        .then(async response => {
            const statusCode = response.status;
            console.log(statusCode);
            const data = response.json();
            const res = await Promise.all([statusCode, data]);
            return ({
                statusCode: res[0],
                data: res[1]
            });
        }).catch(error => {
            console.warn(error);
        });
    return response;
}

export function signUpFunction(password, email) {
    const url = API_URI_USER_AUTH + "/user/create";
    return fetch(url, {
        method: "POST",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            email: email,
            password: password
        })
    }).catch(error => {
        console.warn(error);
    });
}

export function forgetPassword(email) {
    const url = API_URI_USER_AUTH + "/user/forgot/password";
    return fetch(url, {
        method: "POST",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            email: email
        })
    }).catch(error => {
        console.warn(error);
    });
}

export function NewPassword(email, passcode, password) {
    console.log(email + " " + passcode + " " + password)
    const url = API_URI_USER_AUTH + "/user/forgot/password";
    return fetch(url, {
        method: "PUT",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            email: email,
            passcode: passcode,
            password: password
        })
    })
        .then(response => response.status)
        .catch(error => {
            console.warn(error);
        });
}

export function CheckPasscode(email, passcode) {
    console.log(email + " " + passcode)
    const url = API_URI_USER_AUTH + "/user/forgot/password/passcode";
    return fetch(url, {
        method: "POST",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            email: email,
            passcode: passcode
        })
    })
        .then(response => response.status)
        .catch(error => {
            console.warn(error);
        });
}

export function addMobile(email, password, mobile) {
    const url = API_URI_USER_AUTH + "/user/add/mobile";
    return fetch(url, {
        method: "PUT",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            email: email,
            password: password,
            mobile: mobile,
            fullname: "pool"
        })
    })
        .then(response => response.status)
        .catch(error => {
            console.warn(error);
        });
}

export function verifyUser(email, password, passcode) {
    const url = API_URI_USER_AUTH + "/user/activation";
    return fetch(url, {
        method: "POST",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            email: email,
            passcode: passcode,
            password: password
        })
    })
        .then(response => response.status)
        .catch(error => {
            console.warn(error);
        });
}



export function loginFunction(email, password) {
    const url = API_URI_USER_AUTH + "/auth";
    return fetch(url, {
        method: "POST",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            email: email,
            password: password
        })
    })
        .then(response => {
            const statusCode = response.status;
            const data = response.json();
            return Promise.all([statusCode, data]).then(res => ({
                statusCode: res[0],
                data: res[1]
            }));
        })
        .catch(error => {
            console.warn(error);
            return { name: "network error", description: "" };
        });
}

export function sessionVerification() {
    return fetch(API_URI_USER_AUTH + "/auth")
        .then(response => response.status)
        .catch(error => {
            console.error(error);
        });
}

export async function fetchAvatars() {
    const token = await AsyncStorage.getItem("@userToken");
    const response = fetch(API_URI_INQUBATOR + "/user-profile/avatars", {
        method: "GET",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        }
    })
        .then(response => response.json())
        .then(responseJson => {
            return responseJson;
        })
        .catch(error => {
            console.error(error);
        });
    return response;
}

export async function fetchSkills() {
    const token = await AsyncStorage.getItem("@userToken");
    const response = fetch(API_URI_INQUBATOR + "/user-profile/interests", {
        method: "GET",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        }
    })
        .then(response => response.json())
        .then(responseJson => {
            return responseJson;
        })
        .catch(error => {
            console.error(error);
        });

    return response;
}

export async function editProfile(avatar, interests, nickname) {
    const token = await AsyncStorage.getItem("@userToken");
    console.log(avatar);
    console.log(interests);
    console.log(nickname);
    const user = {
        avatar: avatar,
        interests: interests,
        nickname: nickname
    };

    const response = fetch(API_URI_INQUBATOR + "/user-profile", {
        method: "Post",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(user)
    })
        .then(response => response.json())
        .then(responseJson => {
            console.log(responseJson);
            return responseJson;
        })
        .catch(error => {
            console.error(error);
        });

    return response;
}

export async function fetchWalletBalance() {
    const token = await AsyncStorage.getItem("@userToken");
    const response = fetch(API_URI_INQUBATOR + "/user-profile/balance", {
        method: "GET",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        }
    })
        .then(response => {
            return response.json();
        })
        .then(responseJson => {
            return responseJson;
        })
        .catch(error => {
            console.error(error);
        });

    return response;
}