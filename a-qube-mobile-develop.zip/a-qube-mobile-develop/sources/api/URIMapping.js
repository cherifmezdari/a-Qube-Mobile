import Config from 'react-native-config';

export const API_URI_USER_AUTH = Config.API_URI_USER_AUTH;
export const API_URI_PVM = Config.API_URI_PVM;
export const API_URI_INQUBATOR = Config.API_URI_INQUBATOR;
