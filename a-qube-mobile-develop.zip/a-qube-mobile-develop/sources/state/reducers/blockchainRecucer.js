
function blockchainRecucer(state = { slots: [] }, action) {
  let nextState
  switch (action.type) {
    case 'TOGGLE_BLOCK':
      const favoriteslotsIndex = state.slots.findIndex(item => item === action.value)
      if (favoriteslotsIndex !== -1) {
        // Le slots est déjà dans les favoris, on le supprime de la liste
        nextState = {
          ...state,
          slots: state.slots.filter( (item, index) => index !== favoriteslotsIndex)
        }
      }
      else {
        // Le slots n'est pas dans les slotss favoris, on l'ajoute à la liste
        nextState = {
          ...state,
          slots: [...state.slots, action.value]
        }
      }
      return nextState || state
  default:
    return state
  }
}
export default blockchainRecucer
