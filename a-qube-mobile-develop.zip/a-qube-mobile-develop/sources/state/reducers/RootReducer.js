import { combineReducers } from "redux"

import LoginReducer from "./LoginReducer"
import AddIngredient from "./IngredientReducer"
import blockchainRecucer from "./blockchainRecucer"


const RootReducer = combineReducers({ AddIngredient,blockchainRecucer })

export default RootReducer
