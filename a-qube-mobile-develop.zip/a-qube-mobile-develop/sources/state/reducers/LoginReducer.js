const LoginReducer = (state = { LoginInfo: [] }, action) => {
    state = action.value
    state = {
        LoginInfo: action.value,
    }
    return state
}

export default LoginReducer
