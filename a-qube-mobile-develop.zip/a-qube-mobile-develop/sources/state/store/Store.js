import { createStore } from "redux"

import CombineReducer from "../reducers/RootReducer"

const Store = createStore(CombineReducer)

export default Store
