import React, { Component } from "react";
import {
    Image,
    KeyboardAvoidingView,
    Keyboard,
    Platform,
    StyleSheet,
    Text,
    View,
    TouchableWithoutFeedback
} from "react-native";
import { Bar } from "react-native-progress";
import Slider from "@react-native-community/slider";
import Swiper from "react-native-web-swiper";

import { fetchAllContributions } from "../../../api/ValidationEndpoints";

import Button from "../../common/Button/Button";
import Screen from "../../common/Screen/Screen";
import Input from "../../common/Input/Input";

import Colors from "../../../constants/Colors";
import Images from "../../../constants/Images";
import Forms from "../../../constants/Forms";


const paddingBehavior = Platform.OS === "ios" ? "padding" : "";

export default class ProposeValidation extends Component {
    constructor(props) {
        super(props);
        this.state = {
            contributions: null,
            track: this.props.navigation.state.params.previousState.data,
            token_pool: 360,
            question1: "",
            question2: "",
            question3: "",
            modalVisible: false,
            slot: this.props.navigation.state.params.previousState.data._id,
            idea: this.props.navigation.state.params.previousState.data,
            ideaID: this.props.navigation.state.params.previousState.idea._id
        };
    }
    componentWillMount() {
        const { ideaID, slot } = this.state;
        return fetchAllContributions(ideaID, slot).then(t =>
            this.setState({ contributions: t })
        );
    }
    _handlePropose() {
        const { question1, question2, question3, track } = this.state;

        //console.log(this.state)

        switch (track.questions.length) {
            case 1:
                if (question1 != "") {
                    const contributionAnswers = [
                        {
                            answer: question1,
                            question_id: this.state.track.questions[0]._id
                        }
                    ];
                    //this.setState({ contributions: contributionAnswers });

                    console.log(contributionAnswers);

                    ContributeNow(this.state, contributionAnswers).then(d => {
                        console.warn(d);
                        this.setState({ modalVisible: true });
                    });
                }

            case 2:
                if (question1 != "" && question2 != "") {
                    const contributionAnswers = [
                        {
                            answer: question1,
                            question_id: this.state.track.questions[0]._id
                        },
                        {
                            answer: question2,
                            question_id: this.state.track.questions[1]._id
                        }
                    ];
                    //this.setState({ contributions: contributions });

                    ContributeNow(this.state, contributionAnswers).then(d => {
                        console.warn(d);
                        this.setState({ modalVisible: true });
                    });
                }

            case 3:
                if (question1 != "" && question2 != "" && question3 != "") {
                    const contributionAnswers = [
                        {
                            answer: question1,
                            question_id: this.state.track.questions[0]._id
                        },
                        {
                            answer: question2,
                            question_id: this.state.track.questions[1]._id
                        },
                        {
                            answer: question3,
                            question_id: this.state.track.questions[2]._id
                        }
                    ];
                    //this.setState({ contributions: contributions });

                    ContributeNow(this.state, contributionAnswers).then(d => {
                        console.warn(d);
                        this.setState({ modalVisible: true });
                    });
                }
        }
    }
    singleQuestion() {
        const { Placeholders } = Forms;
        const { TextBox } = Placeholders;
        const { contributions } = this.state;
        return (
            <View style={Styles.Slide}>
                <Swiper>
                    {contributions[0].slots_questions_answers.map(
                        (item, index) => (
                            <View key={index} style={{ flex: 1 }}>
                                <Text style={Styles.TextQuestion}>
                                    a: {item.question.name}
                                </Text>
                                <Input
                                    onSubmitEditing={Keyboard.dismiss}
                                    onChangeText={text =>
                                        this.setState({ question1: text })
                                    }
                                    multiline={true}
                                    placeholder={TextBox}
                                    styles={[
                                        Styles.TextBox,
                                        Styles.TextBoxSmall,
                                        { height: 50 }
                                    ]}
                                    value={item.answer}
                                />
                            </View>
                        )
                    )}
                </Swiper>
            </View>
        );
    }
    twoQuestions() {
        const { Placeholders } = Forms;
        const { TextBox } = Placeholders;
        const { contributions } = this.state;
        return (
            <View style={Styles.Slide}>
                <Swiper>
                    {contributions[0].slots_questions_answers.map(
                        (item, index) => (
                            <View key={index} style={{ flex: 1 }}>
                                <Text style={Styles.TextQuestion}>
                                    a: {item.question.name}
                                </Text>
                                <Input
                                    onSubmitEditing={Keyboard.dismiss}
                                    onChangeText={text =>
                                        this.setState({ question1: text })
                                    }
                                    multiline={true}
                                    placeholder={TextBox}
                                    styles={[
                                        Styles.TextBox,
                                        Styles.TextBoxSmall,
                                        { height: 50 }
                                    ]}
                                    value={item.answer}
                                />
                            </View>
                        )
                    )}
                </Swiper>
            </View>
        );
    }
    threeQuestions(data) {
        const { Placeholders } = Forms;
        const { TextBox } = Placeholders;
        const { contributions } = this.state;
        return (
            <Swiper>
                {data.map((item, index) => (
                    <View style={Styles.Slide} key={index}>
                        <Text style={Styles.TextQuestion}>
                            a: {item.question.name}
                        </Text>
                        <Input
                            onSubmitEditing={Keyboard.dismiss}
                            onChangeText={text =>
                                this.setState({ question1: text })
                            }
                            multiline={true}
                            placeholder={TextBox}
                            styles={[
                                Styles.TextBox,
                                Styles.TextBoxSmall,
                                { height: 50 }
                            ]}
                            value={item.answer}
                        />
                    </View>
                ))}
            </Swiper>
        );
    }
    displayQuestions() {
        const { contributions } = this.state;
        console.log(contributions[0].slots_questions_answers.length);

        switch (contributions[0].slots_questions_answers.length) {
            case 1:
                return this.singleQuestion(
                    contributions[0].slots_questions_answers
                );
            case 2:
                return this.twoQuestions(
                    contributions[0].slots_questions_answers
                );
            case 3:
                return this.threeQuestions(
                    contributions[0].slots_questions_answers
                );
        }
    }
    _navigate() {
        const { navigation } = this.props;
        navigation.navigate("Inqubator");
    }
    render() {
        console.log("ProposeValidation");
        console.log(this.state);
        const { track, contributions } = this.state;
        const { Blockchain } = Images;

        if (track != null && contributions != null) {
            return (
                <Screen>
                    <TouchableWithoutFeedback
                        onPress={() => Keyboard.dismiss()}
                    >
                        <KeyboardAvoidingView
                            style={{ flex: 1 }}
                            behavior={paddingBehavior}
                            enabled
                        >
                            <View style={Styles.Container}>
                                <View style={Styles.Header}>
                                    <Image
                                        source={Blockchain}
                                        style={Styles.Image}
                                    />
                                    <Text style={Styles.Text}>1/6</Text>
                                    <Bar
                                        borderRadius={5}
                                        color={"rgba(128, 51, 73, 1)"}
                                        height={10}
                                        progress={0.17}
                                    />
                                    <Text style={Styles.Title}>
                                        Fill the form to propose your idea
                                    </Text>
                                </View>
                                {this.displayQuestions()}
                                <View style={Styles.Slider}>
                                    <Text style={Styles.Text}>
                                        Choose an evaluation for your idea
                                    </Text>
                                    <View
                                        style={{
                                            flexDirection: "row",
                                            width: "80%",
                                            alignSelf: "center",
                                            justifyContent: "space-between"
                                        }}
                                    >
                                        <Text>360</Text>
                                        <Text>1440</Text>
                                    </View>
                                    <Slider
                                        style={{
                                            width: "80%",
                                            height: 40,
                                            alignSelf: "center"
                                        }}
                                        minimumValue={360}
                                        maximumValue={1440}
                                        minimumTrackTintColor="rgba(128, 51, 73, 1)"
                                        maximumTrackTintColor="gray"
                                        value={360}
                                        onValueChange={val =>
                                            this.setState({
                                                token_pool: Math.round(val)
                                            })
                                        }
                                    />
                                    <Text style={Styles.TokenPool}>
                                        {this.state.token_pool}
                                    </Text>
                                </View>
                            </View>
                            <Button
                                onPress={() => this._handlePropose()}
                                styles={{ width: "100%", alignSelf: "center" }}
                            >
                                Validtate
                            </Button>
                        </KeyboardAvoidingView>
                    </TouchableWithoutFeedback>
                </Screen>
            );
        }
        return <View />;
    }
}

const { Eerie, Gray, Pink } = Colors;
const Styles = StyleSheet.create({
    Container: {
        flex: 1,
        paddingTop: 5
    },
    Image: {
        height: 80,
        width: 80
    },
    Header: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
        paddingTop: 10
    },
    Title: {
        fontSize: 20,
        marginVertical: 10,
        textAlign: "center",
        fontFamily: "OpenSans-SemiBold"
    },
    Text: {
        color: Eerie,
        fontSize: 14,
        margin: 10,
        textTransform: "uppercase",
        fontFamily: "OpenSans-Regular"
    },
    Slide: {
        flex: 2,
        justifyContent: "center",
        alignItems: "center"
    },
    TextQuestion: {
        color: Eerie,
        fontSize: 16,
        padding: 5,
        textAlign: "left",
        fontFamily: "OpenSans-Regular"
    },
    TextBox: {
        backgroundColor: Gray,
        color: "black"
    },
    TextBoxBig: {
        height: 250
    },
    Question: {
        fontSize: 14,
        fontWeight: "700",
        fontFamily: "OpenSans-Regular"
    },
    TextBoxSmall: {
        height: 100
    },
    TokenPool: {
        textAlign: "center",
        fontFamily: "OpenSans-Regular"
    },
    ModalContainer: {
        flex: 1,
        alignItems: "center",
        backgroundColor: Gray,
        marginVertical: 300,
        marginHorizontal: 50,
        borderRadius: 10,
        justifyContent: "center"
    },
    Slider: {
        flex: 1
    }
});
