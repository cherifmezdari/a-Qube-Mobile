import React, { Component } from "react";
import {
    Dimensions,
    Image,
    KeyboardAvoidingView,
    Platform,
    Keyboard,
    StyleSheet,
    Text,
    View,
    TouchableWithoutFeedback
} from "react-native";
import { connect } from "react-redux";

import Screen from "../../common/Screen/Screen";
import Images from "../../../constants/Images";
import Input from "../../common/Input/Input";
import Forms from "../../../constants/Forms";
import BottomArrows from "../../common/BottomArrows/BottomArrows";

const paddingBehavior = Platform.OS === "ios" ? "padding" : "";

class CreateNickname extends Component {
    static navigationOptions = {
        header: null
    };
    constructor(props) {
        super(props);
        this.state = {
            nickName: "",
            error: ""
        };
    }
    _navigate(screen) {
        const { navigation } = this.props;
        navigation.navigate(screen, { nickName: this.state.nickName });
    }
    _saveUser() {
        const action = { type: "SAVE_USER", value: this.state };
        this.props.dispatch(action);
    }
    _onPress = () => {
        if (this.state.nickName === "") {
            this.setState({ error: "Please enter a nickname." });
        } else if (this.state.nickName !== "") {
            this.setState({ error: "" });
            this._nextScreen();
        }
    };
    _nextScreen() {
        this._saveUser();
        this._navigate("ChooseAvatar");
    }
    render() {
        const { Placeholders } = Forms;
        const { Logo_horizontal, Arrow_left, Arrow_right } = Images;
        const { Nickname } = Placeholders;
        return (
            <Screen>
                <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
                <KeyboardAvoidingView
                    style={{ flex: 1 }}
                    behavior={paddingBehavior}
                    enabled
                >
                    <View style={{ flex: 1 }}>
                        <Image
                            style={Styles.Image}
                            source={Logo_horizontal}
                            resizeMode="contain"
                        />

                        <Text style={Styles.Text}>Choose your nickname</Text>
                    </View>
                    <View style={{ flex: 5, alignItems: "center" }}>
                        <Text style={Styles.Step}>Step 1</Text>
                        <Text style={Styles.Paragraph}>
                            Hi, welcome to a-Qube!
                        </Text>
                        <Text
                            style={{
                                paddingBottom: 20,
                                paddingHorizontal: 10,
                                fontFamily: "OpenSans-Regular"
                            }}
                        >
                            Before you start, we'd love to learn little bit more
                            about you.
                        </Text>
                        <Input
                            onChangeText={text =>
                                this.setState({ nickName: text })
                            }
                            placeholder={Nickname}
                            onSubmitEditing={Keyboard.dismiss}
                        />
                        <Text style={[Styles.Paragraph, { color: "red" }]}>
                            {this.state.error}
                        </Text>
                        <BottomArrows
                            leftIcon={Arrow_left}
                            onPressLeft={() => this.props.navigation.goBack()}
                            rightIcon={Arrow_right}
                            onPressRight={this._onPress}
                        />
                    </View>
                </KeyboardAvoidingView>
                </TouchableWithoutFeedback>
            </Screen>
        );
    }
}

const Styles = StyleSheet.create({
    Container: {},
    Image: {
        width: Dimensions.get("window").width / 2,
        height: Dimensions.get("window").height / 8,
        alignSelf: "center"
    },
    Title: {
        paddingTop: 20,
        paddingBottom: 20
    },
    Instructions: {
        flex: 2,
        paddingLeft: 20,
        paddingRight: 20,
        alignItems: "center"
    },
    Step: {
        fontSize: 25,
        fontWeight: "600",
        paddingTop: 20,
        fontFamily: "OpenSans-Regular",
        paddingBottom: 20
    },
    Text: {
        fontSize: 25,
        fontWeight: "500",
        textAlign: "center",
        fontFamily: "OpenSans-SemiBold"
    },
    Paragraph: {
        fontSize: 18,
        paddingBottom: 20,
        fontFamily: "OpenSans-Regular"
    }
});

const mapStateToProps = state => {
    return state;
};

export default connect(mapStateToProps)(CreateNickname);
