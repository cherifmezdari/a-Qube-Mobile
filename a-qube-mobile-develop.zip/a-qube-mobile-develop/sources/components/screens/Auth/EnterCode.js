import React, { Component } from "react";
import {
    Image,
    KeyboardAvoidingView,
    Platform,
    Keyboard,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
    TouchableWithoutFeedback,
    Modal,
    Dimensions
} from "react-native";

import { verifyUser } from "../../../api/AuthEndpoints";

import Screen from "../../common/Screen/Screen";
import Button from "../../common/Button/Button";
import Forms from "../../../constants/Forms";
import Images from "../../../constants/Images";
import Input from "../../common/Input/Input";
import Colors from "../../../constants/Colors";
import Routes from "../../../constants/Routes";

const dimensions = Dimensions.get("window");

const marginHeight = Math.round(dimensions.height / 4);

const { Logo_horizontal } = Images;

const paddingBehavior = Platform.OS === "ios" ? "padding" : "";

const marginLeft = Platform.OS === "android" ? 20 : 0;

export default class EnterCode extends Component {
    static navigationOptions = ({ navigation }) => {
        return {
            headerTitle: (
                <Image
                    style={{ height: 50, width: 100, marginLeft: marginLeft }}
                    resizeMode="contain"
                    source={Logo_horizontal}
                />
            ),
            headerLeft: null
        };
    };
    _navigate(screen) {
        const { navigation } = this.props;
        navigation.navigate(screen);
    }

    _displayError(error) {
        if (error !== "") {
            return (
                <Text
                    style={{
                        fontSize: 16,
                        color: "red",
                        fontFamily: "OpenSans-Regular"
                    }}
                >
                    {this.state.error}
                </Text>
            );
        }
    }
    _onPress = () => {
        const { navigation } = this.props;
        const email = navigation.state.params.previousState.email;
        const password = navigation.state.params.previousState.password;
        if (this.state.passcode !== "") {
            verifyUser(email, password, this.state.passcode).then(data =>
                this._verifypasscode(data)
            );
        }
    };
    constructor(props) {
        super(props);
        this.state = { passcode: "" ,modalVisible:false};
    }
    _verifypasscode(data) {
        const { Login } = Routes;
        if (this.state.passcode !== "") {
            if (data == 200) {
              this.setState({modalVisible:true})
              } else if (data == 405) {
                this.setState({ error: "Passcode is invalid." });
            }
        }
    }
    render() {
        const { Placeholders } = Forms;
        const { Code } = Placeholders;
        return (
            <Screen>
                <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
                    <KeyboardAvoidingView
                        style={{ flex: 1 }}
                        behavior={paddingBehavior}
                        enabled
                    >
                        <View style={Styles.Container}>
                            <View style={Styles.Title}>
                                <Text style={Styles.Text}>Enter the code</Text>
                            </View>
                            <View style={Styles.Instructions}>
                                <Text style={Styles.Paragraph}>
                                    Enter the 6 digit code that we've sent to
                                    your Email.
                                </Text>
                            </View>
                            <Modal
                                animationType="slide"
                                transparent={true}
                                visible={this.state.modalVisible}
                            >
                                <View style={Styles.ModalContainer}>
                                    <Text
                                        style={{
                                            textAlign: "center",
                                            fontSize: 20,
                                            fontWeight: "600",
                                            fontFamily: "OpenSans-Regular"
                                        }}
                                    >
                                        Welcome, Login and start Qubing!
                                    </Text>

                                    <Button
                                        onPress={() =>
                                          {this.setState({modalVisible:false})
                                           this.props.navigation.navigate("Login")}
                                              }
                                        styles={{
                                            borderRadius: 10,
                                            backgroundColor: Pink
                                        }}
                                    >
                                        Log in!
                                    </Button>
                                </View>
                            </Modal>
                            <Input
                                onSubmitEditing={Keyboard.dismiss}
                                keyboardType="numeric"
                                placeholder={Code}
                                onChangeText={data =>
                                    this.setState({ passcode: data })
                                }
                            />
                            {this._displayError(this.state.error)}
                            <TouchableOpacity style={Styles.ResendCode}>
                                <Text style={Styles.Resend}>
                                    Resend the code?
                                </Text>
                            </TouchableOpacity>
                            <Button
                                styles={Styles.Button}
                                onPress={this._onPress}
                            >
                                Confirm
                            </Button>
                        </View>
                    </KeyboardAvoidingView>
                </TouchableWithoutFeedback>
            </Screen>
        );
    }
}
const { Eerie, Gray, Pink } = Colors;
const Styles = StyleSheet.create({
    Container: {
        flex: 1,
        alignItems: "center"
    },
    Image: {
        width: 180,
        height: 80
    },
    Title: {
        paddingTop: 20,
        paddingBottom: 20
    },
    Instructions: {
        paddingLeft: 20,
        paddingRight: 20,
        paddingBottom: 20
    },
    Text: {
        fontSize: 25,
        fontWeight: "500",
        textAlign: "center",
        fontFamily: "OpenSans-Regular"
    },
    Paragraph: {
        fontSize: 18,
        fontFamily: "OpenSans-Regular"
    },
    ResendCode: {
        alignSelf: "flex-start",
        paddingLeft: 40
    },
    Resend: {
        textDecorationLine: "underline",
        fontFamily: "OpenSans-Regular"
    },
    Button: {
        marginTop: 80,
        borderRadius: 10,
        borderColor: "red"
    },
    ModalContainer: {
        alignItems: "center",
        backgroundColor: Gray,
        borderRadius: 10,
        justifyContent: "center",
        marginTop: marginHeight,
        marginBottom: marginHeight,
        marginLeft: 10,
        marginRight: 10,
        borderColor: "black",
        borderWidth: 2
    }
});
