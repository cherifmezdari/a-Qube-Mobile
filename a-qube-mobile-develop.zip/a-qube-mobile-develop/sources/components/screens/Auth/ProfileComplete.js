import React, { Component } from "react"
import { Image, StyleSheet, Text, TouchableOpacity, View } from "react-native"

import { fetchWalletBalance } from "../../../api/AuthEndpoints"

import Screen from "../../common/Screen/Screen"
import Images from "../../../constants/Images"
import Button from "../../common/Button/Button"
import Colors from "../../../constants/Colors"

const { Logo_horizontal, Burger_Menu } = Images

export default class ProfileComplete extends Component {
    static navigationOptions = ({navigation}) => {
        return {
            headerTitle: <Image style={{ height: 50, width: 100 }} resizeMode="contain" source={Logo_horizontal} />,
        }
    }
    constructor(props) {
        super(props)
        this.state = {
            balance: ""
        }
    }
    navigate(screen) {
        const { navigation } = this.props
        navigation.navigate(screen)
    }
    componentWillMount() {
        fetchWalletBalance().then((v)=> this.setState({ balance: v }) )
    }
    render() {
        const { Logo_horizontal, Arrow_left, Arrow_right,  } = Images
        const { balance } = this.state
        return (
            <Screen>
                <View style={Styles.Container}>
                    <View style={Styles.Circle}>
                        <Text style={Styles.Earned}>{balance.balance}</Text>
                    </View>
                    <View style={Styles.TextContainer}>
                        <Text style={Styles.Congrats}>Congrats! You've just earned your first QUBs!</Text>
                        <Text>Now you're all set to start contributing to the Challenges!</Text>
                        <Button onPress={() => this.navigate("ApplicationDrawer")}styles={Styles.Button}>Start qubing!</Button>
                    </View>
                </View>
            </Screen>
        )
    }
}

const { Eerie, Gray, Pink } = Colors
const Styles = StyleSheet.create({
    Container: {
        flex: 1,
        alignItems: 'center',
    },
    Image: {
        width: 180,
        height: 80,
    },
    Circle: {
        height: 200,
        width: 200,
        backgroundColor: Gray,
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 100,
        marginTop: 40,
    },
    Earned: {
        fontSize: 80,
        fontWeight: "400",
        fontFamily: "OpenSans-Regular"
    },
    TextContainer: {
        flex: 1,
        paddingLeft: 20,
        paddingRight: 20,
        justifyContent: "space-evenly",
        marginBottom: 40,
        marginTop: 10,
    },
    Congrats: {
        fontSize: 30,
        fontFamily: "OpenSans-Regular"
    },
    Button: {
        borderRadius: 10,
    },
})
