import React, { Component } from "react";
import { Image, StyleSheet, Text, View } from "react-native";
import { Dropdown } from "react-native-material-dropdown";
import { connect } from "react-redux";

import { editProfile } from "../../../api/AuthEndpoints";

import Screen from "../../../common/Screen/Screen";
import Images from "../../../../constants/Images";
import Routes from "../../../../constants/Routes";
import BottomArrows from "../../../common/BottomArrows/BottomArrows";

const general = [
    {
        value: "Project Name + Statement",
        _id: "5d0ecff5c4b98d045ada2dbf"
    },
    {
        value: "Problem & Solution",
        _id: "5d0ecff5c4b98d045ada2dc3"
    },
    {
        value: "Logo",
        _id: "5d0ecff5c4b98d045ada2dd3"
    }
];

const business = [
    {
        value: "Target Audience & GTM",
        _id: "5d0ecff5c4b98d045ada2dc7"
    },
    {
        value: "Business Model & Service",
        _id: "5d0ecff5c4b98d045ada2dcc"
    },
    {
        value: "Investment & Funds",
        _id: "5d0ecff5c4b98d045ada2dd0"
    }
];

const blockchain = [
    {
        value: "Use of Blockchain Tech",
        _id: "5d0ecff5c4b98d045ada2ddc"
    },
    {
        value: "Consensus & Governance",
        _id: "5d0ecff5c4b98d045ada2ddf"
    },
    {
        value: "Token Type + Use & Benefits",
        _id: "5d0ecff5c4b98d045ada2de2"
    },
    {
        value: "Business Model & Tokenomics",
        _id: "5d0ecff5c4b98d045ada2de5"
    },
    {
        value: "Competitive Analysis",
        _id: "5d0ecff5c4b98d045ada2de8"
    }
];
class PickSkills extends Component {
    static navigationOptions = {
        header: null
    };
    constructor(props) {
        super(props);
        this.state = {
            skills: [],
            business: null,
            general: null,
            blockchain: null,
            error: ""
        };
    }

    _navigate(screen) {
        const { navigation } = this.props;
        navigation.navigate(screen);
    }
    _onPress = () => {
        const { general, business, blockchain } = this.state
        const nickname = this.props.navigation.state.params.previousState
            .nickName;
        const avatar = this.props.navigation.state.params.previousState.avatar
            ._id;
        const interests = [
            general,
            business,
            blockchain
        ];

        console.log(general)
        console.log(business)
        console.log(blockchain)

        if(general === null && business === null && blockchain === null) {
            this.setState({ error: "Please select at least one skill." })
        }
        else {
            this.setState({ error: "" })
            editProfile(avatar, interests, nickname).then(
                this._navigate("ProfileComplete")
            );
        }
    };
    _displayError(error) {
        if (error !== "") {
            return <Text style={{ fontSize: 18, color: "red" }}>{ this.state.error }</Text>
        }
    }
    render() {
        const { navigation } = this.props;
        const { Arrow_left, Arrow_right, Logo_horizontal } = Images;
        const { ProfileComplete } = Routes;
        const placeholder = {
            label: "General",
            value: null,
            color: "black"
        };
        return (
            <Screen>
                <View style={Styles.Container}>
                    <Image
                        style={Styles.Image}
                        source={Logo_horizontal}
                        resizeMode="contain"
                    />
                    <View style={Styles.Title}>
                        <Text style={Styles.Text}>
                            Your interests! (1-to-3)
                        </Text>
                    </View>
                    <View
                        style={{ flex: 2, alignItems: "center", width: "100%" }}
                    >
                        <Text style={Styles.Step}>Step 3</Text>
                        <View style={{ width: "80%", height: 50 }}>
                            <Dropdown
                                label="General"
                                data={general}
                                onChangeText={(b, d, v, c) =>
                                    this.setState({ general: v[2]._id })
                                }
                            />
                            <Dropdown
                                label="Business Innovation"
                                data={business}
                                onChangeText={(b, d, v, c) =>
                                    this.setState({ business: v[2]._id })
                                }
                            />
                            <Dropdown
                                label="Blockchain & DLT"
                                data={blockchain}
                                onChangeText={(b, d, v, c) =>
                                    this.setState({ blockchain: v[2]._id })
                                }
                            />
                        </View>
                    </View>
                    <View>{ this._displayError(this.state.error) }</View>
                    <BottomArrows
                        leftIcon={Arrow_left}
                        onPressLeft={() => this.props.navigation.goBack()}
                        rightIcon={Arrow_right}
                        onPressRight={this._onPress}
                    />
                </View>
            </Screen>
        );
    }
}

const Styles = StyleSheet.create({
    Container: {
        flex: 1,
        alignItems: "center",
        backgroundColor: "white"
    },
    Image: {
        width: 180,
        height: 80
    },
    Title: {
        paddingTop: 20,
        paddingBottom: 20
    },
    Step: {
        fontSize: 25,
        fontWeight: "600",
        paddingTop: 20,
        paddingBottom: 20,
        fontFamily: "OpenSans-Regular"
    },
    Text: {
        fontSize: 25,
        fontWeight: "500",
        textAlign: "center",
        fontFamily: "OpenSans-SemiBold"
    }
});

const mapStateToProps = state => {
    return state;
};

export default connect(mapStateToProps)(PickSkills);
