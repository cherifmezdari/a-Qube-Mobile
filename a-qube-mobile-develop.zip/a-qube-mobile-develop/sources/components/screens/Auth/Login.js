import AsyncStorage from "@react-native-community/async-storage";
import React, { Component } from "react";
import {
    Image,
    KeyboardAvoidingView,
    Platform,
    StyleSheet,
    Keyboard,
    Text,
    TouchableOpacity,
    View,
    Dimensions,
    TouchableWithoutFeedback
} from "react-native";
import { connect } from "react-redux";

import { loginFunction, checkToken } from "../../../api/AuthEndpoints";

import Button from "../../common/Button/Button";
import Forms from "../../../constants/Forms";
import Images from "../../../constants/Images";
import Input from "../../common/Input/Input";
import Routes from "../../../constants/Routes";
import Screen from "../../common/Screen/Screen";
import Title from "../../common/Title/Title";

const paddingBehavior = Platform.OS === "ios" ? "padding" : "";

class Login extends Component {
    static navigationOptions = {
        header: null
    };

    constructor(props) {
        super(props);
        this.state = {
            response: [],
            email: "",
            password: "",
            userToken: "",
            error: "",
            profile: ""
        };
    }
    _nav
    igate(screen) {
        const { navigation } = this.props;
        navigation.navigate(screen);
    }

    _displayError(error) {
        if (error !== "") {
            return (
                <Text style={{ fontSize: 18, color: "red" }}>
                    {this.state.error}
                </Text>
            );
        }
    }

    _saveUser() {
        const action = { type: "SAVE_USER", value: this.state };
        this.props.dispatch(action);
    }

    _navigate(screen, subscreen) {
        const { navigation } = this.props;
        navigation.navigate(screen, { previousState: this.state });
        //navigation.navigate(screen, { previousState: this.state }, navigation.navigate({ routeName: subscreen }))
    }

    _onPress = () => {
        if (this.state.email !== "" && this.state.password !== "") {
            loginFunction(this.state.email, this.state.password).then(data => {
                this._login(data);
            });
        }
    };

    _login(data) {
        const { ApplicatioStack, Inqubator, VerifyAccount } = Routes;
        this.setState({ response: data });
        if (data.statusCode == 200) {
            AsyncStorage.setItem("@userToken", data.data.token);
            this.setState({ userToken: data.data.token });
            console.log(this.state);
            this._saveUser();

            checkToken().then(a => {
                console.log(a.is_profile_completed);
                if (a.is_profile_completed === false) {
                    this._navigate("CreateNickname");
                } else {
                    this._navigate("ApplicationDrawer");
                }
            });
        } else if (data.statusCode == 403) {
            this._navigate(VerifyAccount);
        } else if (data.statusCode == 404) {
            this.setState({ error: "Email and password don't match." });
        } else {
            this.setState({ error: "Server issue, please try again" });
        }
    }

    render() {
        const height = Dimensions.get("window").height;
        const width = Dimensions.get("window").width;
        const { Logo_horizontal } = Images;
        const { Placeholders } = Forms;
        const { Email, Password } = Placeholders;
        return (
            <Screen>
                <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
                    <KeyboardAvoidingView
                        style={Styles.Container}
                        behavior={paddingBehavior}
                        enabled
                    >
                        <View style={Styles.Logo}>
                            <Image
                                style={Styles.Image}
                                source={Logo_horizontal}
                                resizeMode="contain"
                            />
                            <Title>Login</Title>
                        </View>
                        <View style={Styles.Form}>
                            <Input
                                keyboardType="email-address"
                                autoCapitalize={"none"}
                                onChangeText={data =>
                                    this.setState({ email: data })
                                }
                                placeholder={Email}
                                onSubmitEditing={Keyboard.dismiss}
                            />
                            <Input
                                autoCapitalize={"none"}
                                onChangeText={data =>
                                    this.setState({ password: data })
                                }
                                secureTextEntry
                                placeholder={Password}
                                onSubmitEditing={Keyboard.dismiss}
                            />
                            <View>{this._displayError(this.state.error)}</View>
                            <TouchableOpacity style={Styles.ForgotPassword} onPress={() => this._navigate("ForgotPassword")}>
                                <Text
                                    style={[
                                        Styles.Information,
                                        { textDecorationLine: "underline" }
                                    ]}
                                >
                                    Forgot your password?
                                </Text>
                            </TouchableOpacity>
                        </View>
                        <View style={Styles.Submit}>
                            <Button
                                styles={Styles.Button}
                                onPress={this._onPress}
                            >
                                Login
                            </Button>
                        </View>
                        <View style={Styles.Register}>
                            <Text style={Styles.Information}>
                                Don"t have an account? Register{" "}
                            </Text>
                            <TouchableOpacity
                                onPress={() => this._navigate("Register")}
                            >
                                <Text
                                    style={[
                                        Styles.Information,
                                        { textDecorationLine: "underline" }
                                    ]}
                                >
                                    here
                                </Text>
                            </TouchableOpacity>
                            <Text style={Styles.Information}>.</Text>
                        </View>
                    </KeyboardAvoidingView>
                </TouchableWithoutFeedback>
            </Screen>
        );
    }
}

const Styles = StyleSheet.create({
    Container: {
        alignItems: "center",
        flex: 1,
        justifyContent: "space-evenly"
    },
    Image: {
        width: Dimensions.get("window").width / 2,
        height: Dimensions.get("window").height / 8
    },
    Form: {
        alignItems: "center",
        flex: 2,
        justifyContent: "space-evenly"
    },
    ForgotPassword: {
        alignSelf: "flex-start",
        paddingLeft: 10
    },
    Information: {
        fontSize: 15,
        fontFamily: "OpenSans-Regular"
    },
    Logo: {
        alignItems: "center",
        flex: 1,
        justifyContent: "space-evenly"
    },
    Submit: {
        alignItems: "center",
        flex: 1,
        justifyContent: "center"
    },
    Register: {
        flexDirection: "row"
    },
    Button: {
        borderRadius: 5
    }
});

const mapStateToProps = state => {
    return state;
};

export default connect(mapStateToProps)(Login);
