import React, { Component } from "react";
import { Image, StyleSheet, Text, View, TouchableOpacity, FlatList } from "react-native";
import { connect } from "react-redux";

import { editProfile } from "../../../api/AuthEndpoints";

import Screen from "../../common/Screen/Screen";
import Images from "../../../constants/Images";
import BottomArrows from "../../common/BottomArrows/BottomArrows";

const general = [
    {
        value: "Project Name + Statement",
        _id: "5d0ecff5c4b98d045ada2dbf"
    },
    {
        value: "Problem & Solution",
        _id: "5d0ecff5c4b98d045ada2dc3"
    },
    {
        value: "Logo",
        _id: "5d0ecff5c4b98d045ada2dd3"
    }
];

const business = [
    {
        value: "Target Audience & GTM",
        _id: "5d0ecff5c4b98d045ada2dc7"
    },
    {
        value: "Business Model & Service",
        _id: "5d0ecff5c4b98d045ada2dcc"
    },
    {
        value: "Investment & Funds",
        _id: "5d0ecff5c4b98d045ada2dd0"
    }
];

const blockchain = [
    {
        value: "Use of Blockchain Tech",
        _id: "5d0ecff5c4b98d045ada2ddc"
    },
    {
        value: "Consensus & Governance",
        _id: "5d0ecff5c4b98d045ada2ddf"
    },
    {
        value: "Token Type + Use & Benefits",
        _id: "5d0ecff5c4b98d045ada2de2"
    },
    {
        value: "Business Model & Tokenomics",
        _id: "5d0ecff5c4b98d045ada2de5"
    },
    {
        value: "Competitive Analysis",
        _id: "5d0ecff5c4b98d045ada2de8"
    }
];

class NewPickSkills extends Component {
    static navigationOptions = {
        header: null
    };

    constructor(props) {
        super(props);
        this.state = {
            skills: [],
            business: null,
            general: null,
            blockchain: null,
            error: "",
            skillCategories: general,
            generalSelected: true,
            businessSelected: false,
            blockchainSelected: false
        };
    }

    _navigate(screen) {
        const { navigation } = this.props;
        navigation.navigate(screen);
    }

    _onPress = () => {
        const { general, business, blockchain, skills } = this.state
        const nickname = this.props.navigation.state.params.previousState
            .nickName;
        const avatar = this.props.navigation.state.params.previousState.avatar
            ._id;
        const interests = [];

        for( var i = 0; i < skills.length; i++ ){
            console.log(skills[i]._id);
            interests.push(skills[i]._id)
        }

        console.log(interests);

        //if (general === null && business === null && blockchain === null) {
        //    this.setState({ error: "Please select at least one skill." })
        //}
        //else {
        //    this.setState({ error: "" })
        //    console.log(this.state)
            //editProfile(avatar, interests, nickname).then(
            //    this._navigate("ProfileComplete")
            //);
        //}

        if( skills.length < 1 ) { 
            this.setState({ error: "Please select at least one skill." })
        } else if( skills.length > 3 ) {
            this.setState({ error: "You have selected too many skills. Please select between 1 to 3 skills." })
        } else {
            this.setState({ error: "" })
            console.log(this.state)
            editProfile(avatar, interests, nickname).then(
                this._navigate("ProfileComplete")
            );
        }
    };

    _displayError(error) {
        if (error !== "") {
            return <Text style={{ fontSize: 18, color: "red" }}>{this.state.error}</Text>
        }
    }

    _renderItem = ({ item }) => {
        return (
            <TouchableOpacity onPress={() => {
                const SkillsIndex = this.state.skills.findIndex(index => index._id === item._id)
                if (SkillsIndex == -1) {
                    this.setState(prevState => ({
                        skills: [...prevState.skills, { value: item.value, _id: item._id }]
                    }))
                }
            }}>
                <Text>{item.value}</Text>
            </TouchableOpacity>
        )
    };

    removeItem(skillPicked) {
        console.log(skillPicked)
        const items = this.state.skills.filter(item => item.value !== skillPicked.value);
        this.setState({ skills: items });
    }

    _renderSkills = ({ item }) => {
        return (
            <TouchableOpacity onPress={() => this.removeItem(item)} style={{ flexDirection: "row", justifyContent: "space-between" }}>
                <Text>{item.value}</Text>
                <Text>Remove</Text>
            </TouchableOpacity>
        )
    }

    render() {
        const { Arrow_left, Arrow_right, Logo_horizontal } = Images;
        const { generalSelected, businessSelected, blockchainSelected } = this.state

        const isGeneralSelected = generalSelected ? "darkgray" : "lightgray"
        const isBusinessSelected = businessSelected ? "darkgray" : "lightgray"
        const isBlockchainSelected = blockchainSelected ? "darkgray" : "lightgray"

        console.log(this.state)

        return (
            <Screen>
                <View style={Styles.Container}>
                    <Image
                        style={Styles.Image}
                        source={Logo_horizontal}
                        resizeMode="contain"
                    />
                    <View style={Styles.Title}>
                        <Text style={Styles.Text}>
                            Your interests! (1-to-3)
                        </Text>
                    </View>
                    <View
                        style={{ flex: 2, alignItems: "center", width: "100%" }}
                    >
                        <Text style={Styles.Step}>Step 3</Text>

                        <View style={{ flex: 1, width: "90%" }}>
                            <View style={{ flex: 1 }}>

                                <View style={{ flexDirection: "row", alignSelf: "center", justifyContent: "center", paddingBottom: 5 }}>
                                    <TouchableOpacity onPress={() => this.setState({ skillCategories: general, generalSelected: true, businessSelected: false, blockchainSelected: false })}
                                        style={{ flex: 1, backgroundColor: isGeneralSelected, borderRadius: 5 }}>
                                        <Text style={Styles.TitleText}>General</Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity onPress={() => this.setState({ skillCategories: business, generalSelected: false, businessSelected: true, blockchainSelected: false })}
                                        style={{ flex: 1, backgroundColor: isBusinessSelected, borderRadius: 5 }}>
                                        <Text style={Styles.TitleText}>Business Innovation</Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity onPress={() => this.setState({ skillCategories: blockchain, generalSelected: false, businessSelected: false, blockchainSelected: true })}
                                        style={{ flex: 1, backgroundColor: isBlockchainSelected, borderRadius: 5 }}>
                                        <Text style={Styles.TitleText}>Blockchain & DLT</Text>
                                    </TouchableOpacity>
                                </View>
                                <View style={{ flex: 1 }}>
                                    <FlatList
                                        data={this.state.skillCategories}
                                        renderItem={this._renderItem}
                                        keyExtractor={(item, index) => index.toString()}
                                    />
                                </View>

                            </View>

                            <View style={{ flex: 1 }}>
                                <Text>Your Selection</Text>

                                <View>
                                    <FlatList
                                        data={this.state.skills}
                                        renderItem={this._renderSkills}
                                        keyExtractor={(item, index) => index.toString()}
                                    />
                                </View>
                            </View>
                        </View>
                    </View>
                    <View>{this._displayError(this.state.error)}</View>
                    <BottomArrows
                        leftIcon={Arrow_left}
                        onPressLeft={() => this.props.navigation.goBack()}
                        rightIcon={Arrow_right}
                        onPressRight={this._onPress}
                    />
                </View>
            </Screen>
        );
    }
}

const Styles = StyleSheet.create({
    Container: {
        flex: 1,
        alignItems: "center",
        backgroundColor: "white"
    },
    Image: {
        width: 180,
        height: 80
    },
    Title: {
        paddingTop: 20,
        paddingBottom: 20
    },
    Step: {
        fontSize: 25,
        fontWeight: "600",
        paddingTop: 20,
        paddingBottom: 20,
        fontFamily: "OpenSans-Regular"
    },
    Text: {
        fontSize: 25,
        fontWeight: "500",
        textAlign: "center",
        fontFamily: "OpenSans-SemiBold"
    },
    TitleText: {
        fontFamily: "OpenSans-Regular",
        textAlign: "center"
    }
});

const mapStateToProps = state => {
    return state;
};

export default connect(mapStateToProps)(NewPickSkills);
