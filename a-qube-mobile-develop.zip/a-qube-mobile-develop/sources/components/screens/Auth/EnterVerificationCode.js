import React, { Component } from "react";
import {
    Image,
    KeyboardAvoidingView,
    Platform,
    Keyboard,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
    TouchableWithoutFeedback,
    Modal,
    Dimensions
} from "react-native";

import { CheckPasscode, forgetPassword } from "../../../api/AuthEndpoints";

import Screen from "../../common/Screen/Screen";
import Button from "../../common/Button/Button";
import Forms from "../../../constants/Forms";
import Images from "../../../constants/Images";
import InputVerification from "../../common/Input/InputVerification";
import Colors from "../../../constants/Colors";
import Title from "../../common/Title/Title";
import BottomArrows from "../../common/BottomArrows/BottomArrows";

const dimensions = Dimensions.get("window");

const marginHeight = Math.round(dimensions.height / 4);

const paddingBehavior = Platform.OS === "ios" ? "padding" : "";

export default class EnterVerificationCode extends Component {
    static navigationOptions = {
        header: null
    };
    _navigate(screen) {
        const { navigation } = this.props;
        navigation.navigate(screen);
    }

    _displayError(error) {
        if (error !== "") {
            return (
                <Text
                    style={{
                        fontSize: 16,
                        color: "red",
                        fontFamily: "OpenSans-Regular"
                    }}
                >
                    {this.state.error}
                </Text>
            );
        }
    }

    constructor(props) {
        super(props);
        this.state = { 
            passcode: "", 
            email: this.props.navigation.state.params.previousState.email, 
        };
    }
    _verifypasscode(data) {
        console.log(data)
            if (data === 200) {
              this.props.navigation.navigate("CreateNewPassword", {previousState: this.state})
            } else  {
                this.setState({ error: "Passcode is invalid." });
            }
        }


    render() {

        const { Logo_horizontal, Arrow_left } = Images
        const { Placeholders } = Forms;
        const { Code } = Placeholders;
        const email= this.props.navigation.state.params.previousState.email
        return (
            <Screen>
                <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
                    <KeyboardAvoidingView
                        style={{ flex: 1 }}
                        behavior={paddingBehavior}
                        enabled
                    >
                        <View style={Styles.Container}>
                            <View style={Styles.Logo}>
                                <Image
                                    style={Styles.Image}
                                    source={Logo_horizontal}
                                    resizeMode="contain"
                                />
                                <Title styles={{ textAlign: "center" }}>
                                    Forgot your password?
                                </Title>
                            </View>
                            <View style={Styles.Instructions}>
                                <Text style={Styles.Paragraph}>
                                    Get code via SMS to create new password.
                                </Text>
                            </View>
                            <View
                                style={{
                                    flexDirection: "row",
                                    justifyContent: "center",
                                    alignItems: "center"
                                }}
                            >
                                <InputVerification
                                    onSubmitEditing={Keyboard.dismiss}
                                    keyboardType="numeric"
                                    placeholder={"Insert code"}
                                    onChangeText={data =>
                                        this.setState({ passcode: data })
                                    }
                                />
                                <Button
                                    styles={Styles.Button}
                                    onPress={()=>forgetPassword(this.state.email)}
                                >
                                    Get new code
                                </Button>
                            </View>


                            {this._displayError(this.state.error)}

                            <Button
                                styles={Styles.Button}
                                onPress={()=>
                                  CheckPasscode(email,this.state.passcode).then((d) => this._verifypasscode(d))
}
                            >
                                Send
                            </Button>
                        </View>
                        <BottomArrows
                            onPressLeft={() => this.props.navigation.goBack()}
                            leftIcon={Arrow_left}
                        />
                    </KeyboardAvoidingView>
                </TouchableWithoutFeedback>
            </Screen>
        );
    }
}
const { Eerie, Gray, Pink } = Colors;
const Styles = StyleSheet.create({
    Container: {
        flex: 1,
        alignItems: "center",
        justifyContent: "space-evenly"
    },
    Image: {
        width: Dimensions.get("window").width / 2,
        height: Dimensions.get("window").height / 8
    },
    Logo: {
        alignItems: "center",
        justifyContent: "center"
    },
    Title: {
        paddingTop: 20,
        paddingBottom: 20
    },
    Instructions: {
        paddingLeft: 20,
        paddingRight: 20,
        paddingBottom: 20,
        paddingTop: 30
    },
    Text: {
        fontSize: 25,
        fontWeight: "500",
        textAlign: "center",
        fontFamily: "OpenSans-Regular"
    },
    Paragraph: {
        fontSize: 18,
        fontFamily: "OpenSans-Regular"
    },
    ResendCode: {
        alignSelf: "flex-start",
        paddingLeft: 40
    },
    Resend: {
        textDecorationLine: "underline",
        fontFamily: "OpenSans-Regular"
    },
    Button: {
        borderRadius: 10,
        borderColor: "red"
    },
    ModalContainer: {
        alignItems: "center",
        backgroundColor: Gray,
        borderRadius: 10,
        justifyContent: "center",
        marginTop: marginHeight,
        marginBottom: marginHeight,
        marginLeft: 10,
        marginRight: 10,
        borderColor: "black",
        borderWidth: 2
    }
});
