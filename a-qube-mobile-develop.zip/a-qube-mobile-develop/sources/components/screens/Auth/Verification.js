import AsyncStorage from "@react-native-community/async-storage"
import React, { Component } from "react"
import { ActivityIndicator } from "react-native"

import { authenticated, checkToken } from "../../../api/AuthEndpoints";

export default class Verification extends Component {
    constructor(props) {
        super(props)
        this.state = {
            hasLoaded: false,
            isAuthenticated: false,
            profileComplete: false,
            statusCode: 401
        }
    }

    componentWillMount() {
        this.getAuthenticationTokenAsync()
    }

    getAuthenticationTokenAsync = async () => {
        const token = await AsyncStorage.getItem("@userToken")
        await authenticated().then(v => this.setState({ statusCode: v.statusCode }))

        await checkToken().then(v => this.setState({ profileComplete: v.is_profile_completed }))

        if (token && this.state.statusCode === 200) {
            this.setState({ isAuthenticated: true })
        }
        this.setState({ hasLoaded: true })
    }

    render() {
        const { hasLoaded, isAuthenticated, profileComplete } = this.state
        if (hasLoaded) {
            this.props.navigation.navigate(isAuthenticated ? (profileComplete ? "ApplicationDrawer" : "CreateProfileStack") : "AuthenticationStack")
        }
        return <ActivityIndicator size="large" />
    }
}
