import React, { Component } from "react";
import {
    Dimensions,
    Image,
    KeyboardAvoidingView,
    Keyboard,
    Platform,
    StyleSheet,
    Text,
    View,
    TouchableWithoutFeedback
} from "react-native";

import { NewPassword } from "../../../api/AuthEndpoints";

import Button from "../../common/Button/Button";
import Forms from "../../../constants/Forms";
import Images from "../../../constants/Images";
import InputRegister from "../../common/Input/InputRegister";
import Routes from "../../../constants/Routes";
import Screen from "../../common/Screen/Screen";
import Title from "../../common/Title/Title";
import BottomArrows from "../../common/BottomArrows/BottomArrows";

const paddingBehavior = Platform.OS === "ios" ? "padding" : "";

export default class CreateNewPassword extends Component {
    static navigationOptions = {
        header: null
    };
    constructor(props) {
        super(props);
        this.state = {
            email: this.props.navigation.state.params.previousState.email,
            password: "",
            passwordConfirm: "",
            passcode: this.props.navigation.state.params.previousState.passcode,
            email_Validate: false,
            password_Validate: false,
            error: "",
            passwordMatching: true
        };
    }
    _navigate(screen) {
        const { navigation } = this.props;
        navigation.navigate(screen, { previousState: this.state });
    }
    _displayError() {
        const { error } = this.state;
        if (error !== "") {
            return <Text style={{ fontSize: 16, color: "red" }}>{error}</Text>;
        }
    }
    _onPress = () => {
        const {
            email,
            password,
            passcode,
            passwordConfirm,
            email_Validate,
            password_Validate
        } = this.state;
        if (
            email !== "" &&
            password !== "" &&
            passwordConfirm !== "" &&
            email_Validate == false &&
            password_Validate == false
        ) {
            if (passwordConfirm == password) {
                NewPassword(email, passcode, password).then(data =>
                    this._signUp(data.status)
                );
            } else {
                this.setState({ error: "Passwords doesn't match" });
            }
        } else {
            console.log("Something went wrong");
        }
    };
    _signUp(data) {
        console.log(data)
        const { email, password, passcode } = this.state;
        if (email !== "" && password !== "" && passcode !== "") {
            if (data === 200) {
                this._navigate("Login");
            } else {
                this.setState({ error: "Please try again." });
            }
        }
    }
    _validate(text, type) {
        const regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        switch (type) {
            case "password":
                this.setState({ password: text });
                if (text.length >= 8) {
                    this.setState({ password_Validate: false });
                } else {
                    this.setState({ password_Validate: true });
                }
                break;
            default:
                null;
        }
    }
    render() {
        const { Logo_horizontal, Arrow_left } = Images;
        console.log(this.props)

        return (
            <Screen>
                <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
                    <KeyboardAvoidingView
                        style={Styles.Container}
                        behavior={paddingBehavior}
                        enabled
                    >
                        <View style={{ flex: 1 }}>
                            <View style={Styles.Logo}>
                                <Image
                                    style={Styles.Image}
                                    source={Logo_horizontal}
                                    resizeMode="contain"
                                />
                                <Title styles={{ textAlign: "center" }}>
                                    Create your new password
                                </Title>
                            </View>
                            <View style={Styles.Form}>
                                <InputRegister
                                    onSubmitEditing={Keyboard.dismiss}
                                    autoCapitalize={"none"}
                                    onChangeText={text =>
                                        this._validate(text, "password")
                                    }
                                    placeholder="New Password"
                                    secureTextEntry
                                    validate={this.state.password_Validate}
                                />
                                <InputRegister
                                    onSubmitEditing={Keyboard.dismiss}
                                    autoCapitalize={"none"}
                                    onChangeText={text =>
                                        this.setState({ passwordConfirm: text })
                                    }
                                    placeholder="Repeat Password"
                                    secureTextEntry
                                />
                                {this._displayError(this.state.error)}
                            </View>
                            <View style={Styles.Submit}>
                                <Button
                                    styles={Styles.Button}
                                    onPress={this._onPress}
                                >
                                    Confirm
                                </Button>
                            </View>
                        </View>
                        <BottomArrows
                            onPressLeft={() => navigation.goBack()}
                            leftIcon={Arrow_left}
                        />
                    </KeyboardAvoidingView>
                </TouchableWithoutFeedback>
            </Screen>
        );
    }
}

const Styles = StyleSheet.create({
    Conditions: {
        alignItems: "center",
        justifyContent: "center"
    },
    Container: {
        alignItems: "center",
        flex: 1,
        justifyContent: "space-evenly"
    },
    Image: {
        width: Dimensions.get("window").width / 2,
        height: Dimensions.get("window").height / 8
    },
    Form: {
        alignItems: "center",
        flex: 2,
        justifyContent: "space-evenly"
    },
    Information: {
        fontSize: 15,
        fontFamily: "OpenSans-Regular"
    },
    Logo: {
        alignItems: "center",
        flex: 1,
        justifyContent: "center"
    },
    Terms: {
        color: "blue",
        textDecorationLine: "underline",
        fontFamily: "OpenSans-Regular"
    },
    Submit: {
        alignItems: "center",
        flex: 1,
        justifyContent: "center"
    },
    Button: {
        borderRadius: 10
    }
});
