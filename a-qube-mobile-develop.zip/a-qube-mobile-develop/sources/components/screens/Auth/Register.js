import React, { Component } from "react";
import {
    Dimensions,
    Image,
    KeyboardAvoidingView,
    Keyboard,
    Platform,
    StyleSheet,
    Text,
    View,
    TouchableWithoutFeedback
} from "react-native";

import { signUpFunction } from "../../../api/AuthEndpoints";

import Button from "../../common/Button/Button";
import Forms from "../../../constants/Forms";
import Images from "../../../constants/Images";
import InputRegister from "../../common/Input/InputRegister";
import Routes from "../../../constants/Routes";
import Screen from "../../common/Screen/Screen";
import Title from "../../common/Title/Title";

const paddingBehavior = Platform.OS === "ios" ? "padding" : "";

export default class Register extends Component {
    static navigationOptions = {
        header: null
    };

    constructor(props) {
        super(props);
        this.state = {
            email: "",
            password: "",
            passwordConfirm: "",
            email_Validate: false,
            password_Validate: false,
            error: "",
            passwordMatching: true
        };
    }

    _navigate(screen) {
        const { navigation } = this.props;
        navigation.navigate(screen, { previousState: this.state });
    }

    _displayError() {
        const { error } = this.state;
        if (error !== "") {
            return <Text style={{ fontSize: 16, color: "red" }}>{error}</Text>;
        }
    }
    _onPress = () => {
        const {
            email,
            password,
            passwordConfirm,
            email_Validate,
            password_Validate
        } = this.state;

        if (
            email !== "" &&
            password !== "" &&
            passwordConfirm !== "" &&
            email_Validate == false &&
            password_Validate == false
        ) {
            if (passwordConfirm == password) {
                signUpFunction(password, email).then(data =>
                    this._signUp(data.status)
                );
            } else {
                this.setState({ error: "Passwords doesn't match" });
            }
        } else {
            console.log("Something went wrong");
        }
    };

    _signUp(data) {
        const { email, password } = this.state;
        const { EnterCode } = Routes;
        if (email !== "" && password !== "") {
            if (data == 201 || data == 403) {
                this._navigate(EnterCode);
            } else if (data == 409) {
                this.setState({ error: "Email already exists, Login now." });
                this._navigate("Login");
            } else {
                this.setState({ error: "Server issue, please try again." });
            }
        }
    }

    _validate(text, type) {
        const regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        switch (type) {
            case "email":
                this.setState({ email: text });
                if (regex.test(text)) {
                    this.setState({ email_Validate: false });
                } else {
                    this.setState({ email_Validate: true });
                }
                break;
            case "password":
                this.setState({ password: text });
                if (text.length >= 8) {
                    this.setState({ password_Validate: false });
                } else {
                    this.setState({ password_Validate: true });
                }
                break;
            default:
                null;
        }
    }

    render() {
        const { Logo_horizontal } = Images;
        const { Placeholders } = Forms;
        const { ConfirmPassword, Email, Password } = Placeholders;
        return (
            <Screen>
                <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
                    <KeyboardAvoidingView
                        style={Styles.Container}
                        behavior={paddingBehavior}
                        enabled
                    >
                        <View style={{ flex: 1 }}>
                            <View style={Styles.Logo}>
                                <Image
                                    style={Styles.Image}
                                    source={Logo_horizontal}
                                    resizeMode="contain"
                                />
                                <Title>Create an account</Title>
                            </View>
                            <View style={Styles.Form}>
                                <InputRegister
                                    keyboardType="email-address"
                                    onSubmitEditing={Keyboard.dismiss}
                                    autoCapitalize={"none"}
                                    placeholder={Email}
                                    validate={this.state.email_Validate}
                                    onChangeText={text =>
                                        this._validate(text, "email")
                                    }
                                />
                                <InputRegister
                                    onSubmitEditing={Keyboard.dismiss}
                                    autoCapitalize={"none"}
                                    onChangeText={text =>
                                        this._validate(text, "password")
                                    }
                                    placeholder={Password}
                                    secureTextEntry
                                    validate={this.state.password_Validate}
                                />
                                <InputRegister
                                    onSubmitEditing={Keyboard.dismiss}
                                    autoCapitalize={"none"}
                                    onChangeText={text =>
                                        this.setState({ passwordConfirm: text })
                                    }
                                    placeholder={ConfirmPassword}
                                    secureTextEntry
                                />
                                {this._displayError(this.state.error)}
                            </View>
                            <View style={Styles.Conditions}>
                                <Text style={Styles.Information}>
                                    By creating an account you agree to our
                                </Text>
                                <Text style={Styles.Information}>
                                    <Text style={Styles.Terms}>
                                        Terms of Service{" "}
                                    </Text>
                                    <Text
                                        style={{
                                            fontFamily: "OpenSans-Regular"
                                        }}
                                    >
                                        and{" "}
                                    </Text>
                                    <Text style={Styles.Terms}>
                                        Privacy Police
                                    </Text>
                                </Text>
                            </View>
                            <View style={Styles.Submit}>
                                <Button
                                    styles={Styles.Button}
                                    onPress={this._onPress}
                                >
                                    Register
                                </Button>
                            </View>
                        </View>
                    </KeyboardAvoidingView>
                </TouchableWithoutFeedback>
            </Screen>
        );
    }
}

const Styles = StyleSheet.create({
    Conditions: {
        alignItems: "center",
        justifyContent: "center"
    },
    Container: {
        alignItems: "center",
        flex: 1,
        justifyContent: "space-evenly"
    },
    Image: {
        width: Dimensions.get("window").width / 2,
        height: Dimensions.get("window").height / 8
    },
    Form: {
        alignItems: "center",
        flex: 2,
        justifyContent: "space-evenly"
    },
    Information: {
        fontSize: 15,
        fontFamily: "OpenSans-Regular"
    },
    Logo: {
        alignItems: "center",
        flex: 1,
        justifyContent: "center"
    },
    Terms: {
        color: "blue",
        textDecorationLine: "underline",
        fontFamily: "OpenSans-Regular"
    },
    Submit: {
        alignItems: "center",
        flex: 1,
        justifyContent: "center"
    },
    Button: {
        borderRadius: 10
    }
});
