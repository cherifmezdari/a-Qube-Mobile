import React, { Component } from "react";
import {
    Image,
    KeyboardAvoidingView,
    Keyboard,
    Platform,
    StyleSheet,
    Text,
    TouchableWithoutFeedback,
    View
} from "react-native";

import { addMobile } from "../../../api/AuthEndpoints";

import Screen from "../../common/Screen/Screen";
import Button from "../../common/Button/Button";
import Forms from "../../../constants/Forms";
import Images from "../../../constants/Images";
import Input from "../../common/Input/Input";
import Routes from "../../../constants/Routes";

const { Logo_horizontal } = Images;

const paddingBehavior = Platform.OS === "ios" ? "padding" : "";

const marginLeft = Platform.OS === "android" ? 20 : 0;

export default class VerifyAccount extends Component {
    static navigationOptions = ({ navigation }) => {
        return {
            headerTitle: (
                <Image
                    style={{ height: 50, width: 100, marginLeft: marginLeft }}
                    resizeMode="contain"
                    source={Logo_horizontal}
                />
            ),
            headerLeft: null
        };
    };

    constructor(props) {
        super(props);
        this.state = {
            Mobile: "",
            password: this.props.navigation.state.params.previousState.password,
            email: this.props.navigation.state.params.previousState.email,
            error: ""
        };
    }

    _onPress = () => {
        const email = this.props.navigation.state.params.previousState.email;
        const password = this.props.navigation.state.params.previousState
            .password;
        if (this.state.Mobile !== "") {
            addMobile(email, password, this.state.Mobile).then(data =>
                this._sendMobileNumber(data)
            );
        }
    };
    
    _sendMobileNumber(data) {
        //console.warn(data)
        const { EnterCode } = Routes;
        if (data == 200) {
            this._navigate("EnterCode");
        } else if (data == 409) {
            this.setState({ error: "Mobile number already exists." });
            //console.warn(this.state.error)
        } else {
            this._navigate(EnterCode);
        }
    }
    _navigate(screen) {
        const { navigation } = this.props;
        navigation.navigate(screen, { previousState: this.state });
    }
    render() {
        const { Placeholders } = Forms;
        const { Phone } = Placeholders;
        return (
            <Screen>
                <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
                    <KeyboardAvoidingView
                        style={{ flex: 1 }}
                        behavior={paddingBehavior}
                        enabled
                    >
                        <View style={Styles.Container}>
                            <View style={Styles.Title}>
                                <Text style={Styles.Text}>
                                    Verify your account
                                </Text>
                            </View>
                            <View style={Styles.Instructions}>
                                <Text style={Styles.Paragraph}>
                                    Enter your phone number that we can use to
                                    verify your identity via text message.
                                </Text>
                            </View>
                            <Input
                                onSubmitEditing={Keyboard.dismiss}
                                keyboardType="numeric"
                                onChangeText={data =>
                                    this.setState({ Mobile: data })
                                }
                                placeholder={Phone}
                            />
                            <Text style={[Styles.Paragraph, { color: 'red' }]}>{this.state.error}</Text>
                            <Button
                                styles={Styles.Button}
                                onPress={this._onPress}
                            >
                                Send code
                            </Button>
                        </View>
                    </KeyboardAvoidingView>
                </TouchableWithoutFeedback>
            </Screen>
        );
    }
}

const Styles = StyleSheet.create({
    Container: {
        flex: 1,
        alignItems: "center"
    },
    Image: {
        width: 180,
        height: 80
    },
    Title: {
        paddingTop: 20,
        paddingBottom: 20
    },
    Instructions: {
        paddingLeft: 20,
        paddingRight: 20,
        paddingBottom: 20
    },
    Text: {
        fontSize: 25,
        fontWeight: "500",
        textAlign: "center",
        fontFamily: "OpenSans-SemiBold"
    },
    Paragraph: {
        fontSize: 18,
        fontFamily: "OpenSans-Regular"
    },
    Button: {
        marginTop: 80,
        borderRadius: 10,
        borderColor: "red",
        fontFamily: "OpenSans-Regular"
    }
});
