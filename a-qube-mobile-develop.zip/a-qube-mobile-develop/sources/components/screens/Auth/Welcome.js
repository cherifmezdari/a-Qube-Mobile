import React, { Component } from "react";
import { Image, StyleSheet, View, Dimensions } from "react-native";

import Button from "../../common/Button/Button";
import Paragraph from "../../common/Paragraph/Paragraph";
import Screen from "../../common/Screen/Screen";
import Title from "../../common/Title/Title";
import Colors from "../../../constants/Colors";

import Images from "../../../constants/Images";
import Routes from "../../../constants/Routes";

export default class Welcome extends Component {
    static navigationOptions = {
        header: null
    };
    navigate(screen) {
        const { navigation } = this.props;
        navigation.navigate(screen);
    }
    render() {
        const { Logo, Underline, Qube_Border } = Images;
        const { Login, Register } = Routes;
        return (
            <Screen qube_Border={Qube_Border}>
                <View style={Styles.Message}>
                    <Image style={Styles.Image} source={Logo} />
                    <View
                        style={{
                            width: "100%",
                            alignItems: "center",
                            justifyContent: "center"
                        }}
                    >
                        <Title
                            styles={{
                                width: Dimensions.get("window").width / 2,
                                textAlign: "center"
                            }}
                        >
                            Welcome to a-Qube!
                        </Title>
                        <Image
                            style={Styles.UnderlineImage}
                            source={Underline}
                        />
                    </View>
                    <View style={Styles.Paragraph}>
                        <Paragraph styles={Styles.Paragraph}>
                            We are building the first decentralized Marketplace
                            of Ideas, a peer-to-peer Mobile Incubator where
                            Ideas have value.
                        </Paragraph>
                    </View>
                </View>
                <View style={Styles.Action}>
                    <Button
                        styles={Styles.Button}
                        onPress={() => this.navigate(Login)}
                    >
                        Login
                    </Button>
                    <Button
                        styles={Styles.Button}
                        onPress={() => this.navigate(Register)}
                    >
                        Register
                    </Button>
                </View>
            </Screen>
        );
    }
}

const { Granite } = Colors;
const Styles = StyleSheet.create({
    Action: {
        flex: 1,
        flexDirection: "row",
        justifyContent: "space-evenly"
    },
    Image: {
        width: Dimensions.get("window").width / 2,
        height: Dimensions.get("window").height / 3.5
    },
    Title: {
        fontWeight: "400",
        fontFamily: "OpenSans-SemiBold"
    },
    UnderlineImage: {
        width: Dimensions.get("window").width / 1.3
    },
    Message: {
        alignItems: "center",
        flex: 2,
        justifyContent: "space-evenly"
    },
    Paragraph: {
        textAlign: "center",
        width: Dimensions.get("window").width / 1.3,
        color: Granite,
        fontWeight: "100",
        fontFamily: "OpenSans-Regular"
    },
    Button: {
        borderRadius: 10,
        fontFamily: "OpenSans-Regular"
    }
});
