import React, { Component } from "react";
import {
    Dimensions,
    Image,
    StyleSheet,
    Text,
    TouchableOpacity,
    View
} from "react-native";
import Swiper from "react-native-web-swiper";
import { connect } from "react-redux";

import { fetchAvatars } from "../../../api/AuthEndpoints";

import Screen from "../../common/Screen/Screen";
import Images from "../../../constants/Images";
import BottomArrows from "../../common/BottomArrows/BottomArrows";

class ChooseAvatar extends Component {
    static navigationOptions = {
        header: null
    };
    constructor(props) {
        super(props);
        this.state = {
            entries: [],
            avatar: "",
            nickName: this.props.navigation.state.params.nickName,
            error: "",
            borderColor: "gray"
        };
    }
    async componentDidMount() {
        fetchAvatars().then(avatars => this.setState({ entries: avatars }));
        //console.log(this.state.entries);
    }
    _navigate(screen) {
        const { navigation } = this.props;
        navigation.navigate(screen, { previousState: this.state });
    }
    _saveUser() {
        const action = { type: "SAVE_USER", value: this.state };
        this.props.dispatch(action);
    }
    _nextScreen() {
        this._saveUser();
        this._navigate("NewPickSkills");
    }
    _onPress = () => {
        if (this.state.avatar === "") {
            this.setState({ error: "Please tap on the avatar you want to pick." });
        } else if (this.state.avatar !== "") {
            this.setState({ error: "" });
            this._nextScreen();
        }
    };
    render() {
        const { entries } = this.state;
        const { Logo_horizontal, Arrow_left, Arrow_right } = Images;
        return (
            <Screen>
                <View style={Styles.Container}>
                    <Image
                        style={Styles.Image}
                        source={Logo_horizontal}
                        resizeMode="contain"
                    />
                    <View style={Styles.Title}>
                        <Text style={Styles.Text}>Choose your avatar</Text>
                    </View>
                    <View>
                        <Text style={Styles.Step}>Step 2</Text>
                    </View>
                    <View style={Styles.Avatars}>
                        <Swiper onIndexChanged={() => this.setState({ avatar: "", borderColor: "gray" })}>
                            {entries.map((entry, index) => (
                                <TouchableOpacity
                                    key={index}
                                    style={Styles.AvatarImage}
                                    onPress={() =>
                                        this.setState({ avatar: entry, borderColor: "green" })
                                    }
                                >
                                    <View style={{
                                        height: Dimensions.get("window").width / 2.5,
                                        width: Dimensions.get("window").width / 2.5,
                                        borderRadius: (Dimensions.get("window").width / 2.5) / 2,
                                        borderColor: this.state.borderColor,
                                        borderWidth: 8,
                                        justifyContent: "center",
                                        alignItems: "center"
                                    }}>
                                    <Image
                                        style={{
                                            height: Dimensions.get("window").width / 3,
                                            width: Dimensions.get("window").width / 3,
                                            borderRadius: (Dimensions.get("window").width / 3) / 2,
                                        }}
                                        source={{ uri: entry.url }}
                                        resizeMode="cover"
                                    />
                                    </View>
                                </TouchableOpacity>
                            ))}
                        </Swiper>
                    </View>
                    <Text style={[Styles.Paragraph, { color: "red" }]}>
                        {this.state.error}
                    </Text>
                    <BottomArrows
                        styles={{ flex: 0, marginBottom: 30}}
                        leftIcon={Arrow_left}
                        onPressLeft={() => this.props.navigation.goBack()}
                        rightIcon={Arrow_right}
                        onPressRight={this._onPress}
                    />
                </View>
            </Screen>
        );
    }
}

const Styles = StyleSheet.create({
    Container: {
        flex: 1,
        alignItems: "center"
    },
    Image: {
        width: 180,
        height: 80
    },
    Title: {
        paddingTop: 20,
        paddingBottom: 20,
        fontFamily: "OpenSans-SemiBold"
    },
    Text: {
        fontSize: 25,
        fontWeight: "500",
        textAlign: "center"
    },
    Content: {
        alignItems: "center",
        justifyContent: "center"
    },
    Carousel: {
        flex: 1
    },
    Step: {
        fontSize: 25,
        fontWeight: "600",
        paddingTop: 20,
        paddingBottom: 20,
        fontFamily: "OpenSans-SemiBold"
    },
    Avatars: {
        flex: 1,
        width: "100%",
        flexDirection: "row",
        justifyContent: "space-evenly",
        paddingTop: 40
    },
    AvatarImage: {
        flex: 1,
        alignItems: "center",
    },
    Paragraph: {
        fontSize: 18,
        paddingBottom: 20,
        fontFamily: "OpenSans-Regular"
    }
});

const mapStateToProps = state => {
    return state;
};

export default connect(mapStateToProps)(ChooseAvatar);
