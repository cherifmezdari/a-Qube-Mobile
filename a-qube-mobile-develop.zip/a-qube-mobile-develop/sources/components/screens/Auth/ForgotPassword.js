import React, { Component } from "react";
import {
    Image,
    KeyboardAvoidingView,
    Platform,
    Keyboard,
    StyleSheet,
    Text,
    View,
    TouchableWithoutFeedback
} from "react-native";

import { forgetPassword } from "../../../api/AuthEndpoints";

import Screen from "../../common/Screen/Screen";
import Button from "../../common/Button/Button";
import Forms from "../../../constants/Forms";
import Images from "../../../constants/Images";
import InputRegister from "../../common/Input/InputRegister";
import BottomArrows from "../../common/BottomArrows/BottomArrows"

const { Logo_horizontal } = Images;

const paddingBehavior = Platform.OS === "ios" ? "padding" : "";
const marginLeft = Platform.OS === "android" ? 20 : 0;

export default class ForgotPassword extends Component {
    static navigationOptions = () => {
        return {
            headerTitle: (
                <Image
                    style={{ height: 50, width: 100, marginLeft: marginLeft }}
                    resizeMode="contain"
                    source={Logo_horizontal}
                />
            ),
            headerLeft: null
        };
    };
    _navigate(screen) {
        const { navigation } = this.props;
        navigation.navigate(screen);
    }
    constructor(props) {
        super(props);
        this.state = {
            email: "",
            error:""
        };
    }
    onPress(data){
      if(data.status==200)
      {
        this.props.navigation.navigate("EnterVerificationCode",{previousState:this.state})
      }
      else {
        this.setState({error:"Email doesn't exist"})
      }
    }
    _displayError(error) {
        if (error !== "") {
            return (
                <Text
                    style={{
                        fontSize: 16,
                        color: "red",
                        fontFamily: "OpenSans-Regular"
                    }}
                >
                    {this.state.error}
                </Text>
            );
        }
    }
    render() {
        const { Logo_horizontal, Arrow_left } = Images;
        const { Placeholders } = Forms;
        const { Email } = Placeholders;
        return (
            <Screen>
                <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
                    <KeyboardAvoidingView
                        style={{ flex: 1 }}
                        behavior={paddingBehavior}
                        enabled
                    >
                        <View style={Styles.Container}>
                            <View style={Styles.Title}>
                                <Text style={Styles.Text}>
                                    Forgot your password?
                                </Text>
                            </View>
                            <View style={Styles.Instructions}>
                                <Text style={Styles.Paragraph}>
                                    Write your email address to create a new
                                    one.
                                </Text>
                            </View>
                            <InputRegister
                                keyboardType="email-address"
                                onSubmitEditing={Keyboard.dismiss}
                                autoCapitalize={"none"}
                                placeholder={Email}
                                validate={this.state.email_Validate}
                                onChangeText={text =>
                                    this.setState({email:text})
                                }
                            />
                            {this._displayError(this.state.error)}

                            <Button
                                styles={Styles.Button}
                                onPress={() => forgetPassword(this.state.email).then((d)=>this.onPress(d))}
                            >
                                Send
                            </Button>
                        </View>
                        <BottomArrows
                            styles={Styles.BottomButtons}
                            leftIcon={Arrow_left}
                            onPressLeft={() => this.props.navigation.goBack()}
                        />
                    </KeyboardAvoidingView>
                </TouchableWithoutFeedback>
            </Screen>
        );
    }
}

const Styles = StyleSheet.create({
    Container: {
        flex: 1,
        alignItems: "center"
    },
    Image: {
        width: 180,
        height: 80
    },
    Title: {
        paddingTop: 20,
        paddingBottom: 20
    },
    Instructions: {
        paddingLeft: 20,
        paddingRight: 20,
        paddingBottom: 20
    },
    Text: {
        fontSize: 25,
        fontWeight: "500",
        textAlign: "center",
        fontFamily: "OpenSans-Regular"
    },
    Paragraph: {
        fontSize: 18,
        fontFamily: "OpenSans-Regular"
    },
    ResendCode: {
        alignSelf: "flex-start",
        paddingLeft: 40
    },
    Resend: {
        textDecorationLine: "underline",
        fontFamily: "OpenSans-Regular"
    },
    Button: {
        marginTop: 80,
        borderRadius: 10,
        borderColor: "red"
    }
});
