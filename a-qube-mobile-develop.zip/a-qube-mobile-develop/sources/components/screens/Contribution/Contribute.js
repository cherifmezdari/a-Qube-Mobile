import React, { Component } from "react";
import {
    Dimensions,
    Image,
    StyleSheet,
    Text,
    TouchableOpacity,
    View
} from "react-native";
import { Bar } from "react-native-progress";

import { getImplementationPool } from "../../../api/ContributionEndpoints";

import Images from "../../../constants/Images";
import Colors from "../../../constants/Colors";

import Button from "../../common/Button/Button";
import Screen from "../../common/Screen/Screen";
import HeaderButton from "../../common/HeaderButton/HeaderButton";

const { Wallet, Arrow_left } = Images;

const dimensions = Dimensions.get("window");
const imageHeight = Math.round(dimensions.width / 6);

export default class Contribution extends Component {
    static navigationOptions = ({ navigation }) => {
        return {
            headerLeft: (
                <HeaderButton
                    onPress={() => navigation.goBack()}
                    icon={Arrow_left}
                />
            )
        };
    };
    constructor(props) {
        super(props);
        this.state = {
            idea: this.props.navigation.state.params.previousState,
            error: ""
        };
    }
    _navigate(screen, data) {
        const { navigation } = this.props;
        navigation.navigate(screen, {
            previousState: { data: data, idea: this.state.idea }
        });
    }

    componentWillMount() {
        const { idea } = this.state;

        getImplementationPool(idea._id).then(v => {
            return this.setState({ implementation: v[0].open_slot.slot._id });
        });
    }

    checkSlotLockUnlock(item, index) {
        const { implementation, idea } = this.state

        if (implementation === item._id) {
            return (
                <TouchableOpacity
                    style={Styles.SlotContainer}
                    key={index}
                    onPress={() =>
                        this._navigate("ProposeContribution", item, idea)
                    }
                >
                    <Text style={Styles.Text}>{item.name}</Text>
                </TouchableOpacity>
            );
        }
        return (
            <TouchableOpacity
                style={[Styles.SlotContainer, { backgroundColor: "grey" }]}
                key={index}
            >
                <Text style={Styles.Text}>{item.name}</Text>
            </TouchableOpacity>
        );
    }
    render() {
        const { Business_Development, Blockchain } = Images;
        const { idea } = this.state;
        const checkTrack =
            idea.track_slots.track.name === "Blockchain & DLT Track" ? (
                <Image
                    source={Blockchain}
                    style={{ height: imageHeight, width: imageHeight }}
                    resizeMode="contain"
                />
            ) : (
                <Image
                    source={Business_Development}
                    style={{ height: imageHeight, width: imageHeight }}
                    resizeMode="contain"
                />
            );
        return (
            <Screen>
                <View style={Styles.Container}>
                    <View style={Styles.Progress}>
                        {checkTrack}
                        <Text style={Styles.Text}>1/6</Text>
                        <Bar
                            borderRadius={5}
                            color={"rgba(128, 51, 73, 1)"}
                            height={10}
                            progress={0.16}
                        />
                    </View>
                    <View style={Styles.Tracks}>
                        <Text style={Styles.Description}>{idea.name}</Text>
                        {idea.track_slots.slots.map((item, index) => {
                            return this.checkSlotLockUnlock(item, index);
                        })}
                    </View>
                    <Text style={[Styles.Text, { color: "red" }]}>
                        {this.state.error}
                    </Text>
                </View>
                <Button
                    styles={{
                        width: "100%",
                        alignSelf: "center",
                        marginBottom: 0
                    }}
                >
                    Contribute
                </Button>
            </Screen>
        );
    }
}

const { Eerie, Granite, DarkGray, White } = Colors;
const Styles = StyleSheet.create({
    Container: {
        alignItems: "center",
        flex: 1,
        justifyContent: "space-evenly"
    },
    Progress: {
        alignItems: "center",
        flex: 1
    },
    Text: {
        color: Eerie,
        fontSize: 15,
        padding: 5,
        textAlign: "center",
        fontFamily: "OpenSans-Regular"
    },
    Description: {
        fontSize: 16,
        textAlign: "center",
        paddingVertical: 5
    },
    Tracks: {
        flex: 3,
        width: "100%",
        justifyContent: "space-evenly"
    },
    SlotContainer: {
        width: "80%",
        alignSelf: "center",
        backgroundColor: "lightgrey",
        paddingHorizontal: 10,
        paddingVertical: 5,
        borderRadius: 5,
        flexDirection: "row",
        justifyContent: "space-between",
        margin: 5
    }
});
