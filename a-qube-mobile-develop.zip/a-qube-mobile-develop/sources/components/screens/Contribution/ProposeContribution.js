import React, { Component } from "react";
import {
    Dimensions,
    Image,
    Platform,
    Modal,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
    Keyboard,
    TouchableWithoutFeedback,
} from "react-native";
import { Bar } from "react-native-progress";
import Slider from "@react-native-community/slider";
import ImagePicker from "react-native-image-picker";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";

import {
    ContributeNow,
    fetchContributionFee,
    payForContribution
} from "../../../api/ContributionEndpoints";

import Button from "../../common/Button/Button";
import Input from "../../common/Input/Input";
import Screen from "../../common/Screen/Screen";

import Colors from "../../../constants/Colors";
import Images from "../../../constants/Images";
import Forms from "../../../constants/Forms";



const contentContainerStyle = Platform.OS === "ios" ? { flex: 1 } : { flex: 0 };

const dimensions = Dimensions.get("window");
const imageHeight = Math.round(dimensions.width / 8);
const textBoxHeight = Math.round(dimensions.height / 8);
const textBoxHeightSmall = Math.round(dimensions.height / 10);
const textBoxHeightExtraSmall = Math.round(dimensions.height / 20);

const marginHeight = Math.round(dimensions.height / 4);

export default class ProposeContribution extends Component {
    constructor(props) {
        super(props);
        this.state = {
            track: this.props.navigation.state.params.previousState.data,
            token_pool: 360,
            question1: "",
            question2: "",
            question3: "",
            modalVisible: false,
            contributions: [],
            slot: this.props.navigation.state.params.previousState.data._id,
            idea: this.props.navigation.state.params.previousState.idea,
            ideaID: this.props.navigation.state.params.previousState.idea._id,
            contributor_fee: "",
            possible_reward: ""
        };
    }

    selectPhotoTapped() {
        const options = {
            quality: 1.0,
            maxWidth: 200,
            maxHeight: 200,
            storageOptions: {
                skipBackup: true
            }
        };
        ImagePicker.showImagePicker(options, response => {
            console.log("Response = ", response);

            if (response.didCancel) {
                console.log("User cancelled photo picker");
            } else if (response.error) {
                console.log("ImagePicker Error: ", response.error);
            } else if (response.customButton) {
                console.log(
                    "User tapped custom button: ",
                    response.customButton
                );
            } else {
                let source = { uri: response.uri };
                this.setState({
                    uploadSource: source
                });
            }
        });
    }

    _handlePropose = () => {
        const { question1, question2, question3, track } = this.state;

        switch (track.questions.length) {
            case 1:
                if (question1 != "") {
                    const contributionAnswers = [
                        {
                            answer: question1,
                            question_id: this.state.track.questions[0]._id
                        }
                    ];

                    return ContributeNow(this.state, contributionAnswers).then(
                        v => {
                            this.setState({
                                contributions: v,
                                modalVisible: true
                            });

                            fetchContributionFee(this.state.contributions).then(
                                v => {
                                    this.setState({
                                        contributor_fee: v.contributor_fee,
                                        possible_reward: v.possible_reward,
                                        allContriubtionInfo: v
                                    });
                                    console.log(this.state);
                                }
                            );
                        }
                    );
                }

            case 2:
                if (question1 != "" && question2 != "") {
                    const contributionAnswers = [
                        {
                            answer: question1,
                            question_id: this.state.track.questions[0]._id
                        },
                        {
                            answer: question2,
                            question_id: this.state.track.questions[1]._id
                        }
                    ];

                    return ContributeNow(this.state, contributionAnswers).then(
                        v => {
                            this.setState({
                                contributions: v,
                                modalVisible: true
                            });

                            fetchContributionFee(this.state.contributions).then(
                                v => {
                                    return this.setState({
                                        contributor_fee: v.contributor_fee,
                                        possible_reward: v.possible_reward,
                                        allContriubtionInfo: v
                                    });
                                }
                            );
                        }
                    );
                }

            case 3:
                if (question1 != "" && question2 != "" && question3 != "") {
                    const contributionAnswers = [
                        {
                            answer: question1,
                            question_id: this.state.track.questions[0]._id
                        },
                        {
                            answer: question2,
                            question_id: this.state.track.questions[1]._id
                        },
                        {
                            answer: question3,
                            question_id: this.state.track.questions[2]._id
                        }
                    ];

                    return ContributeNow(this.state, contributionAnswers).then(
                        v => {
                            this.setState({
                                contributions: v,
                                modalVisible: true
                            });

                            fetchContributionFee(this.state.contributions).then(
                                v => {
                                    return this.setState({
                                        contributor_fee: v.contributor_fee,
                                        possible_reward: v.possible_reward,
                                        allContriubtionInfo: v
                                    });
                                }
                            );
                        }
                    );
                }
        }
    };

    displayQuestions(questions) {
        const { Placeholders } = Forms;
        const { TextBox } = Placeholders;
        return (
            <View style={{ alignItems: "center"}}>
                <Text style={Styles.TextQuestion}>a: {questions[0].name}</Text>
                <Input
                    onChangeText={text => this.setState({ question1: text })}
                    multiline={true}
                    placeholder={TextBox}
                    styles={[Styles.TextBox, Styles.TextBoxBig]}
                    onSubmitEditing={Keyboard.dismiss}
                />
            </View>
        );
    }
    displayUpload(questions) {
        return (
            <View style={{ alignItems: "center"}}>
                <Text style={Styles.TextQuestion}>a: {questions[0].name}</Text>
                <TouchableOpacity onPress={this.selectPhotoTapped.bind(this)}>
                    <Text
                        style={{
                            textAlign: "center",
                            color: "blue",
                            fontSize: 16,
                            fontFamily: "OpenSans-Regular"
                        }}
                    >
                        Select an image to upload.
                    </Text>
                    <Image
                        source={this.state.uploadSource}
                        style={{ width: 200, height: 200 }}
                    />
                </TouchableOpacity>
            </View>
        );
    }
    singleQuestion(questions) {
        console.log(questions);
        const { Placeholders } = Forms;
        const { TextBox } = Placeholders;
        const upload =
            questions[0].category === "UPLOAD"
                ? this.displayUpload(questions)
                : this.displayQuestions(questions);

        return <View>{upload}</View>;
    }
    twoQuestions(questions) {
        const { Placeholders } = Forms;
        const { TextBox } = Placeholders;

        return (
            <View style={{ alignItems: "center"}}>
                <Text style={Styles.TextQuestion}>a: {questions[0].name}</Text>
                <Input
                    onChangeText={text => this.setState({ question1: text })}
                    multiline={true}
                    placeholder={TextBox}
                    styles={[Styles.TextBox, Styles.TextBoxSmall]}
                    onSubmitEditing={Keyboard.dismiss}
                />
                <Text style={Styles.TextQuestion}>b: {questions[1].name}</Text>
                <Input
                    onChangeText={text => this.setState({ question2: text })}
                    multiline={true}
                    placeholder={TextBox}
                    styles={[Styles.TextBox, Styles.TextBoxSmall]}
                    onSubmitEditing={Keyboard.dismiss}
                />
            </View>
        );
    }
    threeQuestions(questions) {
        const { Placeholders } = Forms;
        const { TextBox } = Placeholders;
        return (
            <View style={{ alignItems: "center"}}>
                <Text style={Styles.TextQuestion}>a: {questions[0].name}</Text>
                <Input
                    onChangeText={text => this.setState({ question1: text })}
                    multiline={true}
                    placeholder={TextBox}
                    styles={[
                        Styles.TextBox,
                        Styles.TextBoxExtraSmall,
                        { height: 50 }
                    ]}
                    onSubmitEditing={Keyboard.dismiss}
                />
                <Text style={Styles.TextQuestion}>b: {questions[1].name}</Text>
                <Input
                    onChangeText={text => this.setState({ question2: text })}
                    multiline={true}
                    placeholder={TextBox}
                    styles={[
                        Styles.TextBox,
                        Styles.TextBoxExtraSmall,
                        { height: 50 }
                    ]}
                    onSubmitEditing={Keyboard.dismiss}
                />
                <Text style={Styles.TextQuestion}>b: {questions[2].name}</Text>
                <Input
                    onChangeText={text => this.setState({ question3: text })}
                    multiline={true}
                    placeholder={TextBox}
                    styles={[
                        Styles.TextBox,
                        Styles.TextBoxExtraSmall,
                        { height: 50 }
                    ]}
                    onSubmitEditing={Keyboard.dismiss}
                />
            </View>
        );
    }
    displayQuestions() {
        const { track } = this.state;

        switch (track.questions.length) {
            case 1:
                return this.singleQuestion(track.questions);
            case 2:
                return this.twoQuestions(track.questions);
            case 3:
                return this.threeQuestions(track.questions);
        }
    }
    _navigate() {
        const { navigation } = this.props;

        payForContribution(this.state.allContriubtionInfo).then(v => {
            return navigation.popToTop();
        });
    }

    render() {
        console.log(contentContainerStyle);
        const { track, idea } = this.state;
        const { Blockchain, Business_Development } = Images;
        const checkTrack =
            idea.track_slots.track.name === "Blockchain & DLT Track" ? (
                <Image
                    source={Blockchain}
                    style={{
                        height: imageHeight,
                        width: imageHeight,
                        alignSelf: "center"
                    }}
                    resizeMode="contain"
                />
            ) : (
                <Image
                    source={Business_Development}
                    style={{
                        height: imageHeight,
                        width: imageHeight,
                        alignSelf: "center"
                    }}
                    resizeMode="contain"
                />
            );

        if (track != null) {
            return (
                <Screen>
                    <TouchableWithoutFeedback
                        onPress={() => Keyboard.dismiss()}
                    >
                        <KeyboardAwareScrollView
                            style={{flex: 1}}
                            enableOnAndroid={true}
                            contentContainerStyle={{ flex: 1 }}
                        >
                            <Modal
                                animationType="slide"
                                transparent={true}
                                visible={this.state.modalVisible}
                            >
                                <View style={Styles.ModalContainer}>
                                    <Text
                                        style={{
                                            textAlign: "center",
                                            fontSize: 20,
                                            fontWeight: "600",
                                            fontFamily: "OpenSans-Regular"
                                        }}
                                    >
                                        Almost there!
                                    </Text>
                                    <Text
                                        style={{
                                            textAlign: "center",
                                            fontSize: 15,
                                            fontWeight: "500",
                                            fontFamily: "OpenSans-Regular"
                                        }}
                                    >
                                        Propose your contribution for{" "}
                                        {this.state.contributor_fee} QUBs and
                                        compete to win up to{" "}
                                        {this.state.possible_reward} QUBs!
                                    </Text>
                                    <Button
                                        onPress={() => {
                                            this.setState({
                                                modalVisible: false
                                            });
                                            return this._navigate();
                                        }}
                                        styles={{
                                            borderRadius: 10,
                                            backgroundColor: Pink
                                        }}
                                    >
                                        Qube it!
                                    </Button>
                                </View>
                            </Modal>
                                <View style={{ flex: 1, justifyContent: "space-between", alignContent: "center" }}>
                                    {checkTrack}
                                    <Text style={Styles.Text}>1/6</Text>
                                    <Bar
                                        borderRadius={5}
                                        color={"rgba(128, 51, 73, 1)"}
                                        height={10}
                                        progress={0.17}
                                        style={{ alignSelf: "center"}}
                                    />
                                    <Text style={Styles.Title}>
                                        Fill the form to propose your idea
                                    </Text>
                                    {this.displayQuestions()}
                                    <Text style={Styles.Text}>
                                        Choose an evaluation for your idea
                                    </Text>
                                    <View
                                        style={{
                                            flexDirection: "row",
                                            width: "80%",
                                            alignSelf: "center",
                                            justifyContent: "space-between"
                                        }}
                                    >
                                        <Text>360</Text>
                                        <Text>1440</Text>
                                    </View>
                                    <Slider
                                        style={{
                                            width: "80%",
                                            height: 40,
                                            alignSelf: "center"
                                        }}
                                        minimumValue={360}
                                        maximumValue={1440}
                                        minimumTrackTintColor="rgba(128, 51, 73, 1)"
                                        maximumTrackTintColor="gray"
                                        value={360}
                                        onValueChange={val =>
                                            this.setState({
                                                token_pool: Math.round(val)
                                            })
                                        }
                                    />
                                    <Text style={Styles.TokenPool}>
                                        {this.state.token_pool}
                                    </Text>
                                    
                                <Button
                                    onPress={this._handlePropose.bind(this)}
                                    styles={{
                                        justifyContent: "flex-end",
                                        width: "100%",
                                        alignSelf: "center",
                                        marginBottom: 0,
                                        flex: 0
                                    }}
                                >
                                    Propose
                                </Button>
                            </View>
                        </KeyboardAwareScrollView>
                    </TouchableWithoutFeedback>
                </Screen>
            );
        }
        return <View />;
    }
}

const { Eerie, Gray, Pink } = Colors;
const Styles = StyleSheet.create({
    Container: {
        flex: 1
    },
    Image: {
        height: imageHeight,
        width: imageHeight
    },
    Header: {
        alignItems: "center",
        justifyContent: "center",
        paddingTop: 10,
        flex: 1
    },
    Title: {
        fontSize: 18,
        marginVertical: 2,
        textAlign: "center",
        fontFamily: "OpenSans-SemiBold"
    },
    Text: {
        color: Eerie,
        fontSize: 14,
        margin: 2,
        textAlign: "center",
        fontFamily: "OpenSans-Regular"
    },
    Slide: {
        flex: 1,
        alignItems: "center"
    },
    Slider: {
        flex: 1
    },
    TextQuestion: {
        color: Eerie,
        fontSize: 16,
        margin: 2,
        textAlign: "left",
        fontFamily: "OpenSans-Regular"
    },
    TextBox: {
        backgroundColor: Gray,
        color: "black"
    },
    TextBoxBig: {
        height: textBoxHeight
    },
    Question: {
        fontSize: 14,
        fontWeight: "700",
        fontFamily: "OpenSans-Regular"
    },
    TextBoxSmall: {
        height: textBoxHeightSmall
    },
    TextBoxExtraSmall: {
        height: textBoxHeightExtraSmall
    },
    TokenPool: {
        textAlign: "center",
        fontFamily: "OpenSans-Regular"
    },
    ModalContainer: {
        alignItems: "center",
        backgroundColor: Gray,
        borderRadius: 10,
        justifyContent: "center",
        marginTop: marginHeight,
        marginBottom: marginHeight,
        marginLeft: 10,
        marginRight: 10,
        borderColor: "black",
        borderWidth: 2
    }
});
