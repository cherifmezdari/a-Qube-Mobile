import React, { Component } from "react";
import {
    Dimensions,
    Image,
    ScrollView,
    StyleSheet,
    Text,
    TouchableOpacity,
    View
} from "react-native";

import { FetchNotifications } from "../../../api/UserEndpoints";

import Screen from "../../common/Screen/Screen";
import BottomArrows from "../../common/BottomArrows/BottomArrows";
import HeaderButton from "../../common/HeaderButton/HeaderButton";

import Images from "../../../constants/Images";
import Colors from "../../../constants/Colors";

const { Burger_Menu } = Images;
const { Pink } = Colors;

export default class Notifications extends Component {
    static navigationOptions = ({ navigation }) => {
        return {
            headerLeft: (
                <HeaderButton
                    onPress={() => navigation.toggleDrawer()}
                    icon={Burger_Menu}
                />
            ),
            headerTitle: "Notifications"
        };
    };

    constructor(props) {
        super(props);
        this.state = {
            notificationsArray: []
        };
    }

    _navigate(screen, data) {
        //console.log(data)
        const { navigation } = this.props;
        return navigation.navigate(screen, { previousState: data.idea });
    }

    DisplayNotifications(item, index) {
        const { Ideas, MarketPlace, Arrow_right } = Images;
        console.log(item)
        const date = item.created_on.split("T")
        return (
            <View key={index}>
                <Text style={Styles.Date}>{date[0]}</Text>
                <TouchableOpacity onPress={() => this._navigate("Contribute", item)} style={Styles.Notification}>
                    <Text style={Styles.Text}>{item.notification}</Text>
                    <Image style={{ height: 20, width: 20 }} source={Arrow_right} resizeMode="contain" />
                </TouchableOpacity>
            </View>
        );
    }

    componentWillMount() {
        FetchNotifications().then(data =>
            this.setState({ notificationsArray: data })
        );
    }

    render() {
        const { Ideas, MarketPlace } = Images;
        const { navigation } = this.props
        return (
            <Screen>
                <View style={{ flex: 1 }}>
                    <ScrollView>
                        <View style={{ flex: 1, padding: 5 }}>
                            {this.state.notificationsArray.map((item, index) =>
                                this.DisplayNotifications(item, index)
                            )}
                        </View>
                    </ScrollView>
                    <BottomArrows
                        onPressLeft={() => this.props.navigation.navigate("Notifications")}
                        onPressRight={() => this.props.navigation.navigate("MarketPlace")}
                        styles={{ flex: 0, marginBottom: 10 }}
                        leftIcon={Ideas}
                        rightIcon={MarketPlace}
                    />
                </View>
            </Screen>
        );
    }
}

const Styles = StyleSheet.create({
    Date: {
        fontSize: 18,
        fontFamily: "OpenSans-Regular"
    },
    Text: {
        fontSize: 16,
        fontFamily: "OpenSans-Regular"
    },
    Notification: {
        backgroundColor: "lightgrey",
        margin: 10,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        padding: 10
    }
});
