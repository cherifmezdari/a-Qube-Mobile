import React, { Component } from "react"
import { Image, StyleSheet, Text, TouchableOpacity, View } from "react-native"

import { fetchWalletBalance } from "../../../api/UserEndpoints"


import SettingBox from "../../common/SettingBox/SettingBox"
import Screen from "../../common/Screen/Screen"
import BottomArrows from "../../common/BottomArrows/BottomArrows"
import HeaderButton from "../../common/HeaderButton/HeaderButton"

import Colors from "../../../constants/Colors"
import Images from "../../../constants/Images"


const { Logo_horizontal, Wallet, Burger_Menu } = Images

export default class Idea extends Component {
    static navigationOptions = ({navigation}) => {
        //console.log(navigation.state.params)
        const showBalance = (navigation.state.params != null) ? navigation.state.params.handleThis.balance : ""
        return {
        headerLeft:<HeaderButton onPress={() => navigation.toggleDrawer()} icon={Burger_Menu} />,
        headerRight: <HeaderButton onPress={() => navigation.navigate("Profile")} icon={Wallet}>{showBalance}</HeaderButton>
        }
    }
    componentWillMount() {
        fetchWalletBalance().then((v) => this.props.navigation.setParams({
            handleThis: v
        }))
    }
    render() {
        const { Arrow_left, Account_Icon, Notifications, Privacy, Help } = Images
        const { navigation } = this.props
        return (
            <Screen>
                <View style={Styles.Container}>
                    <Text style={Styles.Title}>Settings</Text>
                    <View style={Styles.SettingSection}>
                        <SettingBox onPress={() => navigation.navigate("Profile")} icons={Account_Icon}>My Account</SettingBox>
                        <SettingBox onPress={() => navigation.navigate("Notifications")} icons={Notifications} statement="All">Notifications</SettingBox>
                        <SettingBox icons={Privacy}>Privacy Policy</SettingBox>
                        <SettingBox icons={Help} statement="Questions?">Help</SettingBox>
                    </View>
                    <BottomArrows leftIcon={Arrow_left} />
                </View>
            </Screen>
        )
    }
}

const { White } = Colors
const Styles = StyleSheet.create({
    Container: {
        alignItems: "center",
        backgroundColor: White,
        flex: 1,
    },
    SettingSection: {
        flex: 3,
        width: "100%",
        height: "100%",
        alignItems: "center"
    },
    Title: {
        fontSize: 25,
        fontWeight: "500",
        paddingBottom: 20,
        fontFamily: "OpenSans-SemiBold"
    }
})
