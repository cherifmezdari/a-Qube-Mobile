import React from "react";
import {
    Dimensions,
    StyleSheet,
    Text,
    View,
    Image,
    Animated,
    PanResponder,
} from "react-native";

import { Bar } from "react-native-progress";

import {
    FetchNotifications,
    fetchRandomIdeas,
    fetchWalletBalance,
    likeIdea,
    dislikeIdea
} from "../../../api/UserEndpoints";

import Screen from "../../common/Screen/Screen";
import Button from "../../common/Button/Button";
import BottomArrows from "../../common/BottomArrows/BottomArrows";
import HeaderButton from "../../common/HeaderButton/HeaderButton";

import Images from "../../../constants/Images";
import Colors from "../../../constants/Colors";

const SCREEN_HEIGHT = Dimensions.get("window").height;
const SCREEN_WIDTH = Dimensions.get("window").width;

const { Activity, QUB, Heart, Burger_Menu, Wallet } = Images;

let currentIdea = [];

const imageHeight = Math.round(SCREEN_WIDTH / 4);

export default class NewInqubator extends React.Component {
    static navigationOptions = ({ navigation }) => {
        const showBalance =
            navigation.state.params != null
                ? navigation.state.params.handleThis.balance
                : "";
        return {
            headerLeft: (
                <HeaderButton
                    onPress={() => navigation.toggleDrawer()}
                    icon={Burger_Menu}
                />
            ),
            headerRight: (
                <HeaderButton
                    onPress={() => navigation.navigate("Profile")}
                    icon={Wallet}
                >
                    {showBalance}
                </HeaderButton>
            )
        };
    };
    constructor() {
        super();
        this.position = new Animated.ValueXY();
        this.state = {
            currentIndex: 0,
            qubes: null,
            wallet: "",
            currentIdea: []
        };

        this.rotate = this.position.x.interpolate({
            inputRange: [-SCREEN_WIDTH / 2, 0, SCREEN_WIDTH / 2],
            outputRange: ["-10deg", "0deg", "10deg"],
            extrapolate: "clamp"
        });

        this.rotateAndTranslate = {
            transform: [
                {
                    rotate: this.rotate
                },
                ...this.position.getTranslateTransform()
            ]
        };

        this.likeOpacity = this.position.x.interpolate({
            inputRange: [-SCREEN_WIDTH / 2, 0, SCREEN_WIDTH / 2],
            outputRange: [0, 0, 1],
            extrapolate: "clamp"
        });
        this.dislikeOpacity = this.position.x.interpolate({
            inputRange: [-SCREEN_WIDTH / 2, 0, SCREEN_WIDTH / 2],
            outputRange: [1, 0, 0],
            extrapolate: "clamp"
        });

        this.nextCardOpacity = this.position.x.interpolate({
            inputRange: [-SCREEN_WIDTH / 2, 0, SCREEN_WIDTH / 2],
            outputRange: [1, 0, 1],
            extrapolate: "clamp"
        });
        this.nextCardScale = this.position.x.interpolate({
            inputRange: [-SCREEN_WIDTH / 2, 0, SCREEN_WIDTH / 2],
            outputRange: [1, 0.8, 1],
            extrapolate: "clamp"
        });
    }
    _navigate(screen, data) {
        const { navigation } = this.props;
        navigation.navigate(screen, { previousState: data });
    }
    componentWillMount() {
        fetchWalletBalance().then(v =>
            this.props.navigation.setParams({
                handleThis: v
            })
        );

        fetchRandomIdeas().then(v => {
            this.setState({ qubes: v });
        });

        FetchNotifications().then(data => {
            this.setState({ notificationsArray: data });
        });

        this.PanResponder = PanResponder.create({
            onStartShouldSetPanResponder: (evt, gestureState) => true,
            onPanResponderMove: (evt, gestureState) => {
                this.position.setValue({
                    x: gestureState.dx,
                    y: gestureState.dy
                });
            },
            onPanResponderRelease: (evt, gestureState) => {
                if (gestureState.dx > 120) {
                    console.log("yes like");
                    likeIdea(currentIdea._id).then((v) => console.log(v))
                    Animated.spring(this.position, {
                        toValue: { x: SCREEN_WIDTH + 100, y: gestureState.dy }
                    }).start(() => {
                        this.setState(
                            { currentIndex: this.state.currentIndex + 1 },
                            () => {
                                this.position.setValue({ x: 0, y: 0 });
                            }
                        );
                    });
                    //
                } else if (gestureState.dx < -120) {
                    console.log("no like");
                    dislikeIdea(currentIdea._id).then((v) => console.log(v))
                    Animated.spring(this.position, {
                        toValue: { x: -SCREEN_WIDTH - 100, y: gestureState.dy }
                    }).start(() => {
                        this.setState(
                            { currentIndex: this.state.currentIndex + 1 },
                            () => {
                                this.position.setValue({ x: 0, y: 0 });
                            }
                        );
                    });
                } else {
                    Animated.spring(this.position, {
                        toValue: { x: 0, y: 0 },
                        friction: 4
                    }).start();
                }
            }
        });
    }

    renderUsers = () => {
        const { Business_Development, Blockchain } = Images;
        return this.state.qubes
            .map((item, i) => {
                currentIdea = item;
                if (i < this.state.currentIndex) {
                    return null;
                } else if (i == this.state.currentIndex) {
                    const checkTrack =
                        item.track_slots.track.name ===
                        "Blockchain & DLT Track" ? (
                            <Image
                                source={Blockchain}
                                style={{
                                    height: imageHeight,
                                    width: imageHeight
                                }}
                                resizeMode="contain"
                            />
                        ) : (
                            <Image
                                source={Business_Development}
                                style={{
                                    height: imageHeight,
                                    width: imageHeight
                                }}
                                resizeMode="contain"
                            />
                        );

                    return (
                        <View
                            key={i}
                            style={{ flex: 8, justifyContent: "center" }}
                        >
                            <Animated.View
                                {...this.PanResponder.panHandlers}
                                style={[
                                    this.rotateAndTranslate,
                                    {
                                        height: SCREEN_HEIGHT - 300,
                                        width: SCREEN_WIDTH,
                                        padding: 10,
                                        position: "absolute"
                                    }
                                ]}
                            >
                                <Animated.View
                                    style={{
                                        opacity: this.likeOpacity,
                                        transform: [{ rotate: "-30deg" }],
                                        position: "absolute",
                                        top: 50,
                                        left: 40,
                                        zIndex: 1000
                                    }}
                                >
                                    <Text
                                        style={{
                                            borderWidth: 1,
                                            borderColor: "green",
                                            color: "green",
                                            fontSize: 32,
                                            fontWeight: "800",
                                            padding: 10,
                                            fontFamily: "OpenSans-Regular"
                                        }}
                                    >
                                        LIKE
                                    </Text>
                                </Animated.View>

                                <Animated.View
                                    style={{
                                        opacity: this.dislikeOpacity,
                                        transform: [{ rotate: "30deg" }],
                                        position: "absolute",
                                        top: 50,
                                        right: 40,
                                        zIndex: 1000
                                    }}
                                >
                                    <Text
                                        style={{
                                            borderWidth: 1,
                                            borderColor: "red",
                                            color: "red",
                                            fontSize: 32,
                                            fontWeight: "800",
                                            padding: 10,
                                            fontFamily: "OpenSans-Regular"
                                        }}
                                    >
                                        NOPE
                                    </Text>
                                </Animated.View>

                                <View style={styles.Card}>
                                    <View style={styles.Section}>
                                        {checkTrack}
                                        <Text style={styles.Text}>1/6</Text>
                                        <Bar
                                            borderRadius={5}
                                            color={"rgba(128, 51, 73, 1)"}
                                            height={10}
                                            progress={0.17}
                                        />
                                    </View>
                                    <View style={styles.Section}>
                                        <Text style={styles.Text}>
                                            {item.name}
                                        </Text>
                                    </View>
                                    <View style={styles.Section}>
                                        <Button
                                            onPress={() =>
                                                this._navigate(
                                                    "Contribute",
                                                    item
                                                )
                                            }
                                            styles={styles.Button}
                                        >
                                            Contribute
                                        </Button>
                                    </View>
                                </View>
                            </Animated.View>
                        </View>
                    );
                } else {
                    return (
                        <Animated.View
                            key={i}
                            style={[
                                {
                                    opacity: this.nextCardOpacity,
                                    transform: [{ scale: this.nextCardScale }],
                                    height: SCREEN_HEIGHT - 120,
                                    width: SCREEN_WIDTH,
                                    padding: 10,
                                    position: "absolute"
                                }
                            ]}
                        >
                            <Animated.View
                                style={{
                                    opacity: 0,
                                    transform: [{ rotate: "-30deg" }],
                                    position: "absolute",
                                    top: 50,
                                    left: 40,
                                    zIndex: 1000
                                }}
                            >
                                <Text
                                    style={{
                                        borderWidth: 1,
                                        borderColor: "green",
                                        color: "green",
                                        fontSize: 32,
                                        fontWeight: "800",
                                        padding: 10,
                                        fontFamily: "OpenSans-Regular"
                                    }}
                                >
                                    LIKE
                                </Text>
                            </Animated.View>

                            <Animated.View
                                style={{
                                    opacity: 0,
                                    transform: [{ rotate: "30deg" }],
                                    position: "absolute",
                                    top: 50,
                                    right: 40,
                                    zIndex: 1000
                                }}
                            >
                                <Text
                                    style={{
                                        borderWidth: 1,
                                        borderColor: "red",
                                        color: "red",
                                        fontSize: 32,
                                        fontWeight: "800",
                                        padding: 10,
                                        fontFamily: "OpenSans-Regular"
                                    }}
                                >
                                    NOPE
                                </Text>
                            </Animated.View>

                            <Image
                                style={{
                                    flex: 1,
                                    height: null,
                                    width: null,
                                    resizeMode: "cover",
                                    borderRadius: 20
                                }}
                                source={item.uri}
                            />
                        </Animated.View>
                    );
                }
            })
            .reverse();
    };
    renderEmptyView() {
        return (
            <View
                style={{
                    flex: 8,
                    alignItems: "center",
                    justifyContent: "center"
                }}
            >
                <Text>No ideas available</Text>
            </View>
        );
    }
    render() {
        const { Ideas, MarketPlace } = Images;
        const { navigation } = this.props;
        const checkQubes =
            this.state.qubes !== null
                ? this.renderUsers()
                : this.renderEmptyView();

        let leftBadgeNumber = this.state.notificationsArray
            ? this.state.notificationsArray.length
            : 0;
        console.log(this.props)
        return (
            <Screen>
                <View style={{ flex: 1 }}>
                    {checkQubes}
                    <BottomArrows
                        onPressLeft={() => navigation.navigate("Notifications")}
                        leftBadge={leftBadgeNumber}
                        onPressRight={() => navigation.navigate("MarketPlace")}
                        styles={{ marginBottom: 10 }}
                        leftIcon={Ideas}
                        rightIcon={MarketPlace}
                    />
                </View>
            </Screen>
        );
    }
}

const { Eerie, Gray } = Colors;
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#fff",
        alignItems: "center",
        justifyContent: "center"
    },
    Button: {
        borderRadius: 10
    },
    Card: {
        backgroundColor: Gray,
        borderRadius: 20,
        flex: 1
    },
    Text: {
        fontSize: 15,
        textAlign: "center"
    },
    Section: {
        alignItems: "center",
        marginVertical: 10
    }
});
