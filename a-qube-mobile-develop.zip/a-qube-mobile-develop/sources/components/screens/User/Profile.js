import React, { Component } from "react";
import { Dimensions, FlatList, Image, StyleSheet, Text, View } from "react-native";

import { fetchUserProfile, fetchWalletBalance, fetchMyChallenges } from "../../../api/UserEndpoints";

import Screen from "../../common/Screen/Screen";
import BottomArrows from "../../common/BottomArrows/BottomArrows";
import ChallengeCard from "../../common/ChallengeCard/ChallengeCard";

import Images from "../../../constants/Images";
import Colors from "../../../constants/Colors";


export default class Profile extends Component {
    constructor(props) {
        super(props);
        this.state = {
            userProfile: null,
            balance: "",
            myChallenges: []
        };
    }
    navigate(screen) {
        const { navigation } = this.props;
        navigation.navigate(screen);
    }

    async componentDidMount() {
        const user = await fetchUserProfile();
        const walletBalance = await fetchWalletBalance();
        const myChallenges = await fetchMyChallenges();
        this.setState({ userProfile: user, balance: walletBalance, myChallenges: myChallenges.data });
    }

    displayImage() {
        let { userProfile } = this.state;
        if (userProfile.is_profile_completed != false) {
            return (
                <Image
                    resizeMode="cover"
                    source={{ uri: userProfile.avatar.url }}
                    style={Styles.Image}
                />
            );
        } else {
            return <Text>No image</Text>;
        }
    }

    _renderItem = ({ item }) => {
        return (
            <ChallengeCard item={item} />
        )
    }

    displayChallenges() {
        return(
            <View style={{flex: 1}}>
            <FlatList
                data={this.state.myChallenges}
                renderItem={this._renderItem}
                keyExtractor={(item, index) => index.toString()}
            />
            </View>
        )
    }

    render() {
        console.log(this.state)
        const {
            Wallet,
            Arrow_left,
            MarketPlace,
            inQubator_icon
        } = Images;
        let { userProfile, balance, myChallenges } = this.state;
        const { navigation } = this.props;
        const avatar = userProfile != null ? this.displayImage() : <View />;

        const nickname = userProfile ? userProfile.nickname : "";
        const myChallengesDisplay = myChallenges ? this.displayChallenges() : (
            <Text style={{ paddingTop: 20, fontSize: 20, fontWeight: "600" }}>
                No Challenges
            </Text>
        );
        return (
            <Screen>
                <View style={Styles.Container}>
                    <Text style={Styles.Title}>My account</Text>
                    {avatar}
                    <Text style={Styles.User}>{nickname}</Text>
                    <Text style={Styles.Balance}>
                        balance: {balance.balance} QUBs
                    </Text>
                    <View style={Styles.ChallengesContainer}>
                        <View style={Styles.Row}>
                            <Image
                                source={Wallet}
                                style={Styles.WalletImage}
                                resizeMode="contain"
                            />
                            <Text style={Styles.MyChallenge}>
                                My Challenges
                            </Text>
                        </View>
                        {myChallengesDisplay}
                    </View>
                    <BottomArrows
                        styles={Styles.BottomButtons}
                        leftIcon={Arrow_left}
                        onPressLeft={() => this.props.navigation.goBack()}
                    />
                    <BottomArrows
                        styles={[
                            Styles.BottomButtons,
                            { backgroundColor: "black" }
                        ]}
                        onPressRight={() => navigation.navigate("MarketPlace")}
                        onPressLeft={() => navigation.navigate("InqubatorStack")}
                        leftIcon={inQubator_icon}
                        rightIcon={MarketPlace}
                        color="white"
                    />
                </View>
            </Screen>
        );
    }
}

const { DarkGray } = Colors;
const Styles = StyleSheet.create({
    Container: {
        flex: 1,
        alignItems: "center",
        justifyContent: "space-evenly"
    },
    Title: {
        fontSize: 25,
        fontWeight: "600",
        fontFamily: "OpenSans-Semibold"
    },
    Image: {
        height: Dimensions.get("window").width / 4,
        width: Dimensions.get("window").width / 4,
        borderRadius: Dimensions.get("window").width / 4 / 2
    },
    ChallengesContainer: {
        flex: 1,
        paddingLeft: 10,
        paddingRight: 10,
        width: "100%",
    },
    WalletImage: {
        height: 30,
        width: 30
    },
    Row: {
        flexDirection: "row",
        alignSelf: "flex-start",
        width: "100%"
    },
    MyChallenge: {
        alignSelf: "center",
        paddingLeft: 10,
        fontSize: 18,
        fontFamily: "OpenSans-Regular"
    },
    User: {
        fontSize: 15,
        fontWeight: "500",
        paddingVertical: 5,
        fontFamily: "OpenSans-Regular"
    },
    Balance: {
        fontSize: 14,
        fontWeight: "200",
        paddingVertical: 5,
        fontFamily: "OpenSans-Regular"
    },
    BottomButtons: {
        flex: 0,
        marginBottom: 0,
        paddingVertical: 10
    }
});
