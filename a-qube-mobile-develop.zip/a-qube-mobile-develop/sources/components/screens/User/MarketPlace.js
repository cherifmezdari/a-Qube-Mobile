import React, { Component } from "react";
import {
    Dimensions,
    Image,
    KeyboardAvoidingView,
    Keyboard,
    Platform,
    ScrollView,
    StyleSheet,
    Text,
    View,
    TouchableWithoutFeedback
} from "react-native";

import { fetchIdeas, FetchNotifications } from "../../../api/UserEndpoints";

import Screen from "../../common/Screen/Screen";
import Input from "../../common/Input/Input";
import BottomArrows from "../../common/BottomArrows/BottomArrows";
import MarketPlaceSection from "../../common/MarketPlaceSection/MarketPlaceSection";

import Images from "../../../constants/Images";
import Forms from "../../../constants/Forms";

const paddingBehavior = Platform.OS === "ios" ? "padding" : "";

export default class MarketPlace extends Component {
    constructor(props) {
        super(props);
        this.state = {
            blockchain: null,
            business: null
        };
    }
    navigate(screen) {
        const { navigation } = this.props;
        navigation.navigate(screen);
    }
    async componentWillMount() {
        FetchNotifications().then(data => {
            this.setState({ notificationsArray: data });
        });

        const blockchainId = "5d0a86364176a19782714c33";
        const businessId = "5d0a86364176a19782714c19";
        const blockchainIdeas = await fetchIdeas(blockchainId);

        const businessIdeas = await fetchIdeas(businessId);

        if (businessIdeas.length != 0) {
            this.setState({ business: businessIdeas });
        }
        if (blockchainIdeas.length != 0) {
            this.setState({ blockchain: blockchainIdeas });
        }
    }
    render() {
        const { MarketPlace, Ideas, Plus } = Images;
        const { business, blockchain } = this.state;
        const { Placeholders } = Forms;
        const { Search } = Placeholders;
        const { navigation } = this.props;
        let leftBadgeNumber = this.state.notificationsArray
            ? this.state.notificationsArray.length
            : 0;
        return (
            <Screen>
                <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
                    <KeyboardAvoidingView
                        style={Styles.Container}
                        behavior={paddingBehavior}
                        enabled
                    >
                        <View style={Styles.Container}>
                            <Image
                                style={Styles.Image}
                                source={MarketPlace}
                                resizeMode="contain"
                            />
                            <Text style={{ fontFamily: "OpenSans-SemiBold" }}>
                                marketPlace
                            </Text>
                            <Input
                                placeholder={Search}
                                onSubmitEditing={Keyboard.dismiss}
                            />
                            <ScrollView style={{ flex: 2 }}>
                                <Text style={Styles.Title}>
                                    Business Innovation
                                </Text>
                                <MarketPlaceSection data={business} />
                                <Text style={Styles.Title}>
                                    Blockchain and DLT
                                </Text>
                                <MarketPlaceSection data={blockchain} />
                            </ScrollView>
                        </View>
                        <BottomArrows
                            leftBadge={leftBadgeNumber}
                            styles={[
                                Styles.BottomButtons,
                                { backgroundColor: "black" }
                            ]}
                            onPressRight={() =>
                                navigation.navigate("ProposeChallengeStack")
                            }
                            onPressLeft={() => navigation.navigate("Inqubator")}
                            leftIcon={Ideas}
                            rightIcon={Plus}
                            leftColor="white"
                            rightStyle={{
                                height: Dimensions.get("window").width / 9,
                                width: Dimensions.get("window").height / 9
                            }}
                        />
                    </KeyboardAvoidingView>
                </TouchableWithoutFeedback>
            </Screen>
        );
    }
}

const Styles = StyleSheet.create({
    Container: {
        flex: 1,
        alignItems: "center",
        paddingTop: 5
    },
    Image: {
        width: Dimensions.get("window").width / 6,
        height: Dimensions.get("window").width / 6
    },
    Title: {
        fontSize: 20,
        fontFamily: "OpenSans-Regular",
        textAlign: "center"
    },
    BottomButtons: {
        flex: 0,
        marginBottom: 0,
        paddingVertical: 10
    }
});
