import React, { Component } from "react"
import {
    Dimensions,
    Image,
    TouchableWithoutFeedback,
    Keyboard,
    StyleSheet,
    Text,
    View
} from "react-native";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";

import { connect } from "react-redux";

import BottomArrows from "../../common/BottomArrows/BottomArrows";
import Input from "../../common/Input/Input";
import Screen from "../../common/Screen/Screen";

import Images from "../../../constants/Images";
import Tracks from "../../../constants/Tracks";
import Colors from "../../../constants/Colors";

const dimensions = Dimensions.get("window");
const imageHeight = Math.round(dimensions.width / 6);

class ProposeChallengeStepThree extends Component {
    static navigationOptions = {
        header: null
    };
    constructor(props) {
        super(props);
        this.state = {
            blockchain: null,
            business: null,
            name: "",
            token_pool: 360,
            qube_number: "",
            trackSlotID: this.props.navigation.state.params.previousState.trackSlotID,
            tracks: this.props.navigation.state.params.previousState.tracks,
            slots: this.props.AddIngredient.slots,
            nature: this.props.navigation.state.params.previousState.nature,
            error: ""
        };
    }

    navigate(screen) {
        const { navigation } = this.props;
        navigation.navigate(screen);
    }

    _displayError() {
        if (this.state.wordNumberError !== "") {
            return (
                <Text style={{ fontSize: 16, color: "red" }}>
                    {this.state.wordNumberError}
                </Text>
            );
        }
    }

    _displayNumberError() {
        if (this.state.error !== "") {
            return (
                <Text style={{ fontSize: 16, color: "red" }}>
                    {this.state.error}
                </Text>
            );
        }
    }

    countWords(s) {
        s = s.replace(/(^\s*)|(\s*$)/gi, "");
        s = s.replace(/[ ]{2,}/gi, " ");
        s = s.replace(/\n /, "\n");
        length = s.split(" ").length;
        if (length < 6 || length > 8) {
            this.setState({
                wordNumberError: "The words count should be between 6 and 8"
            });
        } else {
            this.setState({ wordNumberError: "" });
        }
    }

    render() {
        if (
            this.state.qube_number == "3" ||
            this.state.qube_number == "1" ||
            this.state.qube_number == "2"
        ) {
        }
        console.log(this.state);
        const { navigation } = this.props;
        const { business, blockchain, tracks } = this.state;
        const {
            Logo_horizontal,
            Blockchain,
            Business_Development,
            Arrow_left,
            Arrow_right
        } = Images;
        const displayImage =
            tracks[0].track.name === Tracks.Business ? (
                <Image source={Business_Development} style={Styles.TrackIcon} />
            ) : (
                    <Image source={Blockchain} style={Styles.TrackIcon} />
                );
        return (
            <Screen>
                <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
                    <KeyboardAwareScrollView
                        enableOnAndroid={true}
                        contentContainerStyle={{ flex: 1 }}
                    >

                        <View style={Styles.StepContainer}>
                            {displayImage}
                            <Text style={Styles.Step}>Step 3:</Text>
                            <Text style={Styles.Instructions}>
                                Describe your Challenge in 6-to-8
                                words
                                        </Text>
                            <Input
                                styles={[
                                    Styles.Input,
                                    { height: 200 }
                                ]}
                                multiline={true}
                                onChangeText={text => {
                                    this.setState({
                                        name: text
                                    });
                                    this.countWords(text);
                                }}
                                onSubmitEditing={
                                    Keyboard.dismiss
                                }
                            />
                            {this._displayError()}
                            <BottomArrows
                                onPressLeft={() =>
                                    this.props.navigation.goBack()
                                }
                                styles={Styles.Arrow}
                                leftIcon={Arrow_left}
                                style={{
                                    height: Dimensions.get("window").width / 14,
                                    width: Dimensions.get("window").width / 14
                                }}
                                rightIcon={Arrow_right}
                                onPressRight={() =>
                              {    if (this.state.wordNumberError=="") {
                                    this.props.navigation.navigate("ProposeChallengeStepFour", { previousState: this.state })

                                  }

                                }
                                }
                            />

                        </View>
                    </KeyboardAwareScrollView>
                </TouchableWithoutFeedback>
            </Screen>
        );
    }
}

const { Eerie, Gray, Pink } = Colors;
const Styles = StyleSheet.create({
    Container: {
        flex: 1,
        alignItems: "center"
    },
    Arrow: {
        flex: 0,
        marginBottom: 0
    },
    Button: {
        width: "100%",
        alignSelf: "center"
    },
    Image: {
        height: Dimensions.get("window").width / 8,
        width: Dimensions.get("window").width / 2
    },
    TrackIcon: {
        alignSelf: "center",
        width: imageHeight,
        height: imageHeight
    },
    Instructions: {
        fontSize: 20,
        fontWeight: "600",
        textAlign: "center",
        fontFamily: "OpenSans-Regular"
    },
    Propose: {
        fontSize: 25,
        textAlign: "center",
        fontFamily: "OpenSans-SemiBold"
    },
    Step: {
        fontSize: 24,
        textAlign: "center",
        fontFamily: "OpenSans-Regular"
    },
    Track: {
        width: "80%",
        padding: 5,
        margin: 5,
        backgroundColor: Gray,
        borderRadius: 5,
        alignSelf: "center"
    },
    TrackText: {
        fontSize: 20,
        fontWeight: "500",
        textAlign: "center",
        fontFamily: "OpenSans-Regular"
    },
    Swiper: {
        flex: 1,
        width: "100%",
        alignSelf: "center",
        justifyContent: "space-between"
    },
    StepContainer: {
        flex: 1,
        justifyContent: "space-between"
    },
    Input: {
        alignSelf: "center"
    },
    TokenPool: {
        textAlign: "center",
        fontFamily: "OpenSans-Regular"
    }
});

const mapStateToProps = state => {
    return state;
};

export default connect(mapStateToProps)(ProposeChallengeStepThree);
