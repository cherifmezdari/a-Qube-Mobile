import React, { Component } from "react"
import {
    Dimensions,
    Image,
    TouchableWithoutFeedback,
    Keyboard,
    StyleSheet,
    Text,
    View,
    Modal
} from "react-native";
import Slider from "@react-native-community/slider";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";

import { connect } from "react-redux";

import {
    sendIdea
} from "../../../api/ProposeChallengeEndpoints";

import BottomArrows from "../../common/BottomArrows/BottomArrows";
import Button from "../../common/Button/Button";
import ContributionTrack from "../../common/ContributionTrack/ContributionTrack";
import Input from "../../common/Input/Input";
import Screen from "../../common/Screen/Screen";

import Images from "../../../constants/Images";
import Tracks from "../../../constants/Tracks";
import Colors from "../../../constants/Colors";

const dimensions = Dimensions.get("window");
const imageHeight = Math.round(dimensions.width / 6);
const marginHeight = Math.round(dimensions.height / 4);


class ProposeChallengeStepFour extends Component {
    static navigationOptions = {
        header: null
    };
    constructor(props) {
        super(props);
        this.state = {
            blockchain: null,
            business: null,
            name: this.props.navigation.state.params.previousState.name,
            token_pool: 360,
            qube_number: "",
            trackSlotID: this.props.navigation.state.params.previousState.trackSlotID,
            tracks: this.props.navigation.state.params.previousState.tracks,
            slots: this.props.AddIngredient.slots,
            nature: this.props.navigation.state.params.previousState.nature,
            error: "",
            modalVisible:false
        };
    }

    navigate(screen) {
        const { navigation } = this.props;
        navigation.navigate(screen);
    }

    displayTrack() {
        const { tracks } = this.state;
        const { Blockchain, Business_Development } = Images;
        const displayImage =
            tracks[0].track.name === Tracks.Business ? (
                <Image source={Business_Development} style={Styles.TrackIcon} />
            ) : (
                    <Image source={Blockchain} style={Styles.TrackIcon} />
                );
        return (
            <View style={Styles.StepContainer}>
                {displayImage}
                <Text style={Styles.Step}>Step 2:</Text>
                <Text style={Styles.Instructions}>
                    Slots for your Challenge
                </Text>
                {tracks[0].slots.map((slot, index) => (
                    <ContributionTrack
                        key={index}
                        nature={this.props.navigation.state.params.id}
                        slot={slot}
                    >
                        {slot.name}
                    </ContributionTrack>
                ))}
            </View>
        );
    }

    _displayError() {
        if (this.state.wordNumberError !== "") {
            return (
                <Text style={{ fontSize: 16, color: "red" }}>
                    {this.state.wordNumberError}
                </Text>
            );
        }
    }

    _displayNumberError() {
        if (this.state.error !== "") {
            return (
                <Text style={{ fontSize: 16, color: "red" }}>
                    {this.state.error}
                </Text>
            );
        }
    }

    countWords(s) {
        s = s.replace(/(^\s*)|(\s*$)/gi, "");
        s = s.replace(/[ ]{2,}/gi, " ");
        s = s.replace(/\n /, "\n");
        length = s.split(" ").length;
        if (length < 6 || length > 8) {
            this.setState({
                wordNumberError: "The words count should be between 6 and 8"
            });
        } else {
            this.setState({ wordNumberError: "" });
        }
    }

    choosenTrack(data, id) {
        //console.warn(data);
        if (id == "business") {
            this.setState({
                tracks: data,
                trackSlotID: this.state.tracks[0]._id
            });

            this.setState({ nature: "business" });
        } else {
            this.setState({
                tracks: data,
                trackSlotID: this.state.tracks[1]._id
            });
            this.setState({ nature: "blockchain" });
        }
    }
    proposePressed() {
        if (this.state.name != "" && this.state.qube_number != "") {
            if (this.state.nature == "business") {
                sendIdea(this.state, this.props.AddIngredient.slots).then(d => {
                    console.warn(d);
                    if (d.statusCode == 201) {
                        console.warn("success");
                        this.navigate("InqubatorStack");
                    } else if (d.statusCode == 410) {
                        this.setState({
                            error: "Insufficient account balance"
                        });
                    } else {
                        this.setState({ error: "Check your inputs" });
                    }
                });
            } else {
                sendIdea(this.state, this.props.blockchainRecucer.slots).then(
                    d => {
                        console.log(d);
                        if (d.statusCode == 201) {
                            this.navigate("InqubatorStack");
                        }
                    }
                );
            }
        } else {
            this.setState({ error: "Please check your inputs." });
        }

        const { name, trackSlotID } = this.state;
        let validateName = name.split(" ").length;
        if (name[name.length - 1] == " ") {
            validateName = validateName - 1;
        }

        if (validateName > 5 && validateName < 9 && trackSlotID != null) {
            console.log("true");
        }
        this.setState({
            modalVisible: false
        });
    }
    render() {
        if (
            this.state.qube_number == "3" ||
            this.state.qube_number == "1" ||
            this.state.qube_number == "2"
        ) {
        }

        const { navigation } = this.props;
        const { business, blockchain, tracks } = this.state;
        const {
            Logo_horizontal,
            Blockchain,
            Business_Development,
            Arrow_left,
            Arrow_right
        } = Images;
        const displayImage =
            tracks[0].track.name === Tracks.Business ? (
                <Image source={Business_Development} style={Styles.TrackIcon} />
            ) : (
                    <Image source={Blockchain} style={Styles.TrackIcon} />
                );
        return (
            <Screen>
                <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
                    <KeyboardAwareScrollView
                        enableOnAndroid={true}
                        contentContainerStyle={{ flex: 1 }}
                    >


                        <View style={Styles.StepContainer}>
                            {displayImage}
                            <Text style={Styles.Step}>Step 4:</Text>
                            <Text style={Styles.Instructions}>
                                1. Value of the Qube/Solution:
                                        </Text>
                            <View
                                style={{
                                    flexDirection: "row",
                                    width: "80%",
                                    alignSelf: "center",
                                    justifyContent: "space-between"
                                }}
                            >
                                <Text>360</Text>
                                <Text>1440</Text>
                            </View>
                            <Modal
                                animationType="slide"
                                transparent={true}
                                visible={this.state.modalVisible}
                            >
                                <View style={Styles.ModalContainer}>
                                    <Text
                                        style={{
                                            textAlign: "center",
                                            fontSize: 20,
                                            fontWeight: "600",
                                            fontFamily: "OpenSans-Regular"
                                        }}
                                    >
                                        Almost there!
                                    </Text>
                                    <Text
                                        style={{
                                            textAlign: "center",
                                            fontSize: 15,
                                            fontWeight: "500",
                                            fontFamily: "OpenSans-Regular"
                                        }}
                                    >
                                        Propose your challenge for{" "}
                                        {this.state.qube_number*this.state.token_pool} QUBs
                                        {this.state.possible_reward} QUBs!
                                    </Text>
                                    <Button
                                        onPress={() => {

                                          this.proposePressed()
                                        }}
                                        styles={{
                                            borderRadius: 10,
                                            backgroundColor: Pink
                                        }}
                                    >
                                        Qube it!
                                    </Button>
                                </View>
                            </Modal>

                            <Slider
                                style={{
                                    width: "80%",
                                    height: 40,
                                    alignSelf: "center"
                                }}
                                minimumValue={360}
                                maximumValue={1440}
                                minimumTrackTintColor="rgba(128, 51, 73, 1)"
                                maximumTrackTintColor="gray"
                                value={360}
                                onValueChange={val =>
                                    this.setState({
                                        token_pool: Math.round(val)
                                    })
                                }
                            />
                            <Text style={Styles.TokenPool}>
                                {this.state.token_pool}
                            </Text>
                            <Text style={Styles.Instructions}>
                                2. Number of Qubes/Solution (1-to-3)
                                        </Text>
                            <Input
                                styles={Styles.Input}
                                onChangeText={d => {
                                    this.setState({
                                        qube_number: d
                                    });
                                    if (
                                        d == "1" ||
                                        d == "2" ||
                                        d == "3"
                                    ) {
                                        this.setState({
                                            error: ""
                                        });
                                    } else {
                                        this.setState({
                                            error:
                                                "Invalid Qube number"
                                        });
                                    }
                                }}
                                onSubmitEditing={Keyboard.dismiss}
                                keyboardType="numeric"
                            />
                            {this._displayNumberError()}
                            <BottomArrows
                                onPressLeft={() =>
                                    this.props.navigation.goBack()
                                }
                                styles={Styles.Arrow}
                                leftIcon={Arrow_left}
                                style={{
                                    height: Dimensions.get("window").width / 14,
                                    width: Dimensions.get("window").width / 14
                                }}
                            />
                            <Button
                                styles={Styles.Button}
                                onPress={() =>{
                                  if (this.state.qube_number!=="") {
                                    this.setState({modalVisible:true})}
                                  }

                                  }
                            >
                                Propose
                        </Button>
                        </View>
                    </KeyboardAwareScrollView>
                </TouchableWithoutFeedback>
            </Screen>
        );
    }
}

const { Eerie, Gray, Pink } = Colors;
const Styles = StyleSheet.create({
    Container: {
        flex: 1,
        alignItems: "center"
    },
    Arrow: {
        flex: 0,
        marginBottom: 0
    },
    Button: {
        width: "100%",
        alignSelf: "center"
    },
    Image: {
        height: Dimensions.get("window").width / 8,
        width: Dimensions.get("window").width / 2
    },
    TrackIcon: {
        alignSelf: "center",
        width: imageHeight,
        height: imageHeight
    },
    Instructions: {
        fontSize: 20,
        fontWeight: "600",
        textAlign: "center",
        fontFamily: "OpenSans-Regular"
    },
    Propose: {
        fontSize: 25,
        textAlign: "center",
        fontFamily: "OpenSans-SemiBold"
    },
    Step: {
        fontSize: 24,
        textAlign: "center",
        fontFamily: "OpenSans-Regular"
    },
    Track: {
        width: "80%",
        padding: 5,
        margin: 5,
        backgroundColor: Gray,
        borderRadius: 5,
        alignSelf: "center"
    },
    TrackText: {
        fontSize: 20,
        fontWeight: "500",
        textAlign: "center",
        fontFamily: "OpenSans-Regular"
    },
    StepContainer: {
        flex: 1,
        justifyContent: "space-between"
    },
    Input: {
        alignSelf: "center"
    },
    TokenPool: {
        textAlign: "center",
        fontFamily: "OpenSans-Regular"
    },
    ModalContainer: {
        alignItems: "center",
        backgroundColor: Gray,
        borderRadius: 10,
        justifyContent: "center",
        marginTop: marginHeight,
        marginBottom: marginHeight,
        marginLeft: 10,
        marginRight: 10,
        borderColor: "black",
        borderWidth: 2
    }
});

const mapStateToProps = state => {
    return state;
};

export default connect(mapStateToProps)(ProposeChallengeStepFour);
