import React, { Component } from "react";
import {
    Image,
    StyleSheet,
    Text,
    TouchableOpacity,
    View
} from "react-native";

import { connect } from "react-redux";

import {
    fetchTracksSlotsList,
    fetchTracks
} from "../../../api/ProposeChallengeEndpoints";

import BottomArrows from "../../common/BottomArrows/BottomArrows";
import Images from "../../../constants/Images";
import Screen from "../../common/Screen/Screen";
import Tracks from "../../../constants/Tracks";
import Colors from "../../../constants/Colors";

class ProposeChallenge extends Component {
    static navigationOptions = {
        header: null
    };
    constructor(props) {
        super(props);
        this.state = {
            blockchain: null,
            business: null,
            name: "",
            token_pool: 360,
            qube_number: "",
            trackSlotID: null,
            tracks: null,
            slots: this.props.AddIngredient.slots,
            nature: "",
            error: ""
        };
    }

    async componentWillMount() {
        fetchTracks().then(t => this.setState({ fetchTracks: t }));

        const { Business, Blockchain } = Tracks;
        let tracks = await fetchTracksSlotsList();
        let businessTrack = tracks.filter(function (track) {
            return track.track.name == Business;
        });
        let blockchainTrack = tracks.filter(function (track) {
            return track.track.name == Blockchain;


        });
        this.setState({ business: businessTrack, blockchain: blockchainTrack });
    }

    proposePressed() {
        this.setState({ error: "Please select a track." })
    }

    choosenTrack(data, id) {
        console.log(data)
        if (id == "business") {
            return this.props.navigation.navigate("ProposeChallengeStepTwo", { data: data, id: id })
        } else {
            return this.props.navigation.navigate("ProposeChallengeStepTwo", { data: data, id: id })
        }
    }

    render() {
        const { navigation } = this.props;
        const { business, blockchain } = this.state;
        const {
            Logo_horizontal,
            Info_button,
            Arrow_left
        } = Images;
        return (
            <Screen>
                <View style={Styles.Container}>
                    <Image
                        style={Styles.Image}
                        source={Logo_horizontal}
                        resizeMode="contain"
                    />
                    <View style={Styles.Swiper}>
                        <View style={Styles.StepContainer}>
                            <Text style={Styles.Propose}>
                                Propose your Challenge
                            </Text>
                            <Text style={Styles.Step}>Step 1:</Text>
                            <View style={{ flexDirection: "row", alignSelf: "center" }}>
                                <Text style={Styles.Instructions}>
                                    Choose your track
                                </Text>
                                <TouchableOpacity>
                                    <Image source={Info_button} style={{ width: 20, height: 20 }} resizeMode="contain" />
                                </TouchableOpacity>
                            </View>
                            <TouchableOpacity
                                style={Styles.Track}
                                onPress={this.choosenTrack.bind(
                                    this,
                                    business,
                                    "business"
                                )}
                            >
                                <Text style={Styles.TrackText}>
                                    Business Innovation Track
                                </Text>
                            </TouchableOpacity>
                            <TouchableOpacity
                                style={Styles.Track}
                                onPress={this.choosenTrack.bind(
                                    this,
                                    blockchain,
                                    "blockchain"
                                )}
                            >
                                <Text style={Styles.TrackText}>
                                    Blockchain & DLT track
                                </Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                    <Text style={[Styles.TrackText, { color: "red", textAlign: "center" }]}>{this.state.error}</Text>
                    <BottomArrows
                        onPressLeft={() => navigation.navigate("InqubatorStack")}
                        styles={Styles.Arrow}
                        leftIcon={Arrow_left}
                    />
                </View>

            </Screen>
        );
    }
}

const { Gray } = Colors;
const Styles = StyleSheet.create({
    Container: {
        flex: 1,
        alignItems: "center"
    },
    Arrow: {
        flex: 0,
        marginBottom: 0
    },
    Button: {
        width: "100%",
        alignSelf: "center",
        marginBottom: 0
    },
    Image: {
        width: 180,
        height: 80
    },
    TrackIcon: {
        alignSelf: "center",
        width: 80,
        height: 80
    },
    Instructions: {
        fontSize: 25,
        fontWeight: "600",
        textAlign: "center",
        fontFamily: "OpenSans-Regular"
    },
    Propose: {
        fontSize: 25,
        textAlign: "center",
        fontFamily: "OpenSans-SemiBold"
    },
    Step: {
        fontSize: 30,
        textAlign: "center",
        fontFamily: "OpenSans-Regular"
    },
    Track: {
        width: "80%",
        padding: 5,
        margin: 5,
        backgroundColor: Gray,
        borderRadius: 5,
        alignSelf: "center"
    },
    TrackText: {
        fontSize: 20,
        fontWeight: "500",
        textAlign: "center",
        fontFamily: "OpenSans-Regular"
    },
    Swiper: {
        flex: 1,
        width: "100%",
        alignSelf: "center"
    },
    StepContainer: {
        flex: 1
    },
    Input: {
        alignSelf: "center"
    },
    TokenPool: {
        textAlign: "center",
        fontFamily: "OpenSans-Regular"
    }
});

const mapStateToProps = state => {
    return state;
};

export default connect(mapStateToProps)(ProposeChallenge);
