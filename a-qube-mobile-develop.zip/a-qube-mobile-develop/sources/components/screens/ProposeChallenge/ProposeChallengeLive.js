import React, { Component } from "react"
import { Dimensions, Image, StyleSheet, Text, View } from "react-native"

import Screen from "../../common/Screen/Screen"
import Button from "../../common/Button/Button"
import HeaderButton from "../../common/HeaderButton/HeaderButton"

import Images from "../../../constants/Images"
import Colors from "../../../constants/Colors"

const { Logo_horizontal, Burger_Menu } = Images

const dimensions = Dimensions.get("window");
const imageWidth = dimensions.width / 2;

export default class ProposeChallengeLive extends Component {
    static navigationOptions = ({navigation}) => {
        return {
            headerLeft: (
                <HeaderButton
                    onPress={() => navigation.toggleDrawer()}
                    icon={Burger_Menu}
                />
            ),
            headerTitle: <Image style={{ height: 50, width: 100 }} resizeMode="contain" source={Logo_horizontal} />,
        }
    }

    navigate(screen) {
        const { navigation } = this.props
        navigation.navigate(screen)
    }

    render() {
        const { Puzzle_piece } = Images
        return (
            <Screen>
                <View style={Styles.Container}>
                    <Image source={Puzzle_piece} resizeMode="contain" style={{ width: imageWidth, height: imageWidth }} />
                    <View style={Styles.TextContainer}>
                        <Text style={Styles.Congrats}>Congrats! Your Challenge is live!</Text>
                        <Text>Go to your profile to start receiving contributions!</Text>
                        <Button onPress={() => this.navigate("ApplicationDrawer")}styles={Styles.Button}>My Profile</Button>
                    </View>
                </View>
            </Screen>
        )
    }
}

const { Eerie, Gray, Pink } = Colors
const Styles = StyleSheet.create({
    Container: {
        flex: 1,
        alignItems: 'center',
        paddingTop: 10
    },
    Image: {
        width: 180,
        height: 80,
    },
    Circle: {
        height: 200,
        width: 200,
        backgroundColor: Gray,
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 100,
        marginTop: 40,
    },
    TextContainer: {
        flex: 1,
        paddingLeft: 20,
        paddingRight: 20,
        justifyContent: "space-evenly",
        marginBottom: 40,
        marginTop: 10,
    },
    Congrats: {
        fontSize: 30,
        fontFamily: "OpenSans-Regular",
        textAlign: "center"
    },
    Button: {
        borderRadius: 10,
    },
})
