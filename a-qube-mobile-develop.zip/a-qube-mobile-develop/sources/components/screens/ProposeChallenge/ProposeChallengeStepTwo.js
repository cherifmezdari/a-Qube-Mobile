import React, { Component } from "react";
import {
    Dimensions,
    Image,
    TouchableWithoutFeedback,
    Keyboard,
    StyleSheet,
    Text,
    View
} from "react-native";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";

import { connect } from "react-redux";

import BottomArrows from "../../common/BottomArrows/BottomArrows";
import ContributionTrack from "../../common/ContributionTrack/ContributionTrack";
import Screen from "../../common/Screen/Screen";

import Images from "../../../constants/Images";
import Tracks from "../../../constants/Tracks";
import Colors from "../../../constants/Colors";

const dimensions = Dimensions.get("window");
const imageHeight = Math.round(dimensions.width / 6);

class ProposeChallengeQuestions extends Component {
    static navigationOptions = {
        header: null
    };
    constructor(props) {
        super(props);
        this.state = {
            blockchain: null,
            business: null,
            name: "",
            token_pool: 360,
            qube_number: "",
            trackSlotID: this.props.navigation.state.params.data[0].track._id,
            tracks: this.props.navigation.state.params.data,
            slots: this.props.AddIngredient.slots,
            nature: this.props.navigation.state.params.id,
            error: ""
        };
    }

    navigate(screen) {
        const { navigation } = this.props;
        navigation.navigate(screen);
    }

    displayTrack() {
        const { tracks, nature } = this.state;
        const { Blockchain, Business_Development } = Images;
        const displayImage =
            tracks[0].track.name === Tracks.Business ? (
                <Image source={Business_Development} style={Styles.TrackIcon} />
            ) : (
                    <Image source={Blockchain} style={Styles.TrackIcon} />
                );
        return (
            <View style={Styles.StepContainer}>
                {displayImage}
                <Text style={Styles.Step}>Step 2:</Text>
                <Text style={Styles.Instructions}>
                    Slots for your Challenge
                </Text>
                {this._displayError()}
                {tracks[0].slots.map((slot, index) => (
                    <ContributionTrack
                        key={index}
                        nature={this.props.navigation.state.params.id}
                        slot={slot}
                    >
                        {slot.name}
                    </ContributionTrack>
                ))}
            </View>
        );
    }

    _displayError() {
        if (this.state.error !== "") {
            return (
                <Text style={{ fontSize: 16, color: "red" }}>
                    {this.state.error}
                </Text>
            );
        }
    }

    choosenTrack(data, id) {
        //console.warn(data);
        if (id == "business") {
            this.setState({
                tracks: data,
                trackSlotID: this.state.tracks[0]._id
            });
            this.setState({ nature: "business" });
        } else {
            this.setState({
                tracks: data,
                trackSlotID: this.state.tracks[1]._id
            });
            this.setState({ nature: "blockchain" });
        }
    }

    proposePressed() {
        this.setState({
            error: "You need to complete all four steps before proposing the challenge."
        })
    }

    render() {
        console.log(this.props);
        const {
            Arrow_left,
            Arrow_right
        } = Images;
        const checkTrack =
            this.state.tracks != null ? (
                this.displayTrack()
            ) : (
                    <View style={{ alignItems: "center" }}>
                        <Text
                            style={{ fontSize: 18, fontFamily: "OpenSans-Regular" }}
                        >
                            Please select a track.
                    </Text>

                    </View>
                );
        return (
            <Screen>
                <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
                    <KeyboardAwareScrollView
                        enableOnAndroid={true}
                        contentContainerStyle={{ flex: 1 }}
                    >

                        <View style={Styles.Swiper}>
                            {checkTrack}
                            <Text style={Styles.errorText}>{this.state.error}</Text>
                            <BottomArrows
                                onPressLeft={() =>
                                    this.props.navigation.goBack()
                                }
                                styles={Styles.Arrow}
                                leftIcon={Arrow_left}
                                style={{
                                    height: Dimensions.get("window").width / 14,
                                    width: Dimensions.get("window").width / 14
                                }}
                                rightIcon={Arrow_right}
                                onPressRight={() =>

                              {
                                if(this.state.nature=="business"){
                                  if(this.props.AddIngredient.slots.length>5)
                                  {  this.props.navigation.navigate("ProposeChallengeStepThree", { previousState: this.state })
                                }
                                else {
                                  this.setState({error:"please select more than 5 slots"})
                                }}
                                else {
                                  if(this.props.blockchainRecucer.slots.length>5)
                                  {  this.props.navigation.navigate("ProposeChallengeStepThree", { previousState: this.state })
                                }
                                else {
                                  this.setState({error:"please select more than 5 slots"})
                                }
                                }
                              }
                              }
                            />

                        </View>

                    </KeyboardAwareScrollView>
                </TouchableWithoutFeedback>
            </Screen>
        );
    }
}

const { Eerie, Gray, Pink } = Colors;
const Styles = StyleSheet.create({
    Container: {
        flex: 1,
        alignItems: "center"
    },
    Arrow: {
        flex: 0,
        marginBottom: 0
    },
    Button: {
        width: "100%",
        alignSelf: "center"
    },
    Image: {
        height: Dimensions.get("window").width / 8,
        width: Dimensions.get("window").width / 2
    },
    TrackIcon: {
        alignSelf: "center",
        width: imageHeight,
        height: imageHeight
    },
    Instructions: {
        fontSize: 20,
        fontWeight: "600",
        textAlign: "center",
        fontFamily: "OpenSans-Regular"
    },
    Propose: {
        fontSize: 25,
        textAlign: "center",
        fontFamily: "OpenSans-SemiBold"
    },
    Step: {
        fontSize: 24,
        textAlign: "center",
        fontFamily: "OpenSans-Regular"
    },
    Track: {
        width: "80%",
        padding: 5,
        margin: 5,
        backgroundColor: Gray,
        borderRadius: 5,
        alignSelf: "center"
    },
    TrackText: {
        fontSize: 20,
        fontWeight: "500",
        textAlign: "center",
        fontFamily: "OpenSans-Regular"
    },
    Swiper: {
        flex: 1,
        width: "100%",
        alignSelf: "center",
        justifyContent: "space-between"
    },
    StepContainer: {
        flex: 1,
        justifyContent: "space-between",alignItems:"center"
    },
    Input: {
        alignSelf: "center"
    },
    TokenPool: {
        textAlign: "center",
        fontFamily: "OpenSans-Regular"
    },
    errorText: {
        fontFamily: "OpenSans-Regular",
        color: "red",
        fontSize: 15,
        textAlign: "center"
    }
});

const mapStateToProps = state => {
    return state;
};

export default connect(mapStateToProps)(ProposeChallengeQuestions);
