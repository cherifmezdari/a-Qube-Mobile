import { StyleSheet } from "react-native"

import Colors from "../../../constants/Colors"

const { Gray } = Colors
const Base = StyleSheet.create({
    Badge: {
        position: "absolute",
        top: 50,
        zIndex: 1000
    },
    Text: {
        borderWidth: 2,
        fontSize: 32,
        fontWeight: "800",
        padding: 10,
        fontFamily: "OpenSans-Regular"
    },
    LikeBadge: {
        right: 50,
        transform: [{
            rotate: "30deg"
        }]
    },
    LikeText: {
        borderColor: "red",
        color: "red",
        fontFamily: "OpenSans-Regular"
    },
    DislikeBadge: {
        left: 50,
        transform: [{
            rotate: "-30deg"
        }]
    },
    DislikeText: {
        borderColor: "red",
        color: "red",
        fontFamily: "OpenSans-Regular"
    }
})

export default Base
