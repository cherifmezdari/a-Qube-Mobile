import React, { Component } from "react"
import { Animated, Text } from "react-native"

import Base from "./Styles"

export default class QubeStack extends Component {
    render() {
        const { dislike, children, like } = this.props
        if (like) {
            return (
                <Animated.View style={[ Base.Badge, Base.LikeBadge ]}>
                    <Text style={[ Base.Text, Base.LikeText ]} textTransform="uppercase">
                        {children}
                    </Text>
                </Animated.View>
            )
        } else if (dislike) {
            return (
                <Animated.View style={[ Base.Badge, Base.DislikeBadge ]}>
                    <Text style={[ Base.Text, Base.DislikeText ]} textTransform="uppercase">
                        {children}
                    </Text>
                </Animated.View>
            )
        } else {
            return (
                <Animated.View style={Base.Badge}>
                    <Text style={Base.Text} textTransform="uppercase">
                        {children}
                    </Text>
                </Animated.View>
            )
        }
    }
}
