import React, { Component } from "react"
import { Image, Text, View } from "react-native"
import { Bar } from "react-native-progress"

import Base from "./Qube.style"
import Images from "../../../constants/Images"

export default class Qube extends Component {
    render() {
        const { data: { description, illustration, next } } = this.props
        const { Activity, QUB, Heart } = Images
        return (
            <View style={Base.Card}>
                <View style={Base.Section}>
                    <Image source={{ uri: illustration }} style={Base.Image} />
                </View>
                <View style={Base.Section}>
                    <Text style={Base.Text}>2/6</Text>
                    <Bar borderRadius={5} color={"rgba(128, 51, 73, 1)"} height={10} progress={0.33} />
                </View>
                <View style={Base.Section}>
                    <Text style={Base.Text}>
                        {description}
                    </Text>
                </View>
                <View style={Base.Section}>
                    <Text style={Base.Text}>
                        {next}
                    </Text>
                </View>
                <View style={Base.Section}>
                    <View style={Base.Extras}>
                        <View style={Base.Stats}>
                            <Image style={Base.Text} source={Activity} />
                            <Text style={Base.Text}>71%</Text>
                        </View>
                        <View style={Base.Stats}>
                            <Image style={Base.Text} source={QUB} />
                            <Text style={Base.Text}>250</Text>
                        </View>
                        <View style={Base.Stats}>
                            <Image style={Base.Text} source={Heart} />
                            <Text style={Base.Text}>12</Text>
                        </View>
                    </View>
                </View>
            </View>
        )
    }
}
