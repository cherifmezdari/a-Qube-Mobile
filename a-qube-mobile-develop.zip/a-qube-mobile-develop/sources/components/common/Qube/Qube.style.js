import { StyleSheet } from "react-native"

import Colors from "../../../constants/Colors"

const { Eerie, Gray } = Colors
const Base = StyleSheet.create({
    Card: {
        backgroundColor: Gray,
        borderRadius: 20,
        flex: 1
    },
    Extras: {
        flexDirection: "row",
        justifyContent: "space-between"
    },
    Image: {
        borderRadius: 75,
        height: 150,
        width: 150
    },
    Section: {
        alignItems: "center",
        marginVertical: 10
    },
    Stats: {
        marginHorizontal: 25,
    },
    Text: {
        fontSize: 15,
        textAlign: "center"
    },
    Icon: {
        
    }
    // Image: {
    //     borderRadius: 20,
    //     flex: 1,
    //     height: null,
    //     resizeMode: "cover",
    //     width: null,
    // },
})

export default Base
