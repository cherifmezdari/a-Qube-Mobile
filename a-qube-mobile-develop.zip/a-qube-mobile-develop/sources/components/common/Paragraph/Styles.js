import { StyleSheet } from "react-native"

import Colors from "../../../constants/Colors"

const { White } = Colors
const Base = StyleSheet.create({
    Text: {
        color: White,
        fontSize: 15,
        fontFamily: "OpenSans-Regular"
    },
})

export default Base
