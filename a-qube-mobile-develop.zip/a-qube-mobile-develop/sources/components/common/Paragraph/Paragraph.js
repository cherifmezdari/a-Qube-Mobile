import React, { Component } from "react"
import { Text, View } from "react-native"

import Base from "./Styles"

export default class Paragraph extends Component {
    render() {
        const { children, styles } = this.props
        return(
            <View>
                <Text style={[Base.Text, styles]}>{children}</Text>
            </View>
        )
    }
}
