import React, { Component } from "react";
import { TextInput } from "react-native";

import Base from "./Input.style";
import Colors from "../../../constants/Colors";

export default class Input extends Component {
    render() {
        const { Black } = Colors;
        const {
            autoCapitalize,
            onSubmitEditing,
            placeholder,
            secureTextEntry,
            styles,
            keyboardType,
            onChangeText,
            validate
        } = this.props;
        return (
            <TextInput
                style={
                    !validate ? [Base.Input, styles] : [Base.ErrorInput, styles]
                }
                placeholder={placeholder}
                placeholderTextColor={Black}
                secureTextEntry={secureTextEntry}
                autoCapitalize={autoCapitalize}
                onChangeText={onChangeText}
                onSubmitEditing={onSubmitEditing}
                keyboardType={keyboardType}
            />
        );
    }
}
