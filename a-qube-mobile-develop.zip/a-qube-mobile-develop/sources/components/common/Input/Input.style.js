import { StyleSheet } from "react-native"

import Colors from "../../../constants/Colors"

const { Purple, White, DarkGray } = Colors
const Base = StyleSheet.create({
    Input: {
        alignItems: "center",
        backgroundColor: DarkGray,
        borderColor: Purple,
        borderRadius: 5,
        borderWidth: 2,
        color: "black",
        flexDirection: "row",
        fontSize: 20,
        height: 50,
        margin: 10,
        paddingBottom: 10,
        paddingLeft: 20,
        paddingRight: 20,
        paddingTop: 10,
        width: 300,
        fontFamily: "OpenSans-Regular"
    },
    ErrorInput: {
        alignItems: "center",
        backgroundColor: DarkGray,
        borderColor: "red",
        borderRadius: 5,
        borderWidth: 2,
        color: "black",
        flexDirection: "row",
        fontSize: 20,
        height: 50,
        margin: 10,
        paddingBottom: 10,
        paddingLeft: 20,
        paddingRight: 20,
        paddingTop: 10,
        width: 300,
        fontFamily: "OpenSans-Regular"
    },
      InputVerification: {
        alignItems: "center",
        backgroundColor: DarkGray,
        borderRadius: 5,
        borderWidth: 2,
        color: "black",
        flexDirection: "row",
        fontSize: 20,
        height: 50,
        margin: 10,
        paddingBottom: 10,
        paddingLeft: 20,
        paddingRight: 20,
        paddingTop: 10,
        width: 150,
        fontFamily: "OpenSans-Regular"
        }
})

export default Base
