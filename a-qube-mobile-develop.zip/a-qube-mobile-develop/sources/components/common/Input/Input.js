import React, { Component } from "react"
import { TextInput } from "react-native"

import Base from "./Input.style"
import Colors from "../../../constants/Colors"

export default class Input extends Component {
    render() {
        const { autoCapitalize, onSubmitEditing, value, keyboardType, onChangeText, placeholder, secureTextEntry, styles, multiline } = this.props
        const { Black } = Colors
        return(
            <TextInput
                multiline={multiline}
                autoCapitalize={autoCapitalize}
                onChangeText={onChangeText}
                placeholderTextColor={Black}
                secureTextEntry={secureTextEntry}
                style={[ Base.Input, styles ]} 
                placeholder={placeholder}
                keyboardType={keyboardType}
                value={value}
                onSubmitEditing={onSubmitEditing}
            />
        )
    }
}
