import React, { Component } from "react"
import { Image, Text, TouchableOpacity, View } from "react-native"

import Images from "../../../constants/Images"
import Base from "./Styles"

export default class HeaderButton extends Component {
    render() {
        const { children, styles, icon, onPress } = this.props
        return(
            <TouchableOpacity style={Base.Container} onPress={onPress}>
                <Image style={{ height: 20, width: 20, alignSelf: "center" }} resizeMode="contain" source={icon} />
                <Text style={{ fontFamily: "OpenSans-Regular" }}>{children}</Text>
            </TouchableOpacity>
        )
    }
}