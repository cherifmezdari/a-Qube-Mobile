import { StyleSheet } from "react-native"

const Base = StyleSheet.create({
    Container: {
        paddingLeft: 10,
        paddingRight: 10,
        alignSelf: "center",
        justifyContent: "center"
    },
})

export default Base
