import { StyleSheet } from "react-native"

import Colors from "../../../constants/Colors"

const { Eerie, Gray, Granite, Pink } = Colors
const Base = StyleSheet.create({
    Container: {
        width: "75%",
        height: 60, 
        backgroundColor: "#EAEAEA",
        margin: 20,
        flexDirection: "row",
        alignItems: "center",
        paddingLeft: 20,
        borderRadius: 5, 
    },
    Text: {
        fontSize: 15,
        fontWeight: "600",
        fontFamily: "OpenSans-Regular"
    },
    Icons: {
        marginRight: 10
    },
    Statement: {
        textAlign: "right",
        paddingRight: 20,
        color: "#BABBBD",
        fontFamily: "OpenSans-Regular"
    },
})

export default Base
