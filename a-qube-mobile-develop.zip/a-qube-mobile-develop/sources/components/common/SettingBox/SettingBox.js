import React, { Component } from "react"
import { Image, Text, TouchableOpacity, View } from "react-native"

import Base from "./Styles"

export default class SettingBox extends Component {
    render() {
        const { children, styles, icons, statement, onPress } = this.props
        return(
            <TouchableOpacity onPress={onPress} style={[Base.Container, styles]}>
                <Image style={Base.Icons} source={icons} resizeMode="contain"/>
                <Text style={Base.Text}>{children}</Text>
                <View style={{ flex: 1 }}>
                    <Text style={Base.Statement}>{statement}</Text>
                </View>
            </TouchableOpacity>
        )
    }
}