import { StyleSheet } from "react-native"

import Colors from "../../../constants/Colors"

const { Translucid } = Colors
const { Gray } = Translucid
const Base = StyleSheet.create({
    Screen: {
        alignItems: "center",
        backgroundColor: Gray,
        height: "70%",
        justifyContent: "center",
        width: "90%",
    },
})

export default Base
