import React, { Component } from "react"
import { View } from "react-native"

import Base from "./Styles"

export default class Panel extends Component {
    render() {
        const { children, styles } = this.props
        return(
            <View style={[Base.Screen, styles]}>
                {children}
            </View>
        )
    }
}
