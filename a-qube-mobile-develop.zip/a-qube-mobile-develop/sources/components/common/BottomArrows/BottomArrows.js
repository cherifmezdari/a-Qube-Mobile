import React, { Component } from "react"
import { Dimensions, Image, ImageBackground, Text, TouchableOpacity, View } from "react-native"

import Base from "./Styles"

export default class BottomArrows extends Component {
    displayBadgeIcon(number) {
        return (
            <View style={{ position: "absolute", backgroundColor: "red", width: Dimensions.get("window").width / 16, alignSelf: "flex-end", borderRadius: 20 }}>
                <Text style={{ padding: 1, color: "white", fontFamily: "OpenSans-Regular", textAlign: "center"}}>{number}</Text>
            </View>
        )
    }
    render() {
        const { children, onPressRight, onPressLeft, color, leftIcon, rightIcon, styles, leftBadge, style, leftColor, rightStyle } = this.props
        const displayBadge = (leftBadge) ? this.displayBadgeIcon(leftBadge) : null
        return(
            <View style={[Base.ArrowContainer, styles]}>
                <TouchableOpacity onPress={onPressLeft}>
                    <Image source={leftIcon} resizeMode="contain" style={[Base.Arrows, style,  {height: Dimensions.get("window").width / 10, width: Dimensions.get("window").height / 10, tintColor: color, tintColor: leftColor}]} />
                    {displayBadge}
                </TouchableOpacity>
                <TouchableOpacity onPress={onPressRight}>
                    <Image source={rightIcon} resizeMode="contain" style={[Base.Arrows, style, {height: Dimensions.get("window").width / 10, width: Dimensions.get("window").height / 10, tintColor: color}, rightStyle]}/>
                </TouchableOpacity>
            </View>
        )
    }
}