import { StyleSheet } from "react-native"

import Colors from "../../../constants/Colors"

const { Eerie, White } = Colors
const Base = StyleSheet.create({
    ArrowContainer: {
        flexDirection: "row",
        width: "100%",
        paddingLeft: 40,
        paddingRight: 40,
        justifyContent: "space-between",
        alignItems: "flex-end",
        marginBottom: 10,
    },
    Arrows: {
        
    },
})

export default Base
