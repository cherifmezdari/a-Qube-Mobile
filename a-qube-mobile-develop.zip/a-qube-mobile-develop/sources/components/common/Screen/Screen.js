import React, { Component } from "react"
import { ImageBackground, View } from "react-native"
import { SafeAreaView } from "react-navigation"

import Base from "./Styles"

export default class Screen extends Component {
    render() {
        const { children, styles, qube_Border } = this.props
        return(
            <SafeAreaView>
                <ImageBackground style={Base.Background} source={qube_Border}>
                    <View style={[Base.Screen, styles]}>
                        {children}
                    </View>
                </ImageBackground>
            </SafeAreaView>
        )
    }
}
