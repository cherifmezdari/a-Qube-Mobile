import { StyleSheet } from "react-native"

const Base = StyleSheet.create({
    Background: {
        height: "100%",
        width: "100%",
    },
    Screen: {
        flex: 1,
    },
})

export default Base
