import React, { Component } from "react"
import { Text, View } from "react-native"
import Slider from "@react-native-community/slider"

import Base from "./ProposeChallengeStep.style"

export default class ProposeStep extends Component {
    render() {
        const { step } = this.props
        switch(step) {
            case 1:
                return (
                    <View style={Base.Content}>
                        <Text style={Base.Propose}>Propose your Challenge</Text>
                        <Text style={Base.Step}>Step 1:</Text>
                        <Text style={Base.Instructions}>Choose your track</Text>
                        <TouchableOpacity style={Base.Track}>
                            <Text style={Base.TrackText}>Business Innovation Track</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={Base.Track}>
                            <Text style={Base.TrackText}>Blockchain & DLT track</Text>
                        </TouchableOpacity>
                    </View>
                )
            case 2:
                return (
                    <View style={Base.Content}>
                        <Text style={Base.Step}>Step 2:</Text>
                        <Text style={Base.Instructions}>Slots for your Challenge</Text>
                        <ContributionTrack>Name & Statement</ContributionTrack>
                        <ContributionTrack>Problem & Solution</ContributionTrack>
                        <ContributionTrack>Use of blockchain tech</ContributionTrack>
                        <ContributionTrack>Consensus & Governance</ContributionTrack>
                        <ContributionTrack>Type & token usage</ContributionTrack>
                        <ContributionTrack>Business Model & tokenomics</ContributionTrack>
                        <ContributionTrack>Competitive Analysis</ContributionTrack>
                        <ContributionTrack>Logo</ContributionTrack>
                    </View>
                )
            case 3:
                return (
                    <View style={Base.Content}>
                        <Text style={Base.Step}>Step 3:</Text>
                        <Text style={Base.Instructions}>Describe your Challenge in 6-to-8 words</Text>
                        <View style={Base.SpaceContent}>
                            <Input Base={Base.Input} multiline={true}/>
                        </View>
                    </View>
                )
            case 4:
                return (
                    <View style={Base.Content}>
                        <Text style={Base.Step}>Step 4:</Text>
                        <View style={Base.QuestionSection}>
                            <Text style={Base.Instructions}>1. Value of the Qube/Solution:</Text>
                            <Slider
                                style={{ width: "80%", height: 40, alignSelf: "center" }}
                                minimumValue={0}
                                maximumValue={1}
                                minimumTrackTintColor="rgba(128, 51, 73, 1)"
                                maximumTrackTintColor="gray"
                            />
                            <Text style={Base.Instructions}>2. Number of Qubes/Solution (1-to-3)</Text>
                            <Input />
                        </View>
                    </View>
                )
        }
    }
}
