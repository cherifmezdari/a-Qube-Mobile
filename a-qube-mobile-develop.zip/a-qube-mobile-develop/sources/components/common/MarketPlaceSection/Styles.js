import { StyleSheet } from "react-native"

import Colors from "../../../constants/Colors"

const { Eerie } = Colors
const Base = StyleSheet.create({
    Container: {
        flex: 1,
    },
    Row: {
        flexDirection: "row",
        flex: 1,
        justifyContent: "space-evenly",
        width: "95%",
        alignSelf: "center",
        margin: 5,
    },
    ImageBorder: {
        height: 90,
        width: 90,
        borderColor: "lightgrey",
        borderWidth: 2,
        borderRadius: 5,
        alignItems: "center",
    },
    Image: {
        height: 80,
        width: 80,
    },
    Idea: {
        flex: 1,
        alignItems: "center",
        margin: 5,
        padding: 5,
    },
    Title: {
        fontSize: 18,
        textAlign: "center",
    },
    Qubes: {
        fontSize: 14,
        textAlign: "center",
        fontFamily: "OpenSans-Regular"
    },
    Buttons: {
        paddingLeft: 10,
        paddingRight: 10,
        paddingTop: 10,
        paddingBottom: 10,
        borderRadius: 5,
    },
    NoQubes: {
        textAlign: "center",
        fontSize: 20,
        color: "lightgrey"
    },
    Name: {
        fontSize: 15,
        fontWeight: "500",
        fontFamily: "OpenSans-Regular"
    }
})

export default Base
