import React, { Component } from "react"
import { FlatList, Image, Text, TouchableOpacity, View } from "react-native"
import { Bar } from "react-native-progress"

import Base from "./Styles"
import Button from "../Button/Button"
import Images from "../../../constants/Images"

const { Espresso } = Images

export default class MarketPlaceSection extends Component {
    _keyExtractor = (item, index) => index;
    _renderItem = ({item}) => (
        <View style={Base.Idea}>
            <View style={Base.ImageBorder}>
                <Image source={Espresso} style={Base.Image} resizeMode="contain"/>
            </View>
            <Text style={Base.Name}>Espresso Trade</Text>
            <Button styles={Base.Buttons}>View</Button>
        </View>
    );
    _renderIdeas(data) {
        const qubes = data.length
        if(data.length > 5) {
            data = data.splice(0,6)
        }
        return (
            <View style={Base.Container}>
                <Text style={Base.Qubes}>{qubes} Qubes</Text>
                    <View style={Base.Row}>
                        <FlatList
                            data={data}
                            keyExtractor={this._keyExtractor}
                            renderItem={this._renderItem}
                            numColumns={3}
                        />
                    </View>
            </View>
        )
    }
    render() {
        const { children, styles, title, qubes, image, data } = this.props

        const displayIdeas = data ? this._renderIdeas(data) : <View style={{ height: 100 }}><Text style={Base.NoQubes}>No Qubes</Text></View>
        return(
            <View style={Base.Container}>
                {displayIdeas}
            </View>
        )
    }
}