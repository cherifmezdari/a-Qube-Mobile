import React, { Component } from "react"
import { Image, Text, TouchableOpacity, View } from "react-native"

import { fetchEngagementRate } from "../../../api/UserEndpoints"

import Base from "./Styles"

export default class ChallengeCard extends Component {
    constructor(props) {
        super(props)

        this.state = {
            rate: 0
        }
    }

    componentWillMount() {
        console.log(this.props.item._id)
        fetchEngagementRate(this.props.item._id).then(v => this.setState({ rate: v.engagement_rate }))
    }

    render() {
        const { image } = this.props
        const displayImage = image ? 
            <Image source={image} style={Base.Image} resizeMode="contain"/> : 
            <View style={{ width: 100, height: 100 }}/>
        return (
            <TouchableOpacity style={Base.Container}>
                {displayImage}
                <View style={Base.InfoContainer}>
                    <View style={Base.Info}>
                        <Text style={Base.text}>Engagement Rate: </Text>
                        <Text style={Base.text}>{this.state.rate}</Text>
                    </View>
                </View>
            </TouchableOpacity>
        )
    }
}