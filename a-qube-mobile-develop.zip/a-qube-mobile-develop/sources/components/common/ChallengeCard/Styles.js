import { StyleSheet } from "react-native"

import Colors from "../../../constants/Colors"

const { Eerie, Gray } = Colors
const Base = StyleSheet.create({
    Container: {
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: Gray,
        width: "100%",
        borderRadius: 10,
        padding: 10,
        marginVertical: 5,
        flex: 1
    },
    Image: {
        height: 100,
        width: 100,
    },
    InfoContainer: {
        flex: 1,
        justifyContent: "space-evenly",
        paddingLeft: 10,
    },
    Info: {
        flexDirection: "row",
        alignItems: "center"
    },
    Icon: {
        marginRight: 5,
        height: 20,
        width: 20,
    },
    ProgressBar: {
        flex: 1,
        justifyContent: "center",
    },
    text: {
        fontSize: 15, 
        fontFamily: "OpenSans-Regular"
    }
})

export default Base
