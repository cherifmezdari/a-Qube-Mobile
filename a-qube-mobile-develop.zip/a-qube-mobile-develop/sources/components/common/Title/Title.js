import React, { Component } from "react"
import { Text, View } from "react-native"

import Base from "./Styles"

export default class Title extends Component {
    render() {
        const { children, styles } = this.props
        return(
            <View>
                <Text style={[Base.Title, styles]}>{children}</Text>
            </View>
        )
    }
}
