import { StyleSheet } from "react-native"

import Colors from "../../../constants/Colors"

const { Eerie } = Colors
const Base = StyleSheet.create({
    Title: {
        color: Eerie,
        fontSize: 30,
        fontWeight: "700",
        fontFamily: "OpenSans-SemiBold"
    },
})

export default Base
