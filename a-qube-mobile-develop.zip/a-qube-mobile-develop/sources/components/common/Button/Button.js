import React, { Component } from "react"
import { Text, TouchableOpacity, View } from "react-native"

import Base from "./Styles"

export default class Button extends Component {
    render() {
        const { children, onPress, styles, viewStyle } = this.props
        return(
            <View>
                <TouchableOpacity style={[Base.Button, styles]} onPress={onPress}>
                    <Text style={Base.Label}>{children}</Text>
                </TouchableOpacity>
            </View>
        )
    }
}
