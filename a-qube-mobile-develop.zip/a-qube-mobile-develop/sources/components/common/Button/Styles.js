import { StyleSheet } from "react-native"

import Colors from "../../../constants/Colors"

const { Eerie, White } = Colors
const Base = StyleSheet.create({
    Button: {
        backgroundColor: Eerie,
        margin: 10,
        paddingBottom: 15,
        paddingLeft: 30,
        paddingRight: 30,
        paddingTop: 15,
    },
    Label: {
        color: White,
        fontSize: 15,
        textAlign: "center",
        textTransform: "uppercase",
        fontFamily: "OpenSans-Regular"
    },
})

export default Base
