import React, { Component } from "react"
import { ScrollView, Text, View } from "react-native"

import Input from "../Input/Input"
import Forms from "../../../constants/Forms"
import Base from "./ProposeContributionStep.style"

export default class ProposeStep extends Component {
    render() {
        const { styles, questions, singleQuestion, doubleQuestion, tripleQuestion } = this.props
        const { Placeholders } = Forms
        const { TextBox } = Placeholders
        if (singleQuestion) {
            return (
                <View style={Base.Slide}>
                    <Text style={[ Base.Text, Base.Question ]}>a: {questions[0].name}</Text>
                    <Input multiline={true} placeholder={TextBox} styles={[ Base.TextBox, Base.TextBoxBig ]} />
                </View>
            )
        } else if (doubleQuestion) {
            return (
                <View style={Base.Slide}>
                    <Text style={[ Base.Text, Base.Question ]}>a: {questions[0].name}</Text>
                    <Input multiline={true} placeholder={TextBox} styles={[ Base.TextBox, Base.TextBoxSmall ]} />
                    <Text style={[ Base.Text, Base.Question ]}>b: {questions[1].name}</Text>
                    <Input multiline={true} placeholder={TextBox} styles={[ Base.TextBox, Base.TextBoxSmall ]} />
                </View>
            )
        } else if (tripleQuestion) {
            return (
                <View style={Base.Slide}>
                    <Text style={[ Base.Text, Base.Question ]}>a: {questions[0].name}</Text>
                    <Input multiline={true} placeholder={TextBox} styles={[ Base.TextBox, Base.TextBoxSmall, styles ]} />
                    <Text style={[ Base.Text, Base.Question ]}>b: {questions[1].name}</Text>
                    <Input multiline={true} placeholder={TextBox} styles={[ Base.TextBox, Base.TextBoxSmall, styles ]} />
                    <Text style={[ Base.Text, Base.Question ]}>b: {questions[2].name}</Text>
                    <Input multiline={true} placeholder={TextBox} styles={[ Base.TextBox, Base.TextBoxSmall, styles ]} />
                </View>
            )
        }
    }
}
