import { StyleSheet } from "react-native"

import Colors from "../../../constants/Colors"

const { Eerie } = Colors
const Base = StyleSheet.create({
    Slide: {
        flex: 1,
        justifyContent: "center",
        alignItems: 'center',
    },
    Text: {
        color: Eerie,
        fontSize: 14,
        padding: 5,
        textAlign: "left",
        fontFamily: "OpenSans-Regular"
    },
    TextBox: {
        backgroundColor: 'white',
        color: Eerie,
    },
    TextBoxBig: {
        height: 300,
    },
    TextBoxSmall: {
        height: 100,
    },
    Question: {
        fontSize: 14,
        fontWeight: "700",
        fontFamily: "OpenSans-Regular"
    }
})

export default Base
