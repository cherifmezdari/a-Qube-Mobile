import React, { Component } from "react"
import { Image, Text, TouchableOpacity, View } from "react-native"

import Base from "./Styles"
import Images from "../../../constants/Images"

export default class Stats extends Component {
    render() {
        const { children, styles, line, reply, like } = this.props
        const { Activity, QUB, Heart } = Images
        return(
            <View style={Base.Container}>
                <View style={Base.Center}>
                    <Image style={Base.Icons} source={Activity} />
                    <Text style={Base.Text}>{line}</Text>
                </View>
                <View style={Base.Center}>
                    <Image style={Base.Icons} source={QUB} />
                    <Text style={Base.Text}>{reply}</Text>
                </View>
                <View style={Base.Center}>
                    <Image style={Base.Icons} source={Heart} />
                    <Text style={Base.Text}>{like}</Text>
                </View>
            </View>
        )
    }
}