import { StyleSheet } from "react-native"

import Colors from "../../../constants/Colors"

const { Eerie } = Colors
const Base = StyleSheet.create({
    Container: {
        flexDirection: "row",
        justifyContent: "space-evenly",
    },
    Icons: {
        tintColor: Eerie
    },
    Center: {
        alignItems: "center",
        justifyContent: "space-evenly",
    },
    Text: {
        fontFamily: "OpenSans-Regular"
    }
})

export default Base
