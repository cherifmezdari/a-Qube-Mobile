import React, { Component } from "react";
import { Image, Text, TouchableOpacity, View } from "react-native";

import { connect } from "react-redux";

import Base from "./ContributionTrack.style";
import Images from "../../../constants/Images";

class ContributionTrack extends Component {
    constructor(props) {
        super(props);
        this.state = {
            pressed: false
        };
    }

    componentWillMount() {
        if (this.props.nature === "blockchain" && this.props.children === "Project Name + Statement" || this.props.nature === "blockchain" && this.props.children === "Problem & Solution") {
            this.saveBlock();
        }
    }

    saveSlot() {
        const action = {
            type: "TOGGLE_INGREDIENT",
            value: this.props.slot._id
        };
        this.props.dispatch(action);
    }

    saveBlock() {
        const action = { type: "TOGGLE_BLOCK", value: this.props.slot._id };
        this.props.dispatch(action);
        console.log(this.props);
    }

    renderBlockSlot() {
        const { children, id } = this.props;
        const { Check_box } = Images;
        return (
            <View style={Base.Container}>
                <Image style={Base.Arrow} source={Check_box} />
                <Text style={Base.Text}>{children}</Text>
                <View style={Base.ProgressSection}>
                    <Text>{id}</Text>
                </View>
            </View>
        )
    }

    renderBlockchain() {
        const { children, id } = this.props;
        const { Arrow_right, Check_box, Empty_Checkbox } = Images;
        const { pressed } = this.state;
        const isPressed = pressed ? (
            <Image style={Base.Arrow} source={Check_box} />
        ) : (
                <Image style={Base.Arrow} source={Empty_Checkbox} />
            );

        const checkSlot = (children === "Project Name + Statement" || children === "Problem & Solution") ? this.renderBlockSlot() : this.renderBusiness()

        return (
            <View>
                {checkSlot}
            </View>
        )
    }

    renderBusiness() {
        const { children, id } = this.props;
        const { Arrow_right, Check_box, Empty_Checkbox } = Images;
        const { pressed } = this.state;
        const isPressed = pressed ? (
            <Image style={Base.Arrow} source={Check_box} />
        ) : (
                <Image style={Base.Arrow} source={Empty_Checkbox} />
            );
        return (
            <TouchableOpacity
                style={Base.Container}
                onPress={() => {
                    this.setState({ pressed: !pressed });
                    if (this.props.nature == "business") {
                        this.saveSlot();
                    } else if (this.props.nature == "blockchain") {
                        this.saveBlock();
                    }
                }}
            >
                {isPressed}
                <Text style={Base.Text}>{children}</Text>
                <View style={Base.ProgressSection}>
                    <Text>{id}</Text>
                </View>
            </TouchableOpacity>
        )
    }

    render() {

        const slotType = (this.props.nature === "blockchain") ? this.renderBlockchain() : this.renderBusiness()
        return (
            <View>
                {slotType}
            </View>
        );
    }
}
const mapStateToProps = state => {
    return state;
};

export default connect(mapStateToProps)(ContributionTrack);
