import { StyleSheet } from "react-native"

import Colors from "../../../constants/Colors"

const { Eerie, Gray } = Colors
const Base = StyleSheet.create({
    Container: {
        width: "80%",
        alignSelf: "center",
        backgroundColor: Gray,
        paddingHorizontal: 10,
        paddingVertical: 5,
        borderRadius: 5,
        flexDirection: "row",
        justifyContent: "space-between",
        margin: 5
    },
    Text: {
        fontSize: 15,
        fontFamily: "OpenSans-Regular"
    },
    ProgressSection: {
        flexDirection: "row",
        alignItems: "center"
    },
    Arrow: {
        paddingLeft: 5,
    },
})

export default Base
