import { StyleSheet } from "react-native"

const Base = StyleSheet.create({

})

export default Base
