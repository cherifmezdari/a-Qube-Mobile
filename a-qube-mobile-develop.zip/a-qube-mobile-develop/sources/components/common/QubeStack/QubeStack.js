import React, { Component } from "react"
import { Animated, Dimensions, PanResponder, StyleSheet, View } from "react-native"

import Base from "./QubeStack.style"
import Qube from "../Qube/Qube"
import QubeBadge from "../QubeBadge/QubeBadge"

const window = Dimensions.get("window")

export default class QubeStack extends Component {
    constructor(props) {
        super(props)
        this.animatedValue = new Animated.ValueXY()
        this.cardRotation = this.animatedValue.x.interpolate({
            inputRange: [-(window.width / 2), 0, (window.width / 2)],
            outputRange: ["-10deg", "0deg", "10deg"],
            extrapolate: "clamp",
        })
        this.cardTranslateTransform = {
            transform: [
                {
                    rotate: this.cardRotation,
                },
                ...this.animatedValue.getTranslateTransform(),
            ]
        }
        this.leftBadgeOpacity = this.animatedValue.x.interpolate({
            inputRange: [-(window.width / 2), 0, (window.width / 2)],
            outputRange: ["0", "0", "1"],
            extrapolate: "clamp",
        })
        this.panResponder = PanResponder.create({
            onStartShouldSetPanResponder: (event, state) => true,
            onPanResponderMove: (event, state) => {
                this.animatedValue.setValue({ x: state.dx, y: state.dy })
            },
            onPanResponderRelease: (event, state) => {

            },
        })
        this.rightBadgeOpacity = this.animatedValue.x.interpolate({
            inputRange: [-(window.width / 2), 0, (window.width / 2)],
            outputRange: ["1", "0", "0"],
            extrapolate: "clamp",
        })
        this.state = {
            currentQubeIndex: 0,
        }
    }
    render() {
        const { qubes } = this.props
        const { currentQubeIndex } = this.state
        return (
            <Animated.View {...this.panResponder.panHandlers} style={[ Styles.Stack, this.cardTranslateTransform ]}>
                <Qube key={qubes.id} data={qubes} />
                <QubeBadge dislike style={{ opacity: this.leftBadgeOpacity }}>Dislike</QubeBadge>
                <QubeBadge like style={{ opacity: this.rightBadgeOpacity }}>Like</QubeBadge>
            </Animated.View>
        )
    }
}

const Styles = StyleSheet.create({
    Stack: {
        height: (window.height - 200),
        padding: 20,
        position: "absolute",
        width: window.width,
    }
})
