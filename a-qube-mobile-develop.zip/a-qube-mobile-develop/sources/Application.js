
import React, { Component } from "react"
import { Provider } from "react-redux"
import { StyleSheet } from "react-native"
import { createAppContainer, createDrawerNavigator, createStackNavigator, createSwitchNavigator } from "react-navigation"
import Config from 'react-native-config'


import ChooseAvatar from "./components/screens/Auth/ChooseAvatar"
import CreateNickname from "./components/screens/Auth/CreateNickname"
import EnterCode from "./components/screens/Auth/EnterCode"
import Login from "./components/screens/Auth/Login"
import NewPickSkills from "./components/screens/Auth/NewPickSkills"
import ProfileComplete from "./components/screens/Auth/ProfileComplete"
import Register from "./components/screens/Auth/Register"
import Verification from "./components/screens/Auth/Verification"
import VerifyAccount from "./components/screens/Auth/VerifyAccount"
import Welcome from "./components/screens/Auth/Welcome"
import ForgotPassword from "./components/screens/Auth/ForgotPassword"
import CreateNewPassword from "./components/screens/Auth/CreateNewPassword"
import EnterVerificationCode from "./components/screens/Auth/EnterVerificationCode"

import ProposeChallenge from "./components/screens/ProposeChallenge/ProposeChallenge"
import ProposeChallengeStepTwo from "./components/screens/ProposeChallenge/ProposeChallengeStepTwo"
import ProposeChallengeStepThree from "./components/screens/ProposeChallenge/ProposeChallengeStepThree"
import ProposeChallengeStepFour from "./components/screens/ProposeChallenge/ProposeChallengeStepFour"
import ProposeChallengeLive from "./components/screens/ProposeChallenge/ProposeChallengeLive"

import ProposeContribution from "./components/screens/Contribution/ProposeContribution"
import Contribute from "./components/screens/Contribution/Contribute"

import Profile from "./components/screens/User/Profile"
import Settings from "./components/screens/User/Settings"
import MarketPlace from "./components/screens/User/MarketPlace"
import Notifications from "./components/screens/User/Notifications"
import NewInqubator from "./components/screens/User/NewInqubator"

import ProposeValidation from "./components/screens/Validation/ProposeValidation"

import Store from "./state/store/Store"

import Images from "./constants/Images"

import HeaderButton from "./components/common/HeaderButton/HeaderButton"


function getStackDefaultNavigationOptions(initialRoute) {
    const options = {
        defaultNavigationOptions: () => {
            return {
                gesturesEnabled: false,
                headerMode: "none",
            }
        },
        initialRouteName: initialRoute
    }
    return options
}

function getDrawerDefaultNavigationOptions(initialRoute) {
    const options = {
        defaultNavigationOptions: ({ navigation }) => {
            const { Burger_Menu } = Images
            return {
                gesturesEnabled: false,
                headerTitle: "a-Qube",
                headerLeft: <HeaderButton onPress={() => navigation.toggleDrawer()} icon={Burger_Menu} />
            }
        },
        initialRouteName: initialRoute
    }
    return options
}

const InqubatorStack = createStackNavigator({
    inQubator: { screen: NewInqubator },
    Contribute: { screen: Contribute },
    ProposeContribution: { screen: ProposeContribution},
    ProposeValidation: { screen: ProposeValidation },
    ProposeChallenge: { screen: ProposeChallenge },
    Notifications: { screen: Notifications }
}, getDrawerDefaultNavigationOptions("inQubator"))

const ProfileStack = createStackNavigator({
    Profile: { screen: Profile }
}, getDrawerDefaultNavigationOptions("Profile"))

const ProposeChallengeStack = createStackNavigator({
    ProposeChallenge: { screen: ProposeChallenge },
    ProposeChallengeStepTwo: { screen: ProposeChallengeStepTwo },
    ProposeChallengeStepThree: { screen: ProposeChallengeStepThree },
    ProposeChallengeStepFour: { screen: ProposeChallengeStepFour },
    ProposeChallengeLive: { screen: ProposeChallengeLive }
}, getStackDefaultNavigationOptions("ProposeChallenge"))

const MarketPlaceStack = createStackNavigator({
    MarketPlace: { screen: MarketPlace }
}, getDrawerDefaultNavigationOptions("MarketPlace"))

const SettingsStack = createStackNavigator({
    Settings: { screen: Settings },
    Notifications: { screen: Notifications }
}, getDrawerDefaultNavigationOptions("Settings"))

const ApplicationDrawer = createDrawerNavigator({
    inQubator: InqubatorStack,
    Profile: ProfileStack,
    marketPlace: MarketPlaceStack,
    Settings: SettingsStack,
}, getDrawerDefaultNavigationOptions("inQubator"))

const AuthenticationStack = createStackNavigator({
    CreateNewPassword: { screen: CreateNewPassword },
    EnterVerificationCode: { screen: EnterVerificationCode },
    ForgotPassword: { screen: ForgotPassword },
    EnterCode: { screen: EnterCode },
    Login: { screen: Login },
    Register: { screen: Register },
    VerifyAccount: { screen: VerifyAccount },
    Welcome: { screen: Welcome },
}, getStackDefaultNavigationOptions("Welcome"))

const CreateProfileStack = createStackNavigator({
    ChooseAvatar: { screen: ChooseAvatar },
    CreateNickname: { screen: CreateNickname },
    ProfileComplete: { screen: ProfileComplete },
    NewPickSkills: { screen: NewPickSkills }
}, getStackDefaultNavigationOptions("CreateNickname"))

const VerificationStack = createStackNavigator({
    Verification: { screen: Verification }
}, getStackDefaultNavigationOptions("Verification"))

const ApplicationSwitch = createSwitchNavigator({
    InqubatorStack,
    ProposeChallengeStack,
    ProfileStack,
    CreateProfileStack,
    AuthenticationStack,
    ApplicationDrawer,
    VerificationStack
}, { initialRouteName: "VerificationStack" })

const ApplicationContainer = createAppContainer(ApplicationSwitch)

export default class Application extends Component {
    render() {
        return (
            <Provider store={Store}>
                <ApplicationContainer />
            </Provider>
        )
    }
}

const styles = StyleSheet.create({
    drawerIcon: {
        paddingLeft: 20
    }
})
