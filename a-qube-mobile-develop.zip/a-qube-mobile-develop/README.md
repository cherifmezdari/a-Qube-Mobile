[![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)

# a-Qube

The first decentralized **marketplace of ideas**, a peer-to-peer **mobile incubator** where ideas have value.

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. See deployment for notes on how to deploy the project on a live system.

### Prerequisites

To run this project you will need to have the following packages pre-installed in your system.

```
Give examples
```

### Installing

To setup this project locally all you need to do it to install the neccesary **npm packages**.

To do that open your **Terminal** and run the following.

```
npm install
```

### build and run a local debug version (tested on AndroidX)

```
npm install
npm start&
npm run android // please setup a local .env file equivalent to .env.staging
```

### build for staging

```
npm run android-staging
```


## Deployment

Add additional notes about how to deploy this on a live system

## Built with

* [React Native](https://facebook.github.io/react-native/) is a framework for building native applications using React.js.
* [Redux](https://redux.js.org) is a predictable state container for JavaScript applications.
* [React Navigation](https://reactnavigation.org) is a framework that provides routing and navigation capabilities for React Native applications.

## Versioning

We use [SemVer](http://semver.org/) for versioning.

## Authors

See also the list of [tags on this repository](https://github.com/your/project/contributors) who participated in this project.

## License

GNU GENERAL PUBLIC LICENSE
Version 3, 29 June 2007
Copyright © 2007 Free Software Foundation, Inc. <https://fsf.org/>
Copyright © 2019 a-Qube <https://a-qube.io>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
