import { AppRegistry as ApplicationRegistry} from "react-native"

import Application from "./sources/Application"

import { name as Name } from "./app.json"


ApplicationRegistry.registerComponent(Name, () => Application)
